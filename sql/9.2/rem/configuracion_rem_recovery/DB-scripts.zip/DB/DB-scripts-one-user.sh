#!/bin/bash
if [ "$#" -ne 1 ]; then
    echo "Este script sólo se debe utilizar para ejecutar los scripts con un único usuario que tiene acceso a todos los demás."
    echo "Parametro: usuario/pass@host:port/sid"
    exit
fi

function run_scripts {
	export NLS_LANG=.AL32UTF8
	exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01.sql
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql" "REM01" "Carlos Pérez" "online"  "9.1" "20151021" "PRODUCTO-359" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS-REM01-reg3.1.sql > DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_COMPILE_PACKAGE_UTILS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql 20151026 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "REM01" "ALBERTO BARRANTES" "web"  "9.1" "20151026" "PRODUCTO-334" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS-REM01-reg3.1.sql > DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "20151026" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "20151026" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_CREATE_TABLE_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql 20150821 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql" "REM01" "Alberto Campos" "online"  "9.1.3" "20150821" "CMREC-415" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS-REM01-reg3.1.sql > DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql" "20150821" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql" "20150821" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_PCE_CONFIGURACION_EMAILS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql 20151005 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql" "REM01" "BRUNO ANGLÉS ROBLES" "online"  "X.X.X_rcXX" "20151005" "PRODUCTO-277" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY-REM01-reg3.1.sql > DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql" "20151005" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql" "20151005" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_REFACTOR_FORMULAS_PERSONA_W_TEMPORARY.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql 20151014 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151014" "BKREC-58" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA-REM01-reg3.1.sql > DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql" "20151014" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql" "20151014" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_T_ARR_ARQ_RECUPERACION_PERSONA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql 20160113 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "REM01" "PEDROBLASCO" "online"  "9.1" "20160113" "CMREC-1754" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores-REM01-reg3.1.sql > DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "20160113" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "20160113" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CrearCategorizaciones.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CrearCategorizaciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CrearCategorizaciones.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CrearCategorizaciones.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CrearCategorizaciones.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CrearCategorizaciones-REM01-reg3.1.sql > DDL_001_ENTITY01_CrearCategorizaciones.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CrearCategorizaciones.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CrearCategorizaciones.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CrearCategorizaciones.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CrearCategorizaciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CrearCategorizaciones.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CrearCategorizaciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql 20150623 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150623" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION-REM01-reg3.1.sql > DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql" "20150623" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql" "20150623" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CREATE_TABLE_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql 20150611 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql" "REM01" "CARLOS PEREZ" "batch"  "NO-DISPONIBLE" "20150611" "NO-DISPONIBLE" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_SEG-ArquetipoRecuperacion-REM01-reg3.1.sql > DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql" "20150611" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql" "20150611" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_SEG-ArquetipoRecuperacion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_002_ENTITY01_CrearCategorias.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_002_ENTITY01_CrearCategorias.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_CrearCategorias.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_002_ENTITY01_CrearCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_002_ENTITY01_CrearCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_CrearCategorias-REM01-reg3.1.sql > DDL_002_ENTITY01_CrearCategorias.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_002_ENTITY01_CrearCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_002_ENTITY01_CrearCategorias.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CrearCategorias.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_002_ENTITY01_CrearCategorias.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CrearCategorias.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_002_ENTITY01_CrearCategorias.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql 20150623 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150623" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION-REM01-reg3.1.sql > DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql" "20150623" "REM01" "KO" ""
	      echo "@KO@: DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql" "20150623" "REM01" "OK" ""
	      echo " OK : DDL_002_ENTITY01_CREATE_TABLE_DD_PCO_PRC_TIPO_PREPARACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql" "REM01" "CARLOS PEREZ" "batch"  "NO-DISPONIBLE" "20150622" "NO-DISPONIBLE" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_002_ENTITY01_SEG_AddTablasTmpClientes.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_002_ENTITY01_SEG_AddTablasTmpClientes.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_SEG_AddTablasTmpClientes-REM01-reg3.1.sql > DDL_002_ENTITY01_SEG_AddTablasTmpClientes.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_002_ENTITY01_SEG_AddTablasTmpClientes.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_002_ENTITY01_SEG_AddTablasTmpClientes.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_002_ENTITY01_SEG_AddTablasTmpClientes.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_003_ENTITY01_CrearRelacionCategorias.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_003_ENTITY01_CrearRelacionCategorias.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_003_ENTITY01_CrearRelacionCategorias.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_003_ENTITY01_CrearRelacionCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_003_ENTITY01_CrearRelacionCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_003_ENTITY01_CrearRelacionCategorias-REM01-reg3.1.sql > DDL_003_ENTITY01_CrearRelacionCategorias.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_003_ENTITY01_CrearRelacionCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_003_ENTITY01_CrearRelacionCategorias.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_CrearRelacionCategorias.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_003_ENTITY01_CrearRelacionCategorias.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_CrearRelacionCategorias.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_003_ENTITY01_CrearRelacionCategorias.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql 20150623 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150623" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION-REM01-reg3.1.sql > DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql" "20150623" "REM01" "KO" ""
	      echo "@KO@: DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql" "20150623" "REM01" "OK" ""
	      echo " OK : DDL_003_ENTITY01_CREATE_TABLE_DD_PCO_DOC_UNIDADGESTION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql 20150721 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql" "REM01" "CARLOS PEREZ" "batch"  "NO-DISPONIBLE" "20150721" "NO-DISPONIBLE" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_003_ENTITY01_SEG-AddTablasTmpRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_003_ENTITY01_SEG-AddTablasTmpRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_003_ENTITY01_SEG-AddTablasTmpRevision-REM01-reg3.1.sql > DDL_003_ENTITY01_SEG-AddTablasTmpRevision.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_003_ENTITY01_SEG-AddTablasTmpRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_003_ENTITY01_SEG-AddTablasTmpRevision.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql" "20150721" "REM01" "KO" ""
	      echo "@KO@: DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql" "20150721" "REM01" "OK" ""
	      echo " OK : DDL_003_ENTITY01_SEG-AddTablasTmpRevision.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion-REM01-reg3.1.sql > DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_CrearRelacionCategoriasTipoResolucion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql 20150624 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150624" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO-REM01-reg3.1.sql > DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql" "20150624" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql" "20150624" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_CREATE_TABLE_DD_PCO_DOC_ESTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento-REM01-reg3.1.sql > DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_005_ENTITY01_CrearRelacionCategoriasTareasProcedimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql 20150624 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150624" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO-REM01-reg3.1.sql > DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "20150624" "REM01" "KO" ""
	      echo "@KO@: DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "20150624" "REM01" "OK" ""
	      echo " OK : DDL_005_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_005_ENTITY01_SEG_PRODUCTO_65.sql 20150811 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_005_ENTITY01_SEG_PRODUCTO_65.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_005_ENTITY01_SEG_PRODUCTO_65.sql" "REM01" "ALBERTO_RAMIREZ" "online"  "9.1" "20150811" "PRODUCTO-65" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_005_ENTITY01_SEG_PRODUCTO_65.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_005_ENTITY01_SEG_PRODUCTO_65.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_005_ENTITY01_SEG_PRODUCTO_65-REM01-reg3.1.sql > DDL_005_ENTITY01_SEG_PRODUCTO_65.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_005_ENTITY01_SEG_PRODUCTO_65.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_005_ENTITY01_SEG_PRODUCTO_65.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_SEG_PRODUCTO_65.sql" "20150811" "REM01" "KO" ""
	      echo "@KO@: DDL_005_ENTITY01_SEG_PRODUCTO_65.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_SEG_PRODUCTO_65.sql" "20150811" "REM01" "OK" ""
	      echo " OK : DDL_005_ENTITY01_SEG_PRODUCTO_65.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_006_ENTITY01_CrearDespachoExternoConfig.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_006_ENTITY01_CrearDespachoExternoConfig.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_006_ENTITY01_CrearDespachoExternoConfig.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_006_ENTITY01_CrearDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_006_ENTITY01_CrearDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_006_ENTITY01_CrearDespachoExternoConfig-REM01-reg3.1.sql > DDL_006_ENTITY01_CrearDespachoExternoConfig.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_006_ENTITY01_CrearDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_006_ENTITY01_CrearDespachoExternoConfig.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_CrearDespachoExternoConfig.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_006_ENTITY01_CrearDespachoExternoConfig.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_CrearDespachoExternoConfig.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_006_ENTITY01_CrearDespachoExternoConfig.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql 20150624 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150624" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR-REM01-reg3.1.sql > DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "20150624" "REM01" "KO" ""
	      echo "@KO@: DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "20150624" "REM01" "OK" ""
	      echo " OK : DDL_006_ENTITY01_CREATE_TABLE_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_006_ENTITY01_SEG_PRODUCTO_188.sql 20150824 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_006_ENTITY01_SEG_PRODUCTO_188.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_006_ENTITY01_SEG_PRODUCTO_188.sql" "REM01" "ALBERTO_RAMIREZ" "online"  "9.1" "20150824" "PRODUCTO-188" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_006_ENTITY01_SEG_PRODUCTO_188.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_006_ENTITY01_SEG_PRODUCTO_188.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_006_ENTITY01_SEG_PRODUCTO_188-REM01-reg3.1.sql > DDL_006_ENTITY01_SEG_PRODUCTO_188.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_006_ENTITY01_SEG_PRODUCTO_188.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_006_ENTITY01_SEG_PRODUCTO_188.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_SEG_PRODUCTO_188.sql" "20150824" "REM01" "KO" ""
	      echo "@KO@: DDL_006_ENTITY01_SEG_PRODUCTO_188.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_SEG_PRODUCTO_188.sql" "20150824" "REM01" "OK" ""
	      echo " OK : DDL_006_ENTITY01_SEG_PRODUCTO_188.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_007_ENTITY01_AlterResResolucionesMasivo.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_007_ENTITY01_AlterResResolucionesMasivo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_007_ENTITY01_AlterResResolucionesMasivo.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_007_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_007_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_007_ENTITY01_AlterResResolucionesMasivo-REM01-reg3.1.sql > DDL_007_ENTITY01_AlterResResolucionesMasivo.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_007_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_007_ENTITY01_AlterResResolucionesMasivo.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_AlterResResolucionesMasivo.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DDL_007_ENTITY01_AlterResResolucionesMasivo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_AlterResResolucionesMasivo.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DDL_007_ENTITY01_AlterResResolucionesMasivo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO-REM01-reg3.1.sql > DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_007_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_ESTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_008_ENTITY01_AlterCategoriasFK.sql 20150617 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_008_ENTITY01_AlterCategoriasFK.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_008_ENTITY01_AlterCategoriasFK.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150617" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_008_ENTITY01_AlterCategoriasFK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_008_ENTITY01_AlterCategoriasFK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_008_ENTITY01_AlterCategoriasFK-REM01-reg3.1.sql > DDL_008_ENTITY01_AlterCategoriasFK.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_008_ENTITY01_AlterCategoriasFK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_008_ENTITY01_AlterCategoriasFK.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_008_ENTITY01_AlterCategoriasFK.sql" "20150617" "REM01" "KO" ""
	      echo "@KO@: DDL_008_ENTITY01_AlterCategoriasFK.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_008_ENTITY01_AlterCategoriasFK.sql" "20150617" "REM01" "OK" ""
	      echo " OK : DDL_008_ENTITY01_AlterCategoriasFK.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO-REM01-reg3.1.sql > DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_008_ENTITY01_CREATE_TABLE_DD_PCO_BUR_ESTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_009_ENTITY01_AlterTiposResolucion.sql 20150617 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_009_ENTITY01_AlterTiposResolucion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_009_ENTITY01_AlterTiposResolucion.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150617" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_009_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_009_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_009_ENTITY01_AlterTiposResolucion-REM01-reg3.1.sql > DDL_009_ENTITY01_AlterTiposResolucion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_009_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_009_ENTITY01_AlterTiposResolucion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_009_ENTITY01_AlterTiposResolucion.sql" "20150617" "REM01" "KO" ""
	      echo "@KO@: DDL_009_ENTITY01_AlterTiposResolucion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_009_ENTITY01_AlterTiposResolucion.sql" "20150617" "REM01" "OK" ""
	      echo " OK : DDL_009_ENTITY01_AlterTiposResolucion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO-REM01-reg3.1.sql > DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_009_ENTITY01_CREATE_TABLE_DD_PCO_BUR_RESULTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_010_ENTITY01_CrearProcuradores.sql 20150618 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_010_ENTITY01_CrearProcuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_010_ENTITY01_CrearProcuradores.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150618" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_010_ENTITY01_CrearProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_010_ENTITY01_CrearProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_010_ENTITY01_CrearProcuradores-REM01-reg3.1.sql > DDL_010_ENTITY01_CrearProcuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_010_ENTITY01_CrearProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_010_ENTITY01_CrearProcuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_010_ENTITY01_CrearProcuradores.sql" "20150618" "REM01" "KO" ""
	      echo "@KO@: DDL_010_ENTITY01_CrearProcuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_010_ENTITY01_CrearProcuradores.sql" "20150618" "REM01" "OK" ""
	      echo " OK : DDL_010_ENTITY01_CrearProcuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO-REM01-reg3.1.sql > DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_010_ENTITY01_CREATE_TABLE_DD_PCO_BUR_TIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_011_ENTITY01_CrearProcuradorProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_011_ENTITY01_CrearProcuradorProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_011_ENTITY01_CrearProcuradorProcedimiento-REM01-reg3.1.sql > DDL_011_ENTITY01_CrearProcuradorProcedimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_011_ENTITY01_CrearProcuradorProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_011_ENTITY01_CrearProcuradorProcedimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_011_ENTITY01_CrearProcuradorProcedimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS-REM01-reg3.1.sql > DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_011_ENTITY01_CREATE_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_012_ENTITY01_AlterResResolucionesMasivo.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_012_ENTITY01_AlterResResolucionesMasivo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_012_ENTITY01_AlterResResolucionesMasivo.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_012_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_012_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_012_ENTITY01_AlterResResolucionesMasivo-REM01-reg3.1.sql > DDL_012_ENTITY01_AlterResResolucionesMasivo.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_012_ENTITY01_AlterResResolucionesMasivo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_012_ENTITY01_AlterResResolucionesMasivo.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_012_ENTITY01_AlterResResolucionesMasivo.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_012_ENTITY01_AlterResResolucionesMasivo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_012_ENTITY01_AlterResResolucionesMasivo.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_012_ENTITY01_AlterResResolucionesMasivo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql 20150625 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150625" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS-REM01-reg3.1.sql > DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql" "20150625" "REM01" "KO" ""
	      echo "@KO@: DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql" "20150625" "REM01" "OK" ""
	      echo " OK : DDL_012_ENTITY01_CREATE_TABLE_PCO_DOC_DOCUMENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_013_ENTITY01_CrearSociedadProcuradores.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_013_ENTITY01_CrearSociedadProcuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_013_ENTITY01_CrearSociedadProcuradores.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_013_ENTITY01_CrearSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_013_ENTITY01_CrearSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_013_ENTITY01_CrearSociedadProcuradores-REM01-reg3.1.sql > DDL_013_ENTITY01_CrearSociedadProcuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_013_ENTITY01_CrearSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_013_ENTITY01_CrearSociedadProcuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_013_ENTITY01_CrearSociedadProcuradores.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_013_ENTITY01_CrearSociedadProcuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_013_ENTITY01_CrearSociedadProcuradores.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_013_ENTITY01_CrearSociedadProcuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql 20150625 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql" "REM01" "AGUSTIN MOMPO" "web"  "9.1" "20150625" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES-REM01-reg3.1.sql > DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql" "20150625" "REM01" "KO" ""
	      echo "@KO@: DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql" "20150625" "REM01" "OK" ""
	      echo " OK : DDL_013_ENTITY01_CREATE_TABLE_PCO_DOC_SOLICITUDES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_014_ENTITY01_CrearProcuSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_014_ENTITY01_CrearProcuSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_014_ENTITY01_CrearProcuSociedadProcuradores-REM01-reg3.1.sql > DDL_014_ENTITY01_CrearProcuSociedadProcuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_014_ENTITY01_CrearProcuSociedadProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_014_ENTITY01_CrearProcuSociedadProcuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_014_ENTITY01_CrearProcuSociedadProcuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION-REM01-reg3.1.sql > DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_014_ENTITY01_CREATE_TABLE_PCO_LIQ_LIQUIDACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_015_ENTITY01_AlterTiposResolucion.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_015_ENTITY01_AlterTiposResolucion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_015_ENTITY01_AlterTiposResolucion.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_015_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_015_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_015_ENTITY01_AlterTiposResolucion-REM01-reg3.1.sql > DDL_015_ENTITY01_AlterTiposResolucion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_015_ENTITY01_AlterTiposResolucion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_015_ENTITY01_AlterTiposResolucion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_015_ENTITY01_AlterTiposResolucion.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_015_ENTITY01_AlterTiposResolucion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_015_ENTITY01_AlterTiposResolucion.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_015_ENTITY01_AlterTiposResolucion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX-REM01-reg3.1.sql > DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_015_ENTITY01_CREATE_TABLE_PCO_BUR_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_016_ENTITY01_CrearCamposDinamicosHistorico.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_016_ENTITY01_CrearCamposDinamicosHistorico.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_016_ENTITY01_CrearCamposDinamicosHistorico-REM01-reg3.1.sql > DDL_016_ENTITY01_CrearCamposDinamicosHistorico.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_016_ENTITY01_CrearCamposDinamicosHistorico.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_016_ENTITY01_CrearCamposDinamicosHistorico.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_016_ENTITY01_CrearCamposDinamicosHistorico.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql 24-06-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "24-06-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO-REM01-reg3.1.sql > DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql" "24-06-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql" "24-06-2015" "REM01" "OK" ""
	      echo " OK : DDL_016_ENTITY01_CREATE_TABLE_PCO_BUR_ENVIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql 20150702 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150702" "PRODUCTO-88" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE-REM01-reg3.1.sql > DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql" "20150702" "REM01" "KO" ""
	      echo "@KO@: DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql" "20150702" "REM01" "OK" ""
	      echo " OK : DDL_016_HAYA01_VTAR_TAREA_VS_USUARIO_EXPE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_017_ENTITY01_CrearResolucionesCategoria.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_017_ENTITY01_CrearResolucionesCategoria.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_017_ENTITY01_CrearResolucionesCategoria.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_017_ENTITY01_CrearResolucionesCategoria.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_017_ENTITY01_CrearResolucionesCategoria.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_017_ENTITY01_CrearResolucionesCategoria-REM01-reg3.1.sql > DDL_017_ENTITY01_CrearResolucionesCategoria.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_017_ENTITY01_CrearResolucionesCategoria.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_017_ENTITY01_CrearResolucionesCategoria.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_017_ENTITY01_CrearResolucionesCategoria.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_017_ENTITY01_CrearResolucionesCategoria.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_017_ENTITY01_CrearResolucionesCategoria.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_017_ENTITY01_CrearResolucionesCategoria.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql 20150630 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql" "REM01" "AGSUTIN MOMPO" "web"  "9.1" "20150630" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP-REM01-reg3.1.sql > DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql" "20150630" "REM01" "KO" ""
	      echo "@KO@: DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql" "20150630" "REM01" "OK" ""
	      echo " OK : DDL_017_ENTITY01_CREATE_TABLE_PCO_PRC_HEP_HISTOR_EST_PREP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_018_ENTITY01_AlterDecDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_018_ENTITY01_AlterDecDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_018_ENTITY01_AlterDecDespachoExternoConfig-REM01-reg3.1.sql > DDL_018_ENTITY01_AlterDecDespachoExternoConfig.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_018_ENTITY01_AlterDecDespachoExternoConfig.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_018_ENTITY01_AlterDecDespachoExternoConfig.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_018_ENTITY01_AlterDecDespachoExternoConfig.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql 20150603 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql" "REM01" "G ESTELLES" "web"  "9.1" "20150603" "-" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_018_ENTITY01_CreaCampos_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_018_ENTITY01_CreaCampos_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_018_ENTITY01_CreaCampos_SYS_GUID-REM01-reg3.1.sql > DDL_018_ENTITY01_CreaCampos_SYS_GUID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_018_ENTITY01_CreaCampos_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_018_ENTITY01_CreaCampos_SYS_GUID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql" "20150603" "REM01" "KO" ""
	      echo "@KO@: DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql" "20150603" "REM01" "OK" ""
	      echo " OK : DDL_018_ENTITY01_CreaCampos_SYS_GUID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql 14-07-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "14-07-2015" "PRODUCTO-145" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR-REM01-reg3.1.sql > DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql" "14-07-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql" "14-07-2015" "REM01" "OK" ""
	      echo " OK : DDL_018_ENTITY01_CREATE_TABLE_TPO_TPE_TIPO_BUR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql 20150722 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql" "REM01" "PBLASCO" "web"  "9.1" "20150722" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA-REM01-reg3.1.sql > DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql" "20150722" "REM01" "KO" ""
	      echo "@KO@: DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql" "20150722" "REM01" "OK" ""
	      echo " OK : DDL_019_ENTITY01_CREATE_TABLE_DD_SNN_SINONOAPLICA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql" "REM01" "G ESTELLES" "web"  "9.1" "20150902" "-" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_019_ENTITY01_Modifica_SYS_GUID_a_32-REM01-reg3.1.sql > DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_019_ENTITY01_Modifica_SYS_GUID_a_32.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql 20150722 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql" "REM01" "PBLASCO" "web"  "9.1" "20150722" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS-REM01-reg3.1.sql > DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql" "20150722" "REM01" "KO" ""
	      echo "@KO@: DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql" "20150722" "REM01" "OK" ""
	      echo " OK : DDL_020_ENTITY01_ALTER_TABLE_PCO_DOC_DOCUMENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_021_ENTITY01_CrearRecordatorios.sql 20150623 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_021_ENTITY01_CrearRecordatorios.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_021_ENTITY01_CrearRecordatorios.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150623" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_021_ENTITY01_CrearRecordatorios.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_021_ENTITY01_CrearRecordatorios.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_021_ENTITY01_CrearRecordatorios-REM01-reg3.1.sql > DDL_021_ENTITY01_CrearRecordatorios.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_021_ENTITY01_CrearRecordatorios.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_021_ENTITY01_CrearRecordatorios.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_021_ENTITY01_CrearRecordatorios.sql" "20150623" "REM01" "KO" ""
	      echo "@KO@: DDL_021_ENTITY01_CrearRecordatorios.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_021_ENTITY01_CrearRecordatorios.sql" "20150623" "REM01" "OK" ""
	      echo " OK : DDL_021_ENTITY01_CrearRecordatorios.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql 20150706 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150706" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_023_ENTITY01_CrearVistaBusquedaAsuTram-REM01-reg3.1.sql > DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql" "20150706" "REM01" "KO" ""
	      echo "@KO@: DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql" "20150706" "REM01" "OK" ""
	      echo " OK : DDL_023_ENTITY01_CrearVistaBusquedaAsuTram.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql 22-07-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "22-07-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX-REM01-reg3.1.sql > DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql" "22-07-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql" "22-07-2015" "REM01" "OK" ""
	      echo " OK : DDL_028_ENTITY01_CREATE_TABLE_ENVIOS_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql 31-08-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "31-08-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX-REM01-reg3.1.sql > DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql" "31-08-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql" "31-08-2015" "REM01" "OK" ""
	      echo " OK : DDL_029_ENTITY01_ALTER_TABLE_CONTENIDO_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql 20150703 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql" "REM01" "PedroB" "online"  "9.2.2" "20150703" "CIERRE_DEUDAS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO-REM01-reg3.1.sql > DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql" "20150703" "REM01" "KO" ""
	      echo "@KO@: DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql" "20150703" "REM01" "OK" ""
	      echo " OK : DDL_030_BANK01_ACTUALIZAR_CDD_ASUNTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql 20150904 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "20150904" "PRODUCTO-194" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES-REM01-reg3.1.sql > DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "20150904" "REM01" "KO" ""
	      echo "@KO@: DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "20150904" "REM01" "OK" ""
	      echo " OK : DDL_030_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql 20150909 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "20150909" "Producto-95" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES-REM01-reg3.1.sql > DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "20150909" "REM01" "KO" ""
	      echo "@KO@: DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "20150909" "REM01" "OK" ""
	      echo " OK : DDL_031_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql 20151116 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "REM01" "Alberto Campos" "online"  "9.1.0-X" "20151116" "PRODUCTO-422" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES-REM01-reg3.1.sql > DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "20151116" "REM01" "KO" ""
	      echo "@KO@: DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql" "20151116" "REM01" "OK" ""
	      echo " OK : DDL_032_ENTITY01_ALTER_TABLE_PCO_LIQ_LIQUIDACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_032_ENTITY01_ModificacionTablaPersonas.sql 20160104 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_032_ENTITY01_ModificacionTablaPersonas.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_032_ENTITY01_ModificacionTablaPersonas.sql" "REM01" "Alberto Campos" "online"  "9.1.0-cj-rc36" "20160104" "CMREC-1722" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_032_ENTITY01_ModificacionTablaPersonas.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_032_ENTITY01_ModificacionTablaPersonas.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_032_ENTITY01_ModificacionTablaPersonas-REM01-reg3.1.sql > DDL_032_ENTITY01_ModificacionTablaPersonas.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_032_ENTITY01_ModificacionTablaPersonas.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_032_ENTITY01_ModificacionTablaPersonas.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_ModificacionTablaPersonas.sql" "20160104" "REM01" "KO" ""
	      echo "@KO@: DDL_032_ENTITY01_ModificacionTablaPersonas.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_ModificacionTablaPersonas.sql" "20160104" "REM01" "OK" ""
	      echo " OK : DDL_032_ENTITY01_ModificacionTablaPersonas.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql 20150820 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql" "REM01" "Alberto Campos" "online"  "1.3.13_rc01" "20150820" "CMREC-418" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_036_ENTITY01_InsertColumnaFechaVencimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_036_ENTITY01_InsertColumnaFechaVencimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_036_ENTITY01_InsertColumnaFechaVencimiento-REM01-reg3.1.sql > DDL_036_ENTITY01_InsertColumnaFechaVencimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_036_ENTITY01_InsertColumnaFechaVencimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_036_ENTITY01_InsertColumnaFechaVencimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql" "20150820" "REM01" "KO" ""
	      echo "@KO@: DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql" "20150820" "REM01" "OK" ""
	      echo " OK : DDL_036_ENTITY01_InsertColumnaFechaVencimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150729" "PRODUCTO-88" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1-REM01-reg3.1.sql > DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DDL_036_HAYA01_VTAR_TAREA_VS_USUARIO_PART1.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150729" "PRODUCTO-88" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2-REM01-reg3.1.sql > DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DDL_037_HAYA01_VTAR_TAREA_VS_USUARIO_PART2.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql 20150819 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150819" "PRODUCTO-88" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150819" "REM01" "KO" ""
	      echo "@KO@: DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150819" "REM01" "OK" ""
	      echo " OK : DDL_038_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql 20150820 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150820" "PRODUCTO-58" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION-REM01-reg3.1.sql > DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql" "20150820" "REM01" "KO" ""
	      echo "@KO@: DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql" "20150820" "REM01" "OK" ""
	      echo " OK : DDL_039_HAYA01_DEL_UK_REGLAS_ELEVACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql 20150728 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150728" "PRODUCTO-158" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento-REM01-reg3.1.sql > DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql" "20150728" "REM01" "KO" ""
	      echo "@KO@: DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql" "20150728" "REM01" "OK" ""
	      echo " OK : DDL_040_ENTITY01_AlterAcuAcuerdoProcedimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql 20150824 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150824" "PRODUCTO-49" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS-REM01-reg3.1.sql > DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql" "20150824" "REM01" "KO" ""
	      echo "@KO@: DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql" "20150824" "REM01" "OK" ""
	      echo " OK : DDL_040_HAYA01_ADD_MRA_ID_ARQ_ARQUETIPOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql 20150728 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150728" "PRODUCTO-159" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_041_ENTITY01_CrearSubtipoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_041_ENTITY01_CrearSubtipoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_041_ENTITY01_CrearSubtipoAcuerdo-REM01-reg3.1.sql > DDL_041_ENTITY01_CrearSubtipoAcuerdo.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_041_ENTITY01_CrearSubtipoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_041_ENTITY01_CrearSubtipoAcuerdo.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql" "20150728" "REM01" "KO" ""
	      echo "@KO@: DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql" "20150728" "REM01" "OK" ""
	      echo " OK : DDL_041_ENTITY01_CrearSubtipoAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql 20150826 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150826" "PRODUCTO-192" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ-REM01-reg3.1.sql > DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql" "20150826" "REM01" "KO" ""
	      echo "@KO@: DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql" "20150826" "REM01" "OK" ""
	      echo " OK : DDL_041_HAYA01_VTAR_TAREA_VS_USUARIO_OBJ.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150729" "PRODUCTO-159" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO-REM01-reg3.1.sql > DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DDL_042_ENTITY01_FK_TERMINOS_ACUERDO_SUBTIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql 20150827 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150827" "PRODUCTO-192" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150827" "REM01" "KO" ""
	      echo "@KO@: DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150827" "REM01" "OK" ""
	      echo " OK : DDL_042_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql 20150803 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150803" "PRODUCTO-173" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos-REM01-reg3.1.sql > DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql" "20150803" "REM01" "KO" ""
	      echo "@KO@: DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql" "20150803" "REM01" "OK" ""
	      echo " OK : DDL_043_ENTITY01_CrearAcuerdoOperacionesTerminos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql 20150908 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150908" "PRODUCTO-224" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN-REM01-reg3.1.sql > DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql" "20150908" "REM01" "KO" ""
	      echo "@KO@: DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql" "20150908" "REM01" "OK" ""
	      echo " OK : DDL_043_HAYA01_INSTALL_ITINERARIOS_PLUGIN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql 20150803 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150803" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_044_ENTITY01_CaposTipoAcuerdoTerminos-REM01-reg3.1.sql > DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql" "20150803" "REM01" "KO" ""
	      echo "@KO@: DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql" "20150803" "REM01" "OK" ""
	      echo " OK : DDL_044_ENTITY01_CaposTipoAcuerdoTerminos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql 20150910 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150910" "PRODUCTO-49" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO-REM01-reg3.1.sql > DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql" "20150910" "REM01" "KO" ""
	      echo "@KO@: DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql" "20150910" "REM01" "OK" ""
	      echo " OK : DDL_044_HAYA01_ADD_MRA_PLAZO_DISPARO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql 20150708 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.12-bk" "20150708" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD-REM01-reg3.1.sql > DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql" "20150708" "REM01" "KO" ""
	      echo "@KO@: DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql" "20150708" "REM01" "OK" ""
	      echo " OK : DDL_045_BANK01_CREAR_DICCIONARIO_RES_VAL_CDD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql 20150708 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql" "REM01" "Manuel Mejias" "online"  "9.1.3-hy-rc01" "20150708" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA-REM01-reg3.1.sql > DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql" "20150708" "REM01" "KO" ""
	      echo "@KO@: DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql" "20150708" "REM01" "OK" ""
	      echo " OK : DDL_046_BANK01_ALTER_TABLE_BATCH_CIERRE_DEUDA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql 20150711 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.12-bk" "20150711" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE-REM01-reg3.1.sql > DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql" "20150711" "REM01" "KO" ""
	      echo "@KO@: DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql" "20150711" "REM01" "OK" ""
	      echo " OK : DDL_048_BANK01_CREAR_DICCIONARIO_RES_VAL_NUSE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql 20150914 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql" "REM01" "CARLOS PEREZ	" "batch"  "9.1" "20150914" "PRODUCTO-255" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255-REM01-reg3.1.sql > DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql" "20150914" "REM01" "KO" ""
	      echo "@KO@: DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql" "20150914" "REM01" "OK" ""
	      echo " OK : DDL_050_ENTITY01_CrearTabla_H_ARR-PRODUCTO_255.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql 20150717 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.12-bk" "20150717" "FASE-1062" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_055_BANK01_RERA_PRECAL_ARQUET_1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_055_BANK01_RERA_PRECAL_ARQUET_1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_055_BANK01_RERA_PRECAL_ARQUET_1-REM01-reg3.1.sql > DDL_055_BANK01_RERA_PRECAL_ARQUET_1.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_055_BANK01_RERA_PRECAL_ARQUET_1.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_055_BANK01_RERA_PRECAL_ARQUET_1.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql" "20150717" "REM01" "KO" ""
	      echo "@KO@: DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql" "20150717" "REM01" "OK" ""
	      echo " OK : DDL_055_BANK01_RERA_PRECAL_ARQUET_1.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql 20150717 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.12-bk" "20150717" "BCFI-670" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE-REM01-reg3.1.sql > DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql" "20150717" "REM01" "KO" ""
	      echo "@KO@: DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql" "20150717" "REM01" "OK" ""
	      echo " OK : DDL_056_BANK01_REFRESH_DATA_RULE_ENGINE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150902" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos-REM01-reg3.1.sql > DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_057_ENTITY01_ConfiguracionAcuerdosAsuntos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql 20150828 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150828" "PRODUCTO-130" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA-REM01-reg3.1.sql > DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20150828" "REM01" "KO" ""
	      echo "@KO@: DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20150828" "REM01" "OK" ""
	      echo " OK : DDL_057_ENTITY01_CREATE_TABLE_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql 20150728 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150728" "PRODUCTO-158" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento-REM01-reg3.1.sql > DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql" "20150728" "REM01" "KO" ""
	      echo "@KO@: DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql" "20150728" "REM01" "OK" ""
	      echo " OK : DDL_058_ENTITY01_AddColumnAcuAcuerdoProcedimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150902" "PRODUCTO-236" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO-REM01-reg3.1.sql > DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_058_ENTITY01_CREATE_TABLE_CNV_AUX_ALTA_PCO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "REM01" "PEDROBLASCO" "web"  "9.1" "20150902" "PRODUCTO-236" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD-REM01-reg3.1.sql > DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_059_ENTITY01_CREATE_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql 20150911 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "20150911" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC-REM01-reg3.1.sql > DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql" "20150911" "REM01" "KO" ""
	      echo "@KO@: DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql" "20150911" "REM01" "OK" ""
	      echo " OK : DDL_060_ENTITY01_CREATE_TABLE_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO-REM01-reg3.1.sql > DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DDL_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_064_MASTER_DD_CCA_COMUNIDAD.sql 20151013 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_064_MASTER_DD_CCA_COMUNIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_064_MASTER_DD_CCA_COMUNIDAD.sql" "REMMASTER" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_064_MASTER_DD_CCA_COMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_064_MASTER_DD_CCA_COMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_064_MASTER_DD_CCA_COMUNIDAD-REMMASTER-reg3.1.sql > DDL_064_MASTER_DD_CCA_COMUNIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_064_MASTER_DD_CCA_COMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_064_MASTER_DD_CCA_COMUNIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_064_MASTER_DD_CCA_COMUNIDAD.sql" "20151013" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_064_MASTER_DD_CCA_COMUNIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_064_MASTER_DD_CCA_COMUNIDAD.sql" "20151013" "REMMASTER" "OK" ""
	      echo " OK : DDL_064_MASTER_DD_CCA_COMUNIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql 20151013 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql" "REMMASTER" "ALBERTO CAMPOS" "online"  "9.1.3" "20151013" "HR-970" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA-REMMASTER-reg3.1.sql > DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql" "20151013" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql" "20151013" "REMMASTER" "OK" ""
	      echo " OK : DDL_065_MASTER_ALTER_DD_PRV_PROVINCIA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION-REM01-reg3.1.sql > DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DDL_066_ENTITY01_DAA_DESPACHO_AMBITO_ACTUACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO-REM01-reg3.1.sql > DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DDL_067_ENTITY01_ETU_ESQUEMA_TURNADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG-REM01-reg3.1.sql > DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DDL_068_ENTITY01_ETC_ESQUEMA_TURNADO_CONFIG.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.3" "20151013" "HR-970" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO-REM01-reg3.1.sql > DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DDL_069_ENTITY01_ALTER_DES_DESPACHO_EXTERNO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql 20151014 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.4" "20151014" "BCFI-589" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO-REM01-reg3.1.sql > DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql" "20151014" "REM01" "KO" ""
	      echo "@KO@: DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql" "20151014" "REM01" "OK" ""
	      echo " OK : DDL_070_ENTITY01_TMP_AAT_ASIG_TURNADO_LETRADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_071_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO.sql" "REM01" "ALBERTO CAMPOS" "producto"  "9.1.13" "20151116" "BKREC-901" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_071_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO-REM01-reg3.1.sql > DDL_071_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO.log
echo " -- : DDL_071_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1" "20150916" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS-REM01-reg3.1.sql > DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DDL_071_HAYA01_VTAR_TAREA_VS_USUARIO_ACUERDOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1" "20150916" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DDL_072_HAYA01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql 20150915 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150915" "PRODUCTO-158" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento-REM01-reg3.1.sql > DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql" "20150915" "REM01" "KO" ""
	      echo "@KO@: DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql" "20150915" "REM01" "OK" ""
	      echo " OK : DDL_073_ENTITY01_Add_USD_AcuAcuerdoProcedimiento.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_074_BANK01_BKREC_943.sql 20151015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_074_BANK01_BKREC_943.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_074_BANK01_BKREC_943.sql" "REM01" "JORGE ROS" "online"  "9.1.16-bk" "20151015" "BKREC-943" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_074_BANK01_BKREC_943.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_074_BANK01_BKREC_943.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_074_BANK01_BKREC_943-REM01-reg3.1.sql > DDL_074_BANK01_BKREC_943.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_074_BANK01_BKREC_943.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_074_BANK01_BKREC_943.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_074_BANK01_BKREC_943.sql" "20151015" "REM01" "KO" ""
	      echo "@KO@: DDL_074_BANK01_BKREC_943.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_074_BANK01_BKREC_943.sql" "20151015" "REM01" "OK" ""
	      echo " OK : DDL_074_BANK01_BKREC_943.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_074_ENTITY01_DropAcuerdosAsuntos.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_074_ENTITY01_DropAcuerdosAsuntos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_074_ENTITY01_DropAcuerdosAsuntos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150902" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_074_ENTITY01_DropAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_074_ENTITY01_DropAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_074_ENTITY01_DropAcuerdosAsuntos-REM01-reg3.1.sql > DDL_074_ENTITY01_DropAcuerdosAsuntos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_074_ENTITY01_DropAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_074_ENTITY01_DropAcuerdosAsuntos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_074_ENTITY01_DropAcuerdosAsuntos.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_074_ENTITY01_DropAcuerdosAsuntos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_074_ENTITY01_DropAcuerdosAsuntos.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_074_ENTITY01_DropAcuerdosAsuntos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql 20151014 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151014" "BKREC-1099" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_075_BANK01_BI_FACTU_ADD_CPAID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_075_BANK01_BI_FACTU_ADD_CPAID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_075_BANK01_BI_FACTU_ADD_CPAID-REM01-reg3.1.sql > DDL_075_BANK01_BI_FACTU_ADD_CPAID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_075_BANK01_BI_FACTU_ADD_CPAID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_075_BANK01_BI_FACTU_ADD_CPAID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql" "20151014" "REM01" "KO" ""
	      echo "@KO@: DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql" "20151014" "REM01" "OK" ""
	      echo " OK : DDL_075_BANK01_BI_FACTU_ADD_CPAID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql 20150902 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150902" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos-REM01-reg3.1.sql > DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql" "20150902" "REM01" "KO" ""
	      echo "@KO@: DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql" "20150902" "REM01" "OK" ""
	      echo " OK : DDL_075_ENTITY01_CreateConfiguracionAcuerdosAsuntos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_076_BANK01_INM_INMUNIDAD.sql 20151023 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_076_BANK01_INM_INMUNIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_076_BANK01_INM_INMUNIDAD.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.16-bk" "20151023" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_076_BANK01_INM_INMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_076_BANK01_INM_INMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_076_BANK01_INM_INMUNIDAD-REM01-reg3.1.sql > DDL_076_BANK01_INM_INMUNIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_076_BANK01_INM_INMUNIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_076_BANK01_INM_INMUNIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_076_BANK01_INM_INMUNIDAD.sql" "20151023" "REM01" "KO" ""
	      echo "@KO@: DDL_076_BANK01_INM_INMUNIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_076_BANK01_INM_INMUNIDAD.sql" "20151023" "REM01" "OK" ""
	      echo " OK : DDL_076_BANK01_INM_INMUNIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql" "REM01" "PEDROBLASCOS" "online"  "9.1.0-X" "20150916" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS-REM01-reg3.1.sql > DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DDL_076_ENTITY01_AlterACU_ACUERDO_PROCEDIMIENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql" "REM01" "RAFAEL ARACIL LOPEZ  " "load_ficheros_fsr"  "9.1.17-bk" "20151110" "BKREC-1417" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_077_BANK01_CREATE_GEST_HIPOTECARIA-REM01-reg3.1.sql > DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_077_BANK01_CREATE_GEST_HIPOTECARIA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql 20150917 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20150917" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_077_ENTITY01_ConfigActuacionesAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_077_ENTITY01_ConfigActuacionesAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_077_ENTITY01_ConfigActuacionesAcuerdos-REM01-reg3.1.sql > DDL_077_ENTITY01_ConfigActuacionesAcuerdos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_077_ENTITY01_ConfigActuacionesAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_077_ENTITY01_ConfigActuacionesAcuerdos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql" "20150917" "REM01" "KO" ""
	      echo "@KO@: DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql" "20150917" "REM01" "OK" ""
	      echo " OK : DDL_077_ENTITY01_ConfigActuacionesAcuerdos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_078_BANK01_TMP_CICLOS_AUX_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_078_BANK01_TMP_CICLOS_AUX_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_078_BANK01_TMP_CICLOS_AUX_ALL-REM01-reg3.1.sql > DDL_078_BANK01_TMP_CICLOS_AUX_ALL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_078_BANK01_TMP_CICLOS_AUX_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_078_BANK01_TMP_CICLOS_AUX_ALL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_078_BANK01_TMP_CICLOS_AUX_ALL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql 02-10-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql" "REM01" "VICENTE LOZANO" "web"  "9.1" "02-10-2015" "PRODUCTO-288" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO-REM01-reg3.1.sql > DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql" "02-10-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql" "02-10-2015" "REM01" "OK" ""
	      echo " OK : DDL_078_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION_PEDRO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_BANK01_TMP_PER_ARQ_PRI.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_BANK01_TMP_PER_ARQ_PRI.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_BANK01_TMP_PER_ARQ_PRI.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_079_BANK01_TMP_PER_ARQ_PRI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_079_BANK01_TMP_PER_ARQ_PRI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_BANK01_TMP_PER_ARQ_PRI-REM01-reg3.1.sql > DDL_079_BANK01_TMP_PER_ARQ_PRI.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_079_BANK01_TMP_PER_ARQ_PRI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_079_BANK01_TMP_PER_ARQ_PRI.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_BANK01_TMP_PER_ARQ_PRI.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_079_BANK01_TMP_PER_ARQ_PRI.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_BANK01_TMP_PER_ARQ_PRI.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_079_BANK01_TMP_PER_ARQ_PRI.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql 20151027 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.8" "20151027" "CMREC-884" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID-REM01-reg3.1.sql > DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql" "20151027" "REM01" "KO" ""
	      echo "@KO@: DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql" "20151027" "REM01" "OK" ""
	      echo " OK : DDL_079_ENTITY01_ALTER_TABLE_SYS_GUID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql 28-09-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "28-09-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP-REM01-reg3.1.sql > DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql" "28-09-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql" "28-09-2015" "REM01" "OK" ""
	      echo " OK : DDL_079_ENTITY01_CREATE_TABLE_AEE_ACTUACION_EXPLORAR_EXP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql 20151029 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql" "REM01" "MANUEL_MEJIAS" "web"  "9.1" "20151029" "BKREC-1325" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC-REM01-reg3.1.sql > DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql" "20151029" "REM01" "KO" ""
	      echo "@KO@: DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql" "20151029" "REM01" "OK" ""
	      echo " OK : DDL_079_ENTITY01_INSERT_SEQ_BUR_FICHERO_DOC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql 20150925 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql" "REMMASTER" "PEDROBLASCO" "online"  "9.1.3" "20150925" "PRODUCTO" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_079_MASTER_CrearDiccEstadoGestionTermino.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_079_MASTER_CrearDiccEstadoGestionTermino.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_MASTER_CrearDiccEstadoGestionTermino-REMMASTER-reg3.1.sql > DDL_079_MASTER_CrearDiccEstadoGestionTermino.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_079_MASTER_CrearDiccEstadoGestionTermino.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_079_MASTER_CrearDiccEstadoGestionTermino.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql" "20150925" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql" "20150925" "REMMASTER" "OK" ""
	      echo " OK : DDL_079_MASTER_CrearDiccEstadoGestionTermino.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_080_BANK01_TMP_CICLOS_ESC.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_080_BANK01_TMP_CICLOS_ESC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_080_BANK01_TMP_CICLOS_ESC.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_080_BANK01_TMP_CICLOS_ESC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_080_BANK01_TMP_CICLOS_ESC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_080_BANK01_TMP_CICLOS_ESC-REM01-reg3.1.sql > DDL_080_BANK01_TMP_CICLOS_ESC.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_080_BANK01_TMP_CICLOS_ESC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_080_BANK01_TMP_CICLOS_ESC.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_BANK01_TMP_CICLOS_ESC.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_080_BANK01_TMP_CICLOS_ESC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_BANK01_TMP_CICLOS_ESC.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_080_BANK01_TMP_CICLOS_ESC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql 20150929 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql" "REM01" "PEDROBLASCO" "online"  "9.1.0-X" "20150929" "PRODUCTO" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo-REM01-reg3.1.sql > DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql" "20150929" "REM01" "KO" ""
	      echo "@KO@: DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql" "20150929" "REM01" "OK" ""
	      echo " OK : DDL_080_ENTITY01_Add_EstadoGestion_TerminoAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql 02-10-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "02-10-2015" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP-REM01-reg3.1.sql > DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql" "02-10-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql" "02-10-2015" "REM01" "OK" ""
	      echo " OK : DDL_080_ENTITY01_CREATE_TABLE_ARE_ACTUACION_REALIZADAS_EXP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_081_BANK01_TMP_CICLOS_SCA_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_081_BANK01_TMP_CICLOS_SCA_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_081_BANK01_TMP_CICLOS_SCA_ALL-REM01-reg3.1.sql > DDL_081_BANK01_TMP_CICLOS_SCA_ALL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_081_BANK01_TMP_CICLOS_SCA_ALL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_081_BANK01_TMP_CICLOS_SCA_ALL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_081_BANK01_TMP_CICLOS_SCA_ALL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql 05-10-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql" "REM01" "JAVIER RUIZ" "web"  "9.1" "05-10-2015" "PRODUCTO-275" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO-REM01-reg3.1.sql > DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql" "05-10-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql" "05-10-2015" "REM01" "OK" ""
	      echo " OK : DDL_081_ENTITY01_DROP_UK_GAA_GESTOR_ADICIONAL_ASUNTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED-REM01-reg3.1.sql > DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_082_BANK01_TMP_CICLOS_SCA_SELECTED.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql 20151006 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "REM01" "CARLOS GIL" "online"  "9.1" "20151006" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT-REM01-reg3.1.sql > DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "20151006" "REM01" "KO" ""
	      echo "@KO@: DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "20151006" "REM01" "OK" ""
	      echo " OK : DDL_082_HAYA01_V2_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_083_BANK01_TMP_CICLOS.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_083_BANK01_TMP_CICLOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_083_BANK01_TMP_CICLOS.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_083_BANK01_TMP_CICLOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_083_BANK01_TMP_CICLOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_083_BANK01_TMP_CICLOS-REM01-reg3.1.sql > DDL_083_BANK01_TMP_CICLOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_083_BANK01_TMP_CICLOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_083_BANK01_TMP_CICLOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_083_BANK01_TMP_CICLOS.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_083_BANK01_TMP_CICLOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_083_BANK01_TMP_CICLOS.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_083_BANK01_TMP_CICLOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql 20151006 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151006" "PRODUCTO-290" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo-REM01-reg3.1.sql > DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql" "20151006" "REM01" "KO" ""
	      echo "@KO@: DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql" "20151006" "REM01" "OK" ""
	      echo " OK : DDL_083_ENTITY01_CrearDDMotivosRechazoAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_084_BANK01_TMP_EXPTES.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_084_BANK01_TMP_EXPTES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_084_BANK01_TMP_EXPTES.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_084_BANK01_TMP_EXPTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_084_BANK01_TMP_EXPTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_084_BANK01_TMP_EXPTES-REM01-reg3.1.sql > DDL_084_BANK01_TMP_EXPTES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_084_BANK01_TMP_EXPTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_084_BANK01_TMP_EXPTES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_084_BANK01_TMP_EXPTES.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_084_BANK01_TMP_EXPTES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_084_BANK01_TMP_EXPTES.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_084_BANK01_TMP_EXPTES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql 20151007 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql" "REM01" "CARLOS GIL GIMENO	" "online"  "9.1.0-X" "20151007" "PRODUCTO-290" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK-REM01-reg3.1.sql > DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql" "20151007" "REM01" "KO" ""
	      echo "@KO@: DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql" "20151007" "REM01" "OK" ""
	      echo " OK : DDL_084_ENTITY01_ACU_ACUERDO_PROCEDIMIENTOS_ADD_MOTIVORECHAZO_FK.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_085_BANK01_TMP_CANDIDATES.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_085_BANK01_TMP_CANDIDATES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_085_BANK01_TMP_CANDIDATES.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_085_BANK01_TMP_CANDIDATES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_085_BANK01_TMP_CANDIDATES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_085_BANK01_TMP_CANDIDATES-REM01-reg3.1.sql > DDL_085_BANK01_TMP_CANDIDATES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_085_BANK01_TMP_CANDIDATES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_085_BANK01_TMP_CANDIDATES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_BANK01_TMP_CANDIDATES.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_085_BANK01_TMP_CANDIDATES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_BANK01_TMP_CANDIDATES.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_085_BANK01_TMP_CANDIDATES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2.2" "20151021" "BKREC-1237" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO-REM01-reg3.1.sql > DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_085_ENTITY01_ACTUALIZAR_BFT_TIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql 20151015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "REM01" "CARLOS GIL" "online"  "9.1" "20151015" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT-REM01-reg3.1.sql > DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "20151015" "REM01" "KO" ""
	      echo "@KO@: DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql" "20151015" "REM01" "OK" ""
	      echo " OK : DDL_085_ENTITY01_VTAR_TAREA_VS_USUARIO_ACUERDOS_TAR_NOT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_086_BANK01_TMP_SELECTION.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_086_BANK01_TMP_SELECTION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_086_BANK01_TMP_SELECTION.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_086_BANK01_TMP_SELECTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_086_BANK01_TMP_SELECTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_086_BANK01_TMP_SELECTION-REM01-reg3.1.sql > DDL_086_BANK01_TMP_SELECTION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_086_BANK01_TMP_SELECTION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_086_BANK01_TMP_SELECTION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_086_BANK01_TMP_SELECTION.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_086_BANK01_TMP_SELECTION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_086_BANK01_TMP_SELECTION.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_086_BANK01_TMP_SELECTION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql 20151029 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql" "REM01" "MANUEL_MEJIAS" "web"  "9.1" "20151029" "PRODUCTO-366" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO-REM01-reg3.1.sql > DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql" "20151029" "REM01" "KO" ""
	      echo "@KO@: DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql" "20151029" "REM01" "OK" ""
	      echo " OK : DDL_086_ENTITY01_ALTER_TABLE_DD_PCO_BFR_RESULTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151021" "BKREC-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE-REM01-reg3.1.sql > DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DDL_087_BANK01_TMP_ACUERDOSEXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_087_ENTITY01_AlterAdjuntoContrato.sql 20151112 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_087_ENTITY01_AlterAdjuntoContrato.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_087_ENTITY01_AlterAdjuntoContrato.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151112" "CMREC-1083" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_087_ENTITY01_AlterAdjuntoContrato.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_087_ENTITY01_AlterAdjuntoContrato.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_087_ENTITY01_AlterAdjuntoContrato-REM01-reg3.1.sql > DDL_087_ENTITY01_AlterAdjuntoContrato.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_087_ENTITY01_AlterAdjuntoContrato.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_087_ENTITY01_AlterAdjuntoContrato.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_ENTITY01_AlterAdjuntoContrato.sql" "20151112" "REM01" "KO" ""
	      echo "@KO@: DDL_087_ENTITY01_AlterAdjuntoContrato.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_ENTITY01_AlterAdjuntoContrato.sql" "20151112" "REM01" "OK" ""
	      echo " OK : DDL_087_ENTITY01_AlterAdjuntoContrato.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql 20151118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "REM01" "Alberto Campos" "web"  "9.1" "20151118" "PRODUCTO-347" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD-REM01-reg3.1.sql > DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20151118" "REM01" "KO" ""
	      echo "@KO@: DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20151118" "REM01" "OK" ""
	      echo " OK : DDL_087_ENTITY01_ALTER_TABLE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20151110" "BKREC-1420" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_088_BANK01_ALTER_RULE_DATA_ENGINE-REM01-reg3.1.sql > DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_088_BANK01_ALTER_RULE_DATA_ENGINE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_088_ENTITY01_AlterAdjuntoPersona.sql 20151112 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_088_ENTITY01_AlterAdjuntoPersona.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_088_ENTITY01_AlterAdjuntoPersona.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151112" "CMREC-1083" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_088_ENTITY01_AlterAdjuntoPersona.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_088_ENTITY01_AlterAdjuntoPersona.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_088_ENTITY01_AlterAdjuntoPersona-REM01-reg3.1.sql > DDL_088_ENTITY01_AlterAdjuntoPersona.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_088_ENTITY01_AlterAdjuntoPersona.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_088_ENTITY01_AlterAdjuntoPersona.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_088_ENTITY01_AlterAdjuntoPersona.sql" "20151112" "REM01" "KO" ""
	      echo "@KO@: DDL_088_ENTITY01_AlterAdjuntoPersona.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_088_ENTITY01_AlterAdjuntoPersona.sql" "20151112" "REM01" "OK" ""
	      echo " OK : DDL_088_ENTITY01_AlterAdjuntoPersona.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_089_BANK01_SP_REFRESH_DATA_RULE_ENGINE.sql" "REM01" "Rubén Rovira" "batch"  "0.2" "20151110" "BKREC-1420" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_089_BANK01_SP_REFRESH_DATA_RULE_ENGINE-REM01-reg3.1.sql > DDL_089_BANK01_SP_REFRESH_DATA_RULE_ENGINE.log
echo " -- : DDL_089_BANK01_SP_REFRESH_DATA_RULE_ENGINE.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql 20151118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20151118" "BKREC-1285" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA-REM01-reg3.1.sql > DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql" "20151118" "REM01" "KO" ""
	      echo "@KO@: DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql" "20151118" "REM01" "OK" ""
	      echo " OK : DDL_090_BANK01_ALTER_RAS_RANKING_SUBCARTERA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_091_BANK01_SP_PROCESA_PROCESO_FACT.sql" "REM01" "RUBEN ROVIRA" "batch"  "0.2" "20151117" "BKREC-1285" "NO"
	exit | sqlplus -s -l $1 @./scripts/DDL_091_BANK01_SP_PROCESA_PROCESO_FACT-REM01-reg3.1.sql > DDL_091_BANK01_SP_PROCESA_PROCESO_FACT.log
echo " -- : DDL_091_BANK01_SP_PROCESA_PROCESO_FACT.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql 20151117 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.16-bk" "20151117" "BKREC-1285" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR-REM01-reg3.1.sql > DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql" "20151117" "REM01" "KO" ""
	      echo "@KO@: DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql" "20151117" "REM01" "OK" ""
	      echo " OK : DDL_092_BANK01_TMP_RAS_RANKING_SUBCARTERA_POR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_093_BANK01_SP_RERA_CALCULO_RAS_RANKING.sql" "REM01" "RUBEN ROVIRA" "batch"  "0.2" "20151117" "BKREC-1285" "NO"
	exit | sqlplus -s -l $1 @./scripts/DDL_093_BANK01_SP_RERA_CALCULO_RAS_RANKING-REM01-reg3.1.sql > DDL_093_BANK01_SP_RERA_CALCULO_RAS_RANKING.log
echo " -- : DDL_093_BANK01_SP_RERA_CALCULO_RAS_RANKING.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_094_BANK01_SP_REFRESH_DATA_RULE_ENGINE.sql" "REM01" "Rubén Rovira" "batch"  "9.1.16-BK-UP" "20151124" "BKREC-1420" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_094_BANK01_SP_REFRESH_DATA_RULE_ENGINE-REM01-reg3.1.sql > DDL_094_BANK01_SP_REFRESH_DATA_RULE_ENGINE.log
echo " -- : DDL_094_BANK01_SP_REFRESH_DATA_RULE_ENGINE.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql 20151103 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql" "REM01" "MANUEL_MEJIAS" "web"  "9.1" "20151103" "PRODUCTO-75" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET-REM01-reg3.1.sql > DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql" "20151103" "REM01" "KO" ""
	      echo "@KO@: DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql" "20151103" "REM01" "OK" ""
	      echo " OK : DDL_100_ENTITY01_CREATE_TABLE_DD_MAL_MOTIVO_ASIG_LET.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql 29-10-2015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql" "REM01" "CARLOS PEREZ" "web"  "9.1" "29-10-2015" "CMREC-945" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_100_ENTITY01_TMP_CREA_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_100_ENTITY01_TMP_CREA_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_100_ENTITY01_TMP_CREA_ASUNTOS-REM01-reg3.1.sql > DDL_100_ENTITY01_TMP_CREA_ASUNTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_100_ENTITY01_TMP_CREA_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_100_ENTITY01_TMP_CREA_ASUNTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql" "29-10-2015" "REM01" "KO" ""
	      echo "@KO@: DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql" "29-10-2015" "REM01" "OK" ""
	      echo " OK : DDL_100_ENTITY01_TMP_CREA_ASUNTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql 12112015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.17-bk" "12112015" "PRODUCTO-420" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION-REM01-reg3.1.sql > DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql" "12112015" "REM01" "KO" ""
	      echo "@KO@: DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql" "12112015" "REM01" "OK" ""
	      echo " OK : DDL_101_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO_INTEGRACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql 20151119 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql" "REM01" "PEDROBLASCO" "web"  "9.1" "20151119" "CMREC-1079" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD-REM01-reg3.1.sql > DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql" "20151119" "REM01" "KO" ""
	      echo "@KO@: DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql" "20151119" "REM01" "OK" ""
	      echo " OK : DDL_110_ENTITY01_CREATE_TABLE_DD_TAE_TIPO_ADJUNTO_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql 20151104 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "José Luis Gauxachs" "online"  "9.1.11-hy" "20151104" "HR-1265" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20151104" "REM01" "KO" ""
	      echo "@KO@: DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20151104" "REM01" "OK" ""
	      echo " OK : DDL_127_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql" "REM01" "José Luis Gauxachs" "web"  "9.1.11-hy" "20151110" "HR-1474" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO-REM01-reg3.1.sql > DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_128_ENTITY01_ALTER_TABLE_DD_PCO_BFT_TIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql 20151022 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql" "REM01" "ENRIQUE JIMENEZ DIAZ" "batch"  "9.3" "20151022" "CMREC-866" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos-REM01-reg3.1.sql > DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql" "20151022" "REM01" "KO" ""
	      echo "@KO@: DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql" "20151022" "REM01" "OK" ""
	      echo " OK : DDL_128_ENTITY01_DATEJD-CreacionTablasVencidos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1" "20150916" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2-REM01-reg3.1.sql > DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DDL_128_ENTITY01_VTAR_TAREA_VS_USUARIO_V2.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql" "REM01" "José Luis Gauxachs" "web"  "9.1.11-hy" "20151110" "HR-1474" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO-REM01-reg3.1.sql > DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_129_ENTITY01_ALTER_TABLE_PCO_BUR_ENVIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.17-bk" "20151110" "BKREC-1051" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD-REM01-reg3.1.sql > DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_130_ENTITY01_ALTER_PEN_PARAM_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql 2015111 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql" "REM01" "CARLOS PEREZ" "online"  "9.1.0-cj-rc21" "2015111" "no_tiene" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS-REM01-reg3.1.sql > DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql" "2015111" "REM01" "KO" ""
	      echo "@KO@: DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql" "2015111" "REM01" "OK" ""
	      echo " OK : DDL_130_ENTITY01_V_PER_PERSONAS_FORMULAS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql 20151203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.18-bk" "20151203" "BKREC-601" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA-REM01-reg3.1.sql > DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql" "20151203" "REM01" "KO" ""
	      echo "@KO@: DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql" "20151203" "REM01" "OK" ""
	      echo " OK : DDL_131_ENTITY01_ALTER_TMP_REC_CONTRATOS_BAJA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.17-bk" "20151110" "BKREC-1051" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN-REM01-reg3.1.sql > DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DDL_131_ENTITY01_BKREC-1519_Ampliar_campo_valor_PEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql 20151112 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql" "REM01" "Alberto b" "web"  "9.1.0-rcj14" "20151112" "PRODUCTO-419" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS-REM01-reg3.1.sql > DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql" "20151112" "REM01" "KO" ""
	      echo "@KO@: DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql" "20151112" "REM01" "OK" ""
	      echo " OK : DDL_132_ENTITY01_ALTER_TABLE_ACU_OPERACIONES_TERMINOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql 20151203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.18-bk" "20151203" "BKREC-601" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR-REM01-reg3.1.sql > DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql" "20151203" "REM01" "KO" ""
	      echo "@KO@: DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql" "20151203" "REM01" "OK" ""
	      echo " OK : DDL_132_ENTITY01_ALTER_TMP_REC_REPARTO_DIA_ANTERIOR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_132_ENTITY01_tmp_alta_instances.sql 20151210 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_132_ENTITY01_tmp_alta_instances.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_132_ENTITY01_tmp_alta_instances.sql" "REM01" "Óscar" "online"  "9.1.19-bk" "20151210" "BKREC-1202" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_132_ENTITY01_tmp_alta_instances.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_132_ENTITY01_tmp_alta_instances.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_132_ENTITY01_tmp_alta_instances-REM01-reg3.1.sql > DDL_132_ENTITY01_tmp_alta_instances.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_132_ENTITY01_tmp_alta_instances.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_132_ENTITY01_tmp_alta_instances.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_tmp_alta_instances.sql" "20151210" "REM01" "KO" ""
	      echo "@KO@: DDL_132_ENTITY01_tmp_alta_instances.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_132_ENTITY01_tmp_alta_instances.sql" "20151210" "REM01" "OK" ""
	      echo " OK : DDL_132_ENTITY01_tmp_alta_instances.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_133_ENTITY01_SP_PREPROCESADO_COBROS_FACT.sql" "REM01" "Rubén Rovira" "batch"  "0.2" "20151203" "BKREC-58" "NO"
	exit | sqlplus -s -l $1 @./scripts/DDL_133_ENTITY01_SP_PREPROCESADO_COBROS_FACT-REM01-reg3.1.sql > DDL_133_ENTITY01_SP_PREPROCESADO_COBROS_FACT.log
echo " -- : DDL_133_ENTITY01_SP_PREPROCESADO_COBROS_FACT.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_134_BANK01_SP_PROCESA_PROCESO_FACT.sql" "REM01" "RUBEN ROVIRA" "batch"  "0.2" "20151117" "BKREC-1285" "NO"
	exit | sqlplus -s -l $1 @./scripts/DDL_134_BANK01_SP_PROCESA_PROCESO_FACT-REM01-reg3.1.sql > DDL_134_BANK01_SP_PROCESA_PROCESO_FACT.log
echo " -- : DDL_134_BANK01_SP_PROCESA_PROCESO_FACT.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql 20151115 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-rcj17" "20151115" "-" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO-REM01-reg3.1.sql > DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql" "20151115" "REM01" "KO" ""
	      echo "@KO@: DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql" "20151115" "REM01" "OK" ""
	      echo " OK : DDL_134_ENTITY01_ALTER_TABLE_TEA_TERMINOS_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql 20151217 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql" "REM01" "Óscar" "online"  "9.1.19-bk" "20151217" "BKREC-1586" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO-REM01-reg3.1.sql > DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql" "20151217" "REM01" "KO" ""
	      echo "@KO@: DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql" "20151217" "REM01" "OK" ""
	      echo " OK : DDL_134_ENTITY01_BKREC-1586_ADD_COLUMN_REA_ID_REDUCIDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql 20151201 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc23" "20151201" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO-REM01-reg3.1.sql > DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "20151201" "REM01" "KO" ""
	      echo "@KO@: DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "20151201" "REM01" "OK" ""
	      echo " OK : DDL_135_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql 20151217 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql" "REM01" "Javier Ruiz" "web"  "9.1.0" "20151217" "PRODUCTO-527" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES-REM01-reg3.1.sql > DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql" "20151217" "REM01" "KO" ""
	      echo "@KO@: DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql" "20151217" "REM01" "OK" ""
	      echo " OK : DDL_135_ENTITY01_CREATE_TABLE_PEM_PERSONAS_MANUALES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql 20151130 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql" "REM01" "GONZALO ESTELLES" "batch"  "9.3" "20151130" "CMREC-447" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_135_ENTITY01_ModificacionTablaCNTyPER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_135_ENTITY01_ModificacionTablaCNTyPER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_135_ENTITY01_ModificacionTablaCNTyPER-REM01-reg3.1.sql > DDL_135_ENTITY01_ModificacionTablaCNTyPER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_135_ENTITY01_ModificacionTablaCNTyPER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_135_ENTITY01_ModificacionTablaCNTyPER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql" "20151130" "REM01" "KO" ""
	      echo "@KO@: DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql" "20151130" "REM01" "OK" ""
	      echo " OK : DDL_135_ENTITY01_ModificacionTablaCNTyPER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql 20151217 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql" "REM01" "Javier Ruiz" "web"  "9.1.0" "20151217" "PRODUCTO-527" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN-REM01-reg3.1.sql > DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql" "20151217" "REM01" "KO" ""
	      echo "@KO@: DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql" "20151217" "REM01" "OK" ""
	      echo " OK : DDL_136_ENTITY01_CREATE_TABLE_CPM_CONTRATOS_PERSONAS_MAN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql 20151202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql" "REM01" "Alberto b." "web"  "9.1.0-cj-rc23" "20151202" "PPRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO-REM01-reg3.1.sql > DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql" "20151202" "REM01" "KO" ""
	      echo "@KO@: DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql" "20151202" "REM01" "OK" ""
	      echo " OK : DDL_136_ENTITY01_CREATE_TABLE_DD_ENTIDAD_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql 20151222 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1" "20151222" "PRODUCTO-529" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX-REM01-reg3.1.sql > DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql" "20151222" "REM01" "KO" ""
	      echo "@KO@: DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql" "20151222" "REM01" "OK" ""
	      echo " OK : DDL_137_ENTITY01_ADD_PEM_ID_PCO_BUR_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql 20151202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "REM01" "Alberto b." "web"  "9.1.0-cj-rc23" "20151202" "PPRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO-REM01-reg3.1.sql > DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "20151202" "REM01" "KO" ""
	      echo "@KO@: DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql" "20151202" "REM01" "OK" ""
	      echo " OK : DDL_137_ENTITY01_ALTER_TABLE_DD_TPA_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql 20160118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql" "REM01" "ALBERTO SOLER" "web"  "9.1" "20160118" "Creación_plantillas_liquidaciones" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO-REM01-reg3.1.sql > DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql" "20160118" "REM01" "KO" ""
	      echo "@KO@: DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql" "20160118" "REM01" "OK" ""
	      echo " OK : DDL_137_ENTITY01_CREATE_TABLE_DD_PCO_LIQ_TIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql 20151222 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1" "20151222" "PRODUCTO-529" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION-REM01-reg3.1.sql > DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql" "20151222" "REM01" "KO" ""
	      echo "@KO@: DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql" "20151222" "REM01" "OK" ""
	      echo " OK : DDL_138_ENTITY01_ADD_PEM_ID_PCO_BUR_ENVIO_INTEGRACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql 20151204 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "REM01" "JAVIER DIAZ" "batch"  "9.3" "20151204" "CMREC-866" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD-REM01-reg3.1.sql > DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "20151204" "REM01" "KO" ""
	      echo "@KO@: DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "20151204" "REM01" "OK" ""
	      echo " OK : DDL_138_ENTITY01_JADR_CREATE_TABLE_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_139_ENTITY01_ALTER_BIE_BIEN.sql 20160203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_139_ENTITY01_ALTER_BIE_BIEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_139_ENTITY01_ALTER_BIE_BIEN.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20160203" "CMREC-1955" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_139_ENTITY01_ALTER_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_139_ENTITY01_ALTER_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_139_ENTITY01_ALTER_BIE_BIEN-REM01-reg3.1.sql > DDL_139_ENTITY01_ALTER_BIE_BIEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_139_ENTITY01_ALTER_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_139_ENTITY01_ALTER_BIE_BIEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_139_ENTITY01_ALTER_BIE_BIEN.sql" "20160203" "REM01" "KO" ""
	      echo "@KO@: DDL_139_ENTITY01_ALTER_BIE_BIEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_139_ENTITY01_ALTER_BIE_BIEN.sql" "20160203" "REM01" "OK" ""
	      echo " OK : DDL_139_ENTITY01_ALTER_BIE_BIEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_139_ENTITY01_SP_RERA_CALCULO_RAS_RANKING.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160212" "BKREC-1285" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_139_ENTITY01_SP_RERA_CALCULO_RAS_RANKING-REM01-reg3.1.sql > DDL_139_ENTITY01_SP_RERA_CALCULO_RAS_RANKING.log
echo " -- : DDL_139_ENTITY01_SP_RERA_CALCULO_RAS_RANKING.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql 20151120 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151120" "CMREC-1083" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE-REM01-reg3.1.sql > DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql" "20151120" "REM01" "KO" ""
	      echo "@KO@: DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql" "20151120" "REM01" "OK" ""
	      echo " OK : DDL_140_ENTITY01_ADD_TIPOADJ_ADJUNTOEXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_140_ENTITY01_ALTER_BIE_CNT.sql 20160203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_140_ENTITY01_ALTER_BIE_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_140_ENTITY01_ALTER_BIE_CNT.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20160203" "CMREC-1955" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_140_ENTITY01_ALTER_BIE_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_140_ENTITY01_ALTER_BIE_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_140_ENTITY01_ALTER_BIE_CNT-REM01-reg3.1.sql > DDL_140_ENTITY01_ALTER_BIE_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_140_ENTITY01_ALTER_BIE_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_140_ENTITY01_ALTER_BIE_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_140_ENTITY01_ALTER_BIE_CNT.sql" "20160203" "REM01" "KO" ""
	      echo "@KO@: DDL_140_ENTITY01_ALTER_BIE_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_140_ENTITY01_ALTER_BIE_CNT.sql" "20160203" "REM01" "OK" ""
	      echo " OK : DDL_140_ENTITY01_ALTER_BIE_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql 20151120 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151120" "CMREC-1083" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA-REM01-reg3.1.sql > DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql" "20151120" "REM01" "KO" ""
	      echo "@KO@: DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql" "20151120" "REM01" "OK" ""
	      echo " OK : DDL_141_ENTITY01_ADD_TIPOADJ_ADJUNTOPERSONA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql 20160210 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1" "20160210" "CMREC-1955" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD-REM01-reg3.1.sql > DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql" "20160210" "REM01" "KO" ""
	      echo "@KO@: DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql" "20160210" "REM01" "OK" ""
	      echo " OK : DDL_141_ENTITY01_ALTER_BIE_BIEN_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql 20151120 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20151120" "CMREC-1083" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO-REM01-reg3.1.sql > DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql" "20151120" "REM01" "KO" ""
	      echo "@KO@: DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql" "20151120" "REM01" "OK" ""
	      echo " OK : DDL_142_ENTITY01_ADD_TIPOADJ_ADJUNTOCONTRATO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql 201600510 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql" "REM01" "RUBEN ROVIRA" "batch"  "0.1" "201600510" "CMREC-2336" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_142_ENTITY01_INX_CIR_CIRBE_DEL-REM01-reg3.1.sql > DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql" "201600510" "REM01" "KO" ""
	      echo "@KO@: DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql" "201600510" "REM01" "OK" ""
	      echo " OK : DDL_142_ENTITY01_INX_CIR_CIRBE_DEL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql 20160119 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql" "REM01" "Alberto B" "online"  "9.1.0-cj-rc37" "20160119" "HR-1767" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE-REM01-reg3.1.sql > DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql" "20160119" "REM01" "KO" ""
	      echo "@KO@: DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql" "20160119" "REM01" "OK" ""
	      echo " OK : DDL_143_ENTITY01_ALTER_PRC_PROCEDIMIENTOS_PRC_REMOTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql 20160204 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql" "REM01" "Alberto Campos" "web"  "9.2.0-cj-rc01" "20160204" "CMREC-1420" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES-REM01-reg3.1.sql > DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql" "20160204" "REM01" "KO" ""
	      echo "@KO@: DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql" "20160204" "REM01" "OK" ""
	      echo " OK : DDL_143_ENTITY01_ALTER_TABLE_BIE_VALORACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql 20160121 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql" "REM01" "CARLOS PEREZ" "online"  "9.1.1-cj" "20160121" "CMREC-1794" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion-REM01-reg3.1.sql > DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql" "20160121" "REM01" "KO" ""
	      echo "@KO@: DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql" "20160121" "REM01" "OK" ""
	      echo " OK : DDL_144_ENTITY01_V_PER_PERSONAS_FORMULASChangeSituacion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql 20151218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql" "REM01" "JORGE MARTIN" "online"  "9.1.0-X" "20151218" "PRODUCTO-525" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO-REM01-reg3.1.sql > DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql" "20151218" "REM01" "KO" ""
	      echo "@KO@: DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql" "20151218" "REM01" "OK" ""
	      echo " OK : DDL_150_ENTITY01_Add_AcuseRecibo_PCO_BUR_ENVIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql 20151221 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql" "REM01" "JORGE MARTIN" "online"  "9.1.0-X" "20151221" "PRODUCTO-526" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO-REM01-reg3.1.sql > DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql" "20151221" "REM01" "KO" ""
	      echo "@KO@: DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql" "20151221" "REM01" "OK" ""
	      echo " OK : DDL_151_ENTITY01_Add_RefExternaEnvio_PCO_BUR_ENVIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql 20160114 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql" "REM01" "NACHO ARCOS" "online"  "9.1" "20160114" "CMREC-1482" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION-REM01-reg3.1.sql > DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql" "20160114" "REM01" "KO" ""
	      echo "@KO@: DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql" "20160114" "REM01" "OK" ""
	      echo " OK : DDL_152_ENTITY01_ALTER_BIE_ADJ_ADJUDICACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql 20160111 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql" "REM01" "Jorge Ros" "web"  "9.1" "20160111" "PRODUCTO-579" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO-REM01-reg3.1.sql > DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql" "20160111" "REM01" "KO" ""
	      echo "@KO@: DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql" "20160111" "REM01" "OK" ""
	      echo " OK : DDL_152_ENTITY01_ALTER_TABLE_DAA_DESPACHO_AMBITO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql 20151212 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql" "REM01" "Carlos Gil Gimeno" "web"  "9.1.0-rcj14" "20151212" "PRODUCTO-528" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES-REM01-reg3.1.sql > DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql" "20151212" "REM01" "KO" ""
	      echo "@KO@: DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql" "20151212" "REM01" "OK" ""
	      echo " OK : DDL_152_ENTITY01_ALTER_TABLE_PEM_PERSONAS_MANUALES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql 20160118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql" "REM01" "NACHO ARCOS" "online"  "9.1" "20160118" "PRODUCTO-607" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS-REM01-reg3.1.sql > DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql" "20160118" "REM01" "KO" ""
	      echo "@KO@: DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql" "20160118" "REM01" "OK" ""
	      echo " OK : DDL_153_ENTITY01_ALTER_PCO_DOC_DOCUMENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql 20150118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql" "REM01" "Carlos Gil Gimeno" "web"  "9.1.0" "20150118" "PRODUCTO-616" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM-REM01-reg3.1.sql > DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql" "20150118" "REM01" "KO" ""
	      echo "@KO@: DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql" "20150118" "REM01" "OK" ""
	      echo " OK : DDL_153_ENTITY01_CREATE_TABLE_DIR_PEM.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_153_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROVINCIAS.sql" "REM01" "JORGE ROS" "producto"  "9.1" "20160113" "PRODUCTO-582" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_153_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROVINCIAS-REM01-reg3.1.sql > DDL_153_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROVINCIAS.log
echo " -- : DDL_153_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROVINCIAS.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql 20150125 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql" "REM01" "Carlos Gil Gimeno" "web"  "9.1.0" "20150125" "PRODUCTO-527" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN-REM01-reg3.1.sql > DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql" "20150125" "REM01" "KO" ""
	      echo "@KO@: DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql" "20150125" "REM01" "OK" ""
	      echo " OK : DDL_154_ENTITY01_MODIFICA_IDX_CPM_CONTRATOS_PERSONAS_MAN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql 20160129 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql" "REM01" "CARLOS GIL GIMENO" "web"  "9.1" "20160129" "HR-1179" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO-REM01-reg3.1.sql > DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql" "20160129" "REM01" "KO" ""
	      echo "@KO@: DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql" "20160129" "REM01" "OK" ""
	      echo " OK : DDL_155_ENTITY01_ADD_FK_TAP_TAREA_PROCEDIMIENTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql 20160129 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql" "REM01" "Jorge Ros" "web"  "9.1" "20160129" "PRODUCTO-577" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO-REM01-reg3.1.sql > DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql" "20160129" "REM01" "KO" ""
	      echo "@KO@: DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql" "20160129" "REM01" "OK" ""
	      echo " OK : DDL_155_ENTITY01_ALTER_TABLE_DAA_DESPACHO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_156_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V2.sql" "REM01" "JORGE ROS" "producto"  "9.1" "20160202" "PRODUCTO-677" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_156_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V2-REM01-reg3.1.sql > DDL_156_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V2.log
echo " -- : DDL_156_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V2.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql 20160129 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql" "REM01" "Jorge Ros" "web"  "9.1" "20160129" "PRODUCTO-677" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO-REM01-reg3.1.sql > DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql" "20160129" "REM01" "KO" ""
	      echo "@KO@: DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql" "20160129" "REM01" "OK" ""
	      echo " OK : DDL_157_ENTITY01_DROP_COLUMN_DAA_DESPACHO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql 20160107 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql" "REM01" "PEDROBLASCO" "online"  "9.1" "20160107" "CMREC-1750" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS-REM01-reg3.1.sql > DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql" "20160107" "REM01" "KO" ""
	      echo "@KO@: DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql" "20160107" "REM01" "OK" ""
	      echo " OK : DDL_200_ENTITY01_CREATE_TABLE_CMA_CAMBIOS_MASIVOS_ASUNTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_346_ENTITY01_VistasProcuradores.sql 20160215 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_346_ENTITY01_VistasProcuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_346_ENTITY01_VistasProcuradores.sql" "REM01" "OSCAR DORADO" "online"  "9.1" "20160215" "PRODUCTO-578" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_346_ENTITY01_VistasProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_346_ENTITY01_VistasProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_346_ENTITY01_VistasProcuradores-REM01-reg3.1.sql > DDL_346_ENTITY01_VistasProcuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_346_ENTITY01_VistasProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_346_ENTITY01_VistasProcuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_346_ENTITY01_VistasProcuradores.sql" "20160215" "REM01" "KO" ""
	      echo "@KO@: DDL_346_ENTITY01_VistasProcuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_346_ENTITY01_VistasProcuradores.sql" "20160215" "REM01" "OK" ""
	      echo " OK : DDL_346_ENTITY01_VistasProcuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql 20151223 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20151223" "PRODUCTO-547" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR-REM01-reg3.1.sql > DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql" "20151223" "REM01" "KO" ""
	      echo "@KO@: DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql" "20151223" "REM01" "OK" ""
	      echo " OK : DDL_351_ENTITY01_CREATE_TABLE_DD_PCO_GESTION_REVISAR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql 20160129 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql" "REM01" "Alberto Soler" "online"  "9.1" "20160129" "PRODUCTO-677" "SÍ"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado-REM01-reg3.1.sql > DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql" "20160129" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql" "20160129" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_CambiarTamanyoTipoYCodigoTurnado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql 20160201 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "REM01" "JAVIER RUIZ" "producto"  "9.1" "20160201" "CMREC-1856" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS-REM01-reg3.1.sql > DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "20160201" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "20160201" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql 20160126 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql" "REMMASTER" "JORGE ROS" "producto"  "9.1" "20160126" "HR-1316" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA-REMMASTER-reg3.1.sql > DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql" "20160126" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql" "20160126" "REMMASTER" "OK" ""
	      echo " OK : DDL_353_MASTER_CREATE_TABLE_DD_IMV_IMPOSICION_VENTA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql 20160229 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql" "REM01" "BRUNO ANGLES" "web"  "9.1.0-cj-rc36.1-CMREC-1907" "20160229" "CMREC-1907" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907-REM01-reg3.1.sql > DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql" "20160229" "REM01" "KO" ""
	      echo "@KO@: DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql" "20160229" "REM01" "OK" ""
	      echo " OK : DDL_600_ENTITY01_ALTER_DATA_RULE_ENGINE_CMREC1907.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_600_MASTER_USU_ENTIDADES.sql 20151221 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_600_MASTER_USU_ENTIDADES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_600_MASTER_USU_ENTIDADES.sql" "REMMASTER" "MANUEL MEJIAS" "online"  "9.1.12-bk" "20151221" "HR-1675" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_600_MASTER_USU_ENTIDADES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_600_MASTER_USU_ENTIDADES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_600_MASTER_USU_ENTIDADES-REMMASTER-reg3.1.sql > DDL_600_MASTER_USU_ENTIDADES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_600_MASTER_USU_ENTIDADES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_600_MASTER_USU_ENTIDADES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_600_MASTER_USU_ENTIDADES.sql" "20151221" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_600_MASTER_USU_ENTIDADES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_600_MASTER_USU_ENTIDADES.sql" "20151221" "REMMASTER" "OK" ""
	      echo " OK : DDL_600_MASTER_USU_ENTIDADES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql 20160229 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql" "REM01" "BRUNO ANGLES" "web"  "9.1.0-cj-rc36.1-CMREC-1907s" "20160229" "CMREC-1907" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907-REM01-reg3.1.sql > DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql" "20160229" "REM01" "KO" ""
	      echo "@KO@: DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql" "20160229" "REM01" "OK" ""
	      echo " OK : DDL_601_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC1907.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql 20160204 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql" "REM01" "JORGE ROS" "online"  "9.1" "20160204" "CMREC-1588" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD-REM01-reg3.1.sql > DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql" "20160204" "REM01" "KO" ""
	      echo "@KO@: DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql" "20160204" "REM01" "OK" ""
	      echo " OK : DDL_602_ENTITY01_MODIFY_COLUMNS_USUARIOXXX_LONGITUD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_603_ENTITY01_BATCH_LOG.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_603_ENTITY01_BATCH_LOG.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_603_ENTITY01_BATCH_LOG.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_603_ENTITY01_BATCH_LOG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_603_ENTITY01_BATCH_LOG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_603_ENTITY01_BATCH_LOG-REM01-reg3.1.sql > DDL_603_ENTITY01_BATCH_LOG.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_603_ENTITY01_BATCH_LOG.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_603_ENTITY01_BATCH_LOG.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_603_ENTITY01_BATCH_LOG.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_603_ENTITY01_BATCH_LOG.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_603_ENTITY01_BATCH_LOG.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_603_ENTITY01_BATCH_LOG.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql 20160527 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql" "REM01" "LUIS RUIZ" "batch"  "9.2.5" "20160527" "PRODUCTO-1087" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA-REM01-reg3.1.sql > DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql" "20160527" "REM01" "KO" ""
	      echo "@KO@: DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql" "20160527" "REM01" "OK" ""
	      echo " OK : DDL_604_ENTITY01_BATCH_SEG_DATOS_SALIDA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT-REM01-reg3.1.sql > DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_605_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN-REM01-reg3.1.sql > DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_606_ENTITY01_BATCH_SEG_DATOS_SALIDA_1GEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER-REM01-reg3.1.sql > DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_607_ENTITY01_BATCH_SEG_DATOS_SALIDA_1G_PER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT-REM01-reg3.1.sql > DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_608_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER-REM01-reg3.1.sql > DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_609_ENTITY01_BATCH_SEG_DATOS_SALIDA_2G_PER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE-REM01-reg3.1.sql > DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_610_ENTITY01_BATCH_SEG_DATOS_SALIDA_BASE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES-REM01-reg3.1.sql > DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_611_ENTITY01_BATCH_SEG_DATOS_SALIDA_EXP_DES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL-REM01-reg3.1.sql > DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_612_ENTITY01_BATCH_SEG_DATOS_SALIDA_GCL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA-REM01-reg3.1.sql > DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_613_ENTITY01_BATCH_SEG_DATOS_SALIDA_GUIA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT-REM01-reg3.1.sql > DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_614_ENTITY01_BATCH_SEG_DATOS_SALIDA_TIT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO-REM01-reg3.1.sql > DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_615_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM-REM01-reg3.1.sql > DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_616_ENTITY01_BATCH_SEG_DATOS_SALIDA_TODO_LM.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_617_ENTITY01_BATCH_SV_CLIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_617_ENTITY01_BATCH_SV_CLIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_617_ENTITY01_BATCH_SV_CLIENTES-REM01-reg3.1.sql > DDL_617_ENTITY01_BATCH_SV_CLIENTES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_617_ENTITY01_BATCH_SV_CLIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_617_ENTITY01_BATCH_SV_CLIENTES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_617_ENTITY01_BATCH_SV_CLIENTES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE-REM01-reg3.1.sql > DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_618_ENTITY01_BATCH_SV_CLIENTES_BASE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_619_ENTITY01_BATCH_SV_DATOS_CNT-REM01-reg3.1.sql > DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_619_ENTITY01_BATCH_SV_DATOS_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP-REM01-reg3.1.sql > DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_620_ENTITY01_BATCH_SV_DATOS_CNT_EXP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql 20160224 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160224" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER-REM01-reg3.1.sql > DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql" "20160224" "REM01" "KO" ""
	      echo "@KO@: DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql" "20160224" "REM01" "OK" ""
	      echo " OK : DDL_621_ENTITY01_BATCH_SV_DATOS_CNT_PER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_622_ENTITY01_BATCH_SV_DATOS_GCL-REM01-reg3.1.sql > DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_622_ENTITY01_BATCH_SV_DATOS_GCL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP-REM01-reg3.1.sql > DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_623_ENTITY01_BATCH_SV_DATOS_PER_EXP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA-REM01-reg3.1.sql > DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_624_ENTITY01_BATCH_VEN_DATOS_SALIDA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT-REM01-reg3.1.sql > DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_625_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN-REM01-reg3.1.sql > DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_626_ENTITY01_BATCH_VEN_DATOS_SALIDA_1GEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER-REM01-reg3.1.sql > DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_627_ENTITY01_BATCH_VEN_DATOS_SALIDA_1G_PER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT-REM01-reg3.1.sql > DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_628_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER-REM01-reg3.1.sql > DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_629_ENTITY01_BATCH_VEN_DATOS_SALIDA_2G_PER.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE-REM01-reg3.1.sql > DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_630_ENTITY01_BATCH_VEN_DATOS_SALIDA_BASE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES-REM01-reg3.1.sql > DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_631_ENTITY01_BATCH_VEN_DATOS_SALIDA_EXP_DES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL-REM01-reg3.1.sql > DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_632_ENTITY01_BATCH_VEN_DATOS_SALIDA_GCL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA-REM01-reg3.1.sql > DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_633_ENTITY01_BATCH_VEN_DATOS_SALIDA_GUIA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT-REM01-reg3.1.sql > DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_634_ENTITY01_BATCH_VEN_DATOS_SALIDA_TIT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO-REM01-reg3.1.sql > DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_635_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql 20160304 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.37" "20160304" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM-REM01-reg3.1.sql > DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql" "20160304" "REM01" "KO" ""
	      echo "@KO@: DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql" "20160304" "REM01" "OK" ""
	      echo " OK : DDL_636_ENTITY01_BATCH_VEN_DATOS_SALIDA_TODO_LM.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql 20160504 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql" "REM01" "LUIS RUIZ" "batch"  "9.2.2" "20160504" "PRODUCTO-801" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE-REM01-reg3.1.sql > DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql" "20160504" "REM01" "KO" ""
	      echo "@KO@: DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql" "20160504" "REM01" "OK" ""
	      echo " OK : DDL_637_ENTITY01_TMP_BATCH_SV_BPM_INSTANCE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE-REM01-reg3.1.sql > DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_638_ENTITY01_TMP_CNT_NUEVOS_CLI_VCPE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES-REM01-reg3.1.sql > DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_639_ENTITY01_TMP_CNT_NUEVOS_CLI_DES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160218" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV-REM01-reg3.1.sql > DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_640_ENTITY01_TMP_CNT_NUEVOS_CLI_MOV.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql 20160301 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "REM01" "José Luis Gauxachs" "web"  "9.1.0-cj-rc37" "20160301" "CMREC-2328" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS-REM01-reg3.1.sql > DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "20160301" "REM01" "KO" ""
	      echo "@KO@: DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql" "20160301" "REM01" "OK" ""
	      echo " OK : DDL_641_ENTITY01_ALTER_TABLE_PCO_PRC_PROCEDIMIENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql 20160303 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql" "REM01" "LUIS RUIZ" "batch"  "9.1.19" "20160303" "PRODUCTO-673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_642_ENTITY01_TMP_CNT_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_642_ENTITY01_TMP_CNT_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_642_ENTITY01_TMP_CNT_CLI_DES-REM01-reg3.1.sql > DDL_642_ENTITY01_TMP_CNT_CLI_DES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_642_ENTITY01_TMP_CNT_CLI_DES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_642_ENTITY01_TMP_CNT_CLI_DES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql" "20160303" "REM01" "KO" ""
	      echo "@KO@: DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql" "20160303" "REM01" "OK" ""
	      echo " OK : DDL_642_ENTITY01_TMP_CNT_CLI_DES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql 20160511 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql" "REM01" "JOSE MANUEL PEREZ BARBERÁ " "batch"  "9.3" "20160511" "HR-2530" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS-REM01-reg3.1.sql > DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql" "20160511" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql" "20160511" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_DATJPB-CreacionIndiceYPK_REC_RECIBOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql 20150330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql" "REM01" "Nacho Arcos" "online"  "9.1" "20150330" "PRODUCTO-953" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA-REM01-reg3.1.sql > DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql" "20150330" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql" "20150330" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_DD_ACE_ADJ_CONCEPTO_ENTREGA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql 20150720 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql" "REM01" "Gonzalo E" "online"  "9.1" "20150720" "CMREC-368" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA-REM01-reg3.1.sql > DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql" "20150720" "REM01" "KO" ""
	      echo "@KO@: DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql" "20150720" "REM01" "OK" ""
	      echo " OK : DDL_000_ENTITY01_DD_ATE_ADJ_TPO_ENTREGA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql 20160113 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "REM01" "PEDROBLASCO" "online"  "9.1" "20160113" "CMREC-1754" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores-REM01-reg3.1.sql > DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "20160113" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql" "20160113" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CreacionPLSQLCambiosMasivosGestores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql 20160317 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql" "REM01" "PEDROBLASCO" "online"  "9.2" "20160317" "PRODUCTO-565" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular-REM01-reg3.1.sql > DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql" "20160317" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql" "20160317" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CreacionPLSQLExpedSaldoIrregular.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_CREATE_TABLES_TUP.sql 20160513 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_CREATE_TABLES_TUP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_CREATE_TABLES_TUP.sql" "REM01" "Óscar" "online"  "9.2.4" "20160513" "PRODUCTO-1313" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_CREATE_TABLES_TUP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_CREATE_TABLES_TUP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_CREATE_TABLES_TUP-REM01-reg3.1.sql > DDL_001_ENTITY01_CREATE_TABLES_TUP.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_CREATE_TABLES_TUP.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_CREATE_TABLES_TUP.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CREATE_TABLES_TUP.sql" "20160513" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_CREATE_TABLES_TUP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_CREATE_TABLES_TUP.sql" "20160513" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_CREATE_TABLES_TUP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql 20160212 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "Alberto b." "online"  "9.2.0" "20160212" "PRODUCTO-776" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160212" "REM01" "KO" ""
	      echo "@KO@: DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160212" "REM01" "OK" ""
	      echo " OK : DDL_001_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql 20160202 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql" "REMMASTER" "NACHO ARCOS" "web"  "9.1" "20160202" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD-REMMASTER-reg3.1.sql > DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql" "20160202" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql" "20160202" "REMMASTER" "OK" ""
	      echo " OK : DDL_001_MASTER_Create_TIPO_GESTOR_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql 20160512 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql" "REM01" "Alberto Soler" "producto"  "9.2" "20160512" "PRODUCTO-1395" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu-REM01-reg3.1.sql > DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql" "20160512" "REM01" "KO" ""
	      echo "@KO@: DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql" "20160512" "REM01" "OK" ""
	      echo " OK : DDL_002_ENTITY01_creacionTablaTemporalTurnadoProcu.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql 20160209 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql" "REM01" "José Luis Gauxachs" "web"  "9.2.0-hy-rc01" "20160209" "HR-1902" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA-REM01-reg3.1.sql > DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql" "20160209" "REM01" "KO" ""
	      echo "@KO@: DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql" "20160209" "REM01" "OK" ""
	      echo " OK : DDL_002_ENTITY01_CREATE_UK_TEX_TAREA_EXTERNA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_003_ENTITY01_create_index_cir_cirbe.sql 20160307 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_003_ENTITY01_create_index_cir_cirbe.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_003_ENTITY01_create_index_cir_cirbe.sql" "REM01" "Alberto B." "online"  "9.2.0" "20160307" "-" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_003_ENTITY01_create_index_cir_cirbe.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_003_ENTITY01_create_index_cir_cirbe.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_003_ENTITY01_create_index_cir_cirbe-REM01-reg3.1.sql > DDL_003_ENTITY01_create_index_cir_cirbe.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_003_ENTITY01_create_index_cir_cirbe.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_003_ENTITY01_create_index_cir_cirbe.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_create_index_cir_cirbe.sql" "20160307" "REM01" "KO" ""
	      echo "@KO@: DDL_003_ENTITY01_create_index_cir_cirbe.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_003_ENTITY01_create_index_cir_cirbe.sql" "20160307" "REM01" "OK" ""
	      echo " OK : DDL_003_ENTITY01_create_index_cir_cirbe.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql" "REM01" "CARLOS GIL GIMENO" "web"  "9.1" "20160218" "PRODUCTO-798" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION-REM01-reg3.1.sql > DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_CREATE_TABLE_DD_DES_DECISION_SANCION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_create_table_DDSituacionGestion.sql 20160303 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_create_table_DDSituacionGestion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_create_table_DDSituacionGestion.sql" "REM01" "Alberto S" "online"  "9.2" "20160303" "PRODUCTO-811" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_create_table_DDSituacionGestion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_create_table_DDSituacionGestion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_create_table_DDSituacionGestion-REM01-reg3.1.sql > DDL_004_ENTITY01_create_table_DDSituacionGestion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_create_table_DDSituacionGestion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_create_table_DDSituacionGestion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_create_table_DDSituacionGestion.sql" "20160303" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_create_table_DDSituacionGestion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_create_table_DDSituacionGestion.sql" "20160303" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_create_table_DDSituacionGestion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql 20160217 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160217" "PRODUCTO-812" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES-REM01-reg3.1.sql > DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql" "20160217" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql" "20160217" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_CREATE_TABLE_PCO_OBSERVACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql 20160225 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql" "REM01" "José Luis Gauxachs" "web"  "9.2.0-hy-rc01" "20160225" "HR-1958" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE-REM01-reg3.1.sql > DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql" "20160225" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql" "20160225" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_CREATE_UK_PRB_PRC_BIE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql 20160303 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql" "REM01" "CARLOS MARTOS" "online"  "9.2.0" "20160303" "PRODUCTO-744" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO-REM01-reg3.1.sql > DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql" "20160303" "REM01" "KO" ""
	      echo "@KO@: DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql" "20160303" "REM01" "OK" ""
	      echo " OK : DDL_004_ENTITY01_VTAR_TAREA_VS_USUARIO_FILTRADONUEVO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql 20160222 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql" "REM01" "CARLOS GIL GIMENO" "web"  "9.1" "20160222" "PRODUCTO-798" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE-REM01-reg3.1.sql > DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql" "20160222" "REM01" "KO" ""
	      echo "@KO@: DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql" "20160222" "REM01" "OK" ""
	      echo " OK : DDL_005_ENTITY01_CREATE_TABLE_SAN_SANCION_EXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql 20160309 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql" "REM01" "IVAN PICAZO" "online"  "9.2" "20160309" "HR-2052" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN-REM01-reg3.1.sql > DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql" "20160309" "REM01" "KO" ""
	      echo "@KO@: DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql" "20160309" "REM01" "OK" ""
	      echo " OK : DDL_005_ENTITY01_UPDATE_FK_BIE_BIEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql 20160222 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20160222" "PRODUCTO-798" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE-REM01-reg3.1.sql > DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql" "20160222" "REM01" "KO" ""
	      echo "@KO@: DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql" "20160222" "REM01" "OK" ""
	      echo " OK : DDL_006_ENTITY01_ADD_SANCION_EXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_007_ENTITY01_AlterConfigAcuerdos.sql 20160301 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_007_ENTITY01_AlterConfigAcuerdos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_007_ENTITY01_AlterConfigAcuerdos.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20160301" "CMREC-2374" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_007_ENTITY01_AlterConfigAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_007_ENTITY01_AlterConfigAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_007_ENTITY01_AlterConfigAcuerdos-REM01-reg3.1.sql > DDL_007_ENTITY01_AlterConfigAcuerdos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_007_ENTITY01_AlterConfigAcuerdos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_007_ENTITY01_AlterConfigAcuerdos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_AlterConfigAcuerdos.sql" "20160301" "REM01" "KO" ""
	      echo "@KO@: DDL_007_ENTITY01_AlterConfigAcuerdos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_007_ENTITY01_AlterConfigAcuerdos.sql" "20160301" "REM01" "OK" ""
	      echo " OK : DDL_007_ENTITY01_AlterConfigAcuerdos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql 20160118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20160118" "PRODUCTO-585" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_019_ENTITY01_CrearVistaTareaVSProcuradores-REM01-reg3.1.sql > DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql" "20160118" "REM01" "KO" ""
	      echo "@KO@: DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql" "20160118" "REM01" "OK" ""
	      echo " OK : DDL_019_ENTITY01_CrearVistaTareaVSProcuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql 20150622 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150622" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_020_ENTITY01_CrearVistaResolucionesCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_020_ENTITY01_CrearVistaResolucionesCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_020_ENTITY01_CrearVistaResolucionesCategorias-REM01-reg3.1.sql > DDL_020_ENTITY01_CrearVistaResolucionesCategorias.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_020_ENTITY01_CrearVistaResolucionesCategorias.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_020_ENTITY01_CrearVistaResolucionesCategorias.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql" "20150622" "REM01" "KO" ""
	      echo "@KO@: DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql" "20150622" "REM01" "OK" ""
	      echo " OK : DDL_020_ENTITY01_CrearVistaResolucionesCategorias.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql 20150706 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150706" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_022_ENTITY01_CrearVistaBusquedaAsuProc-REM01-reg3.1.sql > DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql" "20150706" "REM01" "KO" ""
	      echo "@KO@: DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql" "20150706" "REM01" "OK" ""
	      echo " OK : DDL_022_ENTITY01_CrearVistaBusquedaAsuProc.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql 20150706 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150706" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_024_ENTITY01_CrearVistaBusquedaAsuntos-REM01-reg3.1.sql > DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql" "20150706" "REM01" "KO" ""
	      echo "@KO@: DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql" "20150706" "REM01" "OK" ""
	      echo " OK : DDL_024_ENTITY01_CrearVistaBusquedaAsuntos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql 20150706 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150706" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario-REM01-reg3.1.sql > DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql" "20150706" "REM01" "KO" ""
	      echo "@KO@: DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql" "20150706" "REM01" "OK" ""
	      echo " OK : DDL_025_ENTITY01_CrearVistaBusquedaAsuntosUsuario.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql 20160525 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql" "REM01" "Alejandro I?igo" "ETL"  "1.00" "20160525" "BKREC-2290" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR-REM01-reg3.1.sql > DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql" "20160525" "REM01" "KO" ""
	      echo "@KO@: DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql" "20160525" "REM01" "OK" ""
	      echo " OK : DDL_026_ENTITY01_CLIENTES_ACTUACIONES_FSR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql 20160307 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql" "REM01" "CARLOS MARTOS E IVAN PICAZO" "online"  "9.2" "20160307" "PRODUCTO-881" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto-REM01-reg3.1.sql > DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql" "20160307" "REM01" "KO" ""
	      echo "@KO@: DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql" "20160307" "REM01" "OK" ""
	      echo " OK : DDL_026_ENTITY01_NuevoCampoProvinciaEnAsunto.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql 20160305 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql" "REM01" "Javier Ruiz" "online"  "9.2.0" "20160305" "CMREC-1859" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI-REM01-reg3.1.sql > DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql" "20160305" "REM01" "KO" ""
	      echo "@KO@: DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql" "20160305" "REM01" "OK" ""
	      echo " OK : DDL_026_ENTITY01_VTAR_TAREA_VS_USUARIO_CLI.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql 20160525 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql" "REM01" "Alejandro I?igo" "ETL"  "1.00" "20160525" "BKREC-2290" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_027_ENTITY01_CNT_ACTUACIONES_FSR-REM01-reg3.1.sql > DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql" "20160525" "REM01" "KO" ""
	      echo "@KO@: DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql" "20160525" "REM01" "OK" ""
	      echo " OK : DDL_027_ENTITY01_CNT_ACTUACIONES_FSR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_027_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V3.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160307" "PRODUCTO-881" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_027_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V3-REM01-reg3.1.sql > DDL_027_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V3.log
echo " -- : DDL_027_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V3.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql 20160305 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "Javier Ruiz" "online"  "9.2.0" "20160305" "CMREC-1859" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160305" "REM01" "KO" ""
	      echo "@KO@: DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160305" "REM01" "OK" ""
	      echo " OK : DDL_027_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql 20160307 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160307" "PRODUCTO-881" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV-REM01-reg3.1.sql > DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql" "20160307" "REM01" "KO" ""
	      echo "@KO@: DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql" "20160307" "REM01" "OK" ""
	      echo " OK : DDL_028_ENTITY01_CREATE_TEMP_TURNADO_PRV.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql 20160308 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql" "REM01" "Carlos Martos" "online"  "9.2.0" "20160308" "PRODUCTO-744" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente-REM01-reg3.1.sql > DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql" "20160308" "REM01" "KO" ""
	      echo "@KO@: DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql" "20160308" "REM01" "OK" ""
	      echo " OK : DDL_028_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroExpediente.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_029_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V4.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160307" "PRODUCTO-881" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_029_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V4-REM01-reg3.1.sql > DDL_029_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V4.log
echo " -- : DDL_029_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V4.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql 20160311 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.0-X" "20160311" "PRODUCTO-894" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC-REM01-reg3.1.sql > DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql" "20160311" "REM01" "KO" ""
	      echo "@KO@: DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql" "20160311" "REM01" "OK" ""
	      echo " OK : DDL_030_ENTITY01_ADD_TIPO_ASUNTO_DD_TAC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_030_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V5.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160307" "PRODUCTO-881" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_030_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V5-REM01-reg3.1.sql > DDL_030_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V5.log
echo " -- : DDL_030_ENTITY01_SP_ASIGNACION_ASUNTOS_TURNADO_PROV_V5.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql 20160315 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "REM01" "Alberto Campos" "online"  "9.2.0" "20160315" "CMREC-2119" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO-REM01-reg3.1.sql > DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160315" "REM01" "KO" ""
	      echo "@KO@: DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql" "20160315" "REM01" "OK" ""
	      echo " OK : DDL_031_ENTITY01_VTAR_TAREA_VS_USUARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql 20160317 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql" "REM01" "Jorge Ros" "online"  "9.2" "20160317" "PRODUCTO-812" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS-REM01-reg3.1.sql > DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql" "20160317" "REM01" "KO" ""
	      echo "@KO@: DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql" "20160317" "REM01" "OK" ""
	      echo " OK : DDL_032_ENTITY01_MODIF_TAM_USUARIOXXX_PCO_OBS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql 20160316 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql" "REM01" "Kevin Fernandez" "online"  "9.2.0" "20160316" "PRODUCTO-874" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion-REM01-reg3.1.sql > DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql" "20160316" "REM01" "KO" ""
	      echo "@KO@: DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql" "20160316" "REM01" "OK" ""
	      echo " OK : DDL_032_ENTITY01_VTAR_TAREA_VS_USUARIO_FiltroProcedimientoYActuacion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql 20160316 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql" "REM01" "Kevin Fernandez" "online"  "9.2.0" "20160316" "PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla-REM01-reg3.1.sql > DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql" "20160316" "REM01" "KO" ""
	      echo "@KO@: DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql" "20160316" "REM01" "OK" ""
	      echo " OK : DDL_033_ENTITY01_CCO_CONTABILIDAD_COBROS_CreacionNuevaTabla.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql 20160322 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql" "REM01" "LUIS CABALLERO" "online"  "9.2" "20160322" "PRODUCTO-953" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos-REM01-reg3.1.sql > DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql" "20160322" "REM01" "KO" ""
	      echo "@KO@: DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql" "20160322" "REM01" "OK" ""
	      echo " OK : DDL_033_ENTITY01_NuevosCamposGastosEnCobrosPagos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql 20160322 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql" "REM01" "LUIS CABALLERO" "online"  "9.2" "20160322" "PRODUCTO-953" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos-REM01-reg3.1.sql > DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql" "20160322" "REM01" "KO" ""
	      echo "@KO@: DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql" "20160322" "REM01" "OK" ""
	      echo " OK : DDL_034_ENTITY01_NuevosCamposDiccEnCobrosPagos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql 20160412 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql" "REM01" "Alberto B." "online"  "9.2.2" "20160412" "CMREC-3059" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_035_ENTITY01_ALTER_TAR_EMISOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_035_ENTITY01_ALTER_TAR_EMISOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_035_ENTITY01_ALTER_TAR_EMISOR-REM01-reg3.1.sql > DDL_035_ENTITY01_ALTER_TAR_EMISOR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_035_ENTITY01_ALTER_TAR_EMISOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_035_ENTITY01_ALTER_TAR_EMISOR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql" "20160412" "REM01" "KO" ""
	      echo "@KO@: DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql" "20160412" "REM01" "OK" ""
	      echo " OK : DDL_035_ENTITY01_ALTER_TAR_EMISOR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql 20160419 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql" "REM01" "Kevin Fernández" "online"  "9.2.0" "20160419" "PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable-REM01-reg3.1.sql > DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql" "20160419" "REM01" "KO" ""
	      echo "@KO@: DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql" "20160419" "REM01" "OK" ""
	      echo " OK : DDL_036_ENTITY01_CCO_CONTABILIDAD_COBROS_AlterTable.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql 20160503 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql" "REM01" " Kevin Fernández" "producto"  "9.2" "20160503" "PRODUCTO-1325" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS-REM01-reg3.1.sql > DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql" "20160503" "REM01" "KO" ""
	      echo "@KO@: DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql" "20160503" "REM01" "OK" ""
	      echo " OK : DDL_037_ENTITY01_UPDATE_CCO_CONTABILIDAD_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql 20160503 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql" "REM01" " Kevin Fernández" "producto"  "9.2" "20160503" "PRODUCTO-1325" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS-REM01-reg3.1.sql > DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql" "20160503" "REM01" "KO" ""
	      echo "@KO@: DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql" "20160503" "REM01" "OK" ""
	      echo " OK : DDL_038_ENTITY01_UPDATE02_CCO_CONTABILIDAD_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_066_MASTER_ALTER_ENTIDAD.sql 20160411 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_066_MASTER_ALTER_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_066_MASTER_ALTER_ENTIDAD.sql" "REMMASTER" "PEDROBLASCO" "online"  "9.2" "20160411" "PRODUCTO-1188" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_066_MASTER_ALTER_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_066_MASTER_ALTER_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_066_MASTER_ALTER_ENTIDAD-REMMASTER-reg3.1.sql > DDL_066_MASTER_ALTER_ENTIDAD.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_066_MASTER_ALTER_ENTIDAD.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_066_MASTER_ALTER_ENTIDAD.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_066_MASTER_ALTER_ENTIDAD.sql" "20160411" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_066_MASTER_ALTER_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_066_MASTER_ALTER_ENTIDAD.sql" "20160411" "REMMASTER" "OK" ""
	      echo " OK : DDL_066_MASTER_ALTER_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql 20160315 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql" "REM01" "PEDROBLASCO" "online"  "9.2" "20160315" "PRODUCTO-881" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_077_ENTITY01_NuevoCampoBurofaxManual.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_077_ENTITY01_NuevoCampoBurofaxManual.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_077_ENTITY01_NuevoCampoBurofaxManual-REM01-reg3.1.sql > DDL_077_ENTITY01_NuevoCampoBurofaxManual.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_077_ENTITY01_NuevoCampoBurofaxManual.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_077_ENTITY01_NuevoCampoBurofaxManual.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql" "20160315" "REM01" "KO" ""
	      echo "@KO@: DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql" "20160315" "REM01" "OK" ""
	      echo " OK : DDL_077_ENTITY01_NuevoCampoBurofaxManual.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql 20160317 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql" "REM01" "Enrique Jiménez Díaz" "batch"  "0.1" "20160317" "PRODUCTO-792" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO-REM01-reg3.1.sql > DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql" "20160317" "REM01" "KO" ""
	      echo "@KO@: DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql" "20160317" "REM01" "OK" ""
	      echo " OK : DDL_078_ENTITY01_DATEJD_CREATE_TABLE_ACN_ANTECEDENTES_CONTRATO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_078_ENTITY01_NuevasColumnasAsuntos.sql 20160321 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_078_ENTITY01_NuevasColumnasAsuntos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_078_ENTITY01_NuevasColumnasAsuntos.sql" "REM01" "Alberto S" "online"  "9.2" "20160321" "PRODUCTO-887" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_078_ENTITY01_NuevasColumnasAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_078_ENTITY01_NuevasColumnasAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_078_ENTITY01_NuevasColumnasAsuntos-REM01-reg3.1.sql > DDL_078_ENTITY01_NuevasColumnasAsuntos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_078_ENTITY01_NuevasColumnasAsuntos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_078_ENTITY01_NuevasColumnasAsuntos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_NuevasColumnasAsuntos.sql" "20160321" "REM01" "KO" ""
	      echo "@KO@: DDL_078_ENTITY01_NuevasColumnasAsuntos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_078_ENTITY01_NuevasColumnasAsuntos.sql" "20160321" "REM01" "OK" ""
	      echo " OK : DDL_078_ENTITY01_NuevasColumnasAsuntos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql 20160117 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql" "REM01" "ENRIQUEJIMENEZ" "online"  "9.2" "20160117" "PRODUCTO-792" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_079_ENTITY01_CALCULO_ANTECEDENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_079_ENTITY01_CALCULO_ANTECEDENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_079_ENTITY01_CALCULO_ANTECEDENTES-REM01-reg3.1.sql > DDL_079_ENTITY01_CALCULO_ANTECEDENTES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_079_ENTITY01_CALCULO_ANTECEDENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_079_ENTITY01_CALCULO_ANTECEDENTES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql" "20160117" "REM01" "KO" ""
	      echo "@KO@: DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql" "20160117" "REM01" "OK" ""
	      echo " OK : DDL_079_ENTITY01_CALCULO_ANTECEDENTES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql" "REM01" "OSCAR DORADO" "online"  "9.2" "20160330" "PRODUCTO-1048" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_080_ENTITY01_Vista_tareas_vs_procuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_080_ENTITY01_Vista_tareas_vs_procuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_080_ENTITY01_Vista_tareas_vs_procuradores-REM01-reg3.1.sql > DDL_080_ENTITY01_Vista_tareas_vs_procuradores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_080_ENTITY01_Vista_tareas_vs_procuradores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_080_ENTITY01_Vista_tareas_vs_procuradores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DDL_080_ENTITY01_Vista_tareas_vs_procuradores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql 20160406 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.2.2" "20160406" "PRODUCTO-1101" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO-REM01-reg3.1.sql > DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql" "20160406" "REM01" "KO" ""
	      echo "@KO@: DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql" "20160406" "REM01" "OK" ""
	      echo " OK : DDL_090_ENTITY01_ADD_PROPUESTA_TO_PROCEDIMIENTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_091_ENTITY01_CostasProcuEnSubasta.sql 20160409 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_091_ENTITY01_CostasProcuEnSubasta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_091_ENTITY01_CostasProcuEnSubasta.sql" "REM01" "Óscar Dorado" "online"  "9.2" "20160409" "PRODUCTO-1119" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_091_ENTITY01_CostasProcuEnSubasta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_091_ENTITY01_CostasProcuEnSubasta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_091_ENTITY01_CostasProcuEnSubasta-REM01-reg3.1.sql > DDL_091_ENTITY01_CostasProcuEnSubasta.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_091_ENTITY01_CostasProcuEnSubasta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_091_ENTITY01_CostasProcuEnSubasta.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_091_ENTITY01_CostasProcuEnSubasta.sql" "20160409" "REM01" "KO" ""
	      echo "@KO@: DDL_091_ENTITY01_CostasProcuEnSubasta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_091_ENTITY01_CostasProcuEnSubasta.sql" "20160409" "REM01" "OK" ""
	      echo " OK : DDL_091_ENTITY01_CostasProcuEnSubasta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_092_ENTITY01_PostoresEnBien.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_092_ENTITY01_PostoresEnBien.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_092_ENTITY01_PostoresEnBien.sql" "REM01" "Óscar Dorado" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_092_ENTITY01_PostoresEnBien.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_092_ENTITY01_PostoresEnBien.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_092_ENTITY01_PostoresEnBien-REM01-reg3.1.sql > DDL_092_ENTITY01_PostoresEnBien.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_092_ENTITY01_PostoresEnBien.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_092_ENTITY01_PostoresEnBien.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_092_ENTITY01_PostoresEnBien.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_092_ENTITY01_PostoresEnBien.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_092_ENTITY01_PostoresEnBien.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_092_ENTITY01_PostoresEnBien.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql 20160610 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql" "REM01" "Kevin Fernández" "online"  "9.2" "20160610" "PRODUCTO-1491" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario-REM01-reg3.1.sql > DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql" "20160610" "REM01" "KO" ""
	      echo "@KO@: DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql" "20160610" "REM01" "OK" ""
	      echo " OK : DDL_093_ENTITY01_DD_OOF_ORIGEN_OFICINA_CreacionNuevoDiccionario.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql 20160405 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql" "REM01" "IVAN PICAZO PICAZO" "online"  "9.1.0-X" "20160405" "PRODUCTO-1161" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS-REM01-reg3.1.sql > DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql" "20160405" "REM01" "KO" ""
	      echo "@KO@: DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql" "20160405" "REM01" "OK" ""
	      echo " OK : DDL_100_ENTITY01_ALTER_ADA_ADJUNTOS_ASUNTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql 18-04-2016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql" "REM01" "RAFAEL ARACIL LOPEZ" "BIE_BIEN"  "9.2" "18-04-2016" "HR-2286" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID-REM01-reg3.1.sql > DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql" "18-04-2016" "REM01" "KO" ""
	      echo "@KO@: DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql" "18-04-2016" "REM01" "OK" ""
	      echo " OK : DDL_101_ENTITY01_BIE_SAREB_ID_TO_BIE_HAYA_ID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql 20160413 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160413" "PRODUCTO-1114" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR-REM01-reg3.1.sql > DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql" "20160413" "REM01" "KO" ""
	      echo "@KO@: DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql" "20160413" "REM01" "OK" ""
	      echo " OK : DDL_101_ENTITY01_CREATE_TABLE_MTC_MAPEO_CONTENEDOR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql 26-04-2016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql" "REM01" "RAFAEL ARACIL LOPEZ" "BIE_BIEN"  "9.2" "26-04-2016" "HR-2286" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN-REM01-reg3.1.sql > DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql" "26-04-2016" "REM01" "KO" ""
	      echo "@KO@: DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql" "26-04-2016" "REM01" "OK" ""
	      echo " OK : DDL_102_ENTITY01_ALTER_TABLE_BIE_ENTIDAD_ID_BIE_BIEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql 20160505 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.0-X" "20160505" "PRODUCTO-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS-REM01-reg3.1.sql > DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql" "20160505" "REM01" "KO" ""
	      echo "@KO@: DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql" "20160505" "REM01" "OK" ""
	      echo " OK : DDL_103_ENTITY01_ALTER_ADC_ADJUNTOS_CONTRATOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql 20160530 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql" "REM01" "PEDROBLASCO" "ONLINE"  "9.2" "20160530" "PRODUCTO-478" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES-REM01-reg3.1.sql > DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql" "20160530" "REM01" "KO" ""
	      echo "@KO@: DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql" "20160530" "REM01" "OK" ""
	      echo " OK : DDL_103_ENTITY01_ALTER_TABLE_BIE_DATOS_REGISTRALES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql 20160505 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.0-X" "20160505" "PRODUCTO-1118" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS-REM01-reg3.1.sql > DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql" "20160505" "REM01" "KO" ""
	      echo "@KO@: DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql" "20160505" "REM01" "OK" ""
	      echo " OK : DDL_104_ENTITY01_ALTER_ADP_ADJUNTOS_PERSONAS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160502" "PRODUCTO-1272" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS-REM01-reg3.1.sql > DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DDL_110_ENTITY01_CREATE_DEE_DESPACHO_EXTRAS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql 20160605 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql" "REM01" "JORGE ROS" "producto"  "9.2" "20160605" "PRODUCTO-1272" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO-REM01-reg3.1.sql > DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql" "20160605" "REM01" "KO" ""
	      echo "@KO@: DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql" "20160605" "REM01" "OK" ""
	      echo " OK : DDL_111_ENTITY01_CREATE_DEA_DESPACHO_EXTRAS_AMBITO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql 20160204 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql" "REM01" "José Luis Gauxachs" "web"  "v_Febrero" "20160204" "CMREC-2026" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional-REM01-reg3.1.sql > DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql" "20160204" "REM01" "KO" ""
	      echo "@KO@: DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql" "20160204" "REM01" "OK" ""
	      echo " OK : DDL_348_ENTITY01_Constraint_Contrato_RiesgoOperacional.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql" "REM01" "Javier Ruiz" "online"  "9.2.0" "20160330" "PRODUCTO-1063" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES-REM01-reg3.1.sql > DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DDL_349_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_AlterDataRuleEngine.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_AlterDataRuleEngine.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_AlterDataRuleEngine.sql" "REM01" "Manuel Mejias" "online"  "9.1.0-cj-rc29.1" "20160330" "CMREC-2907" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_AlterDataRuleEngine.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_AlterDataRuleEngine.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_AlterDataRuleEngine-REM01-reg3.1.sql > DDL_350_ENTITY01_AlterDataRuleEngine.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_AlterDataRuleEngine.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_AlterDataRuleEngine.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_AlterDataRuleEngine.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_AlterDataRuleEngine.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_AlterDataRuleEngine.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_AlterDataRuleEngine.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma-REM01-reg3.1.sql > DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_nuevaTablaDiccionarioAsistenciaAFirma.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir-REM01-reg3.1.sql > DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_nuevaTablaDiccionarioDesistir.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta-REM01-reg3.1.sql > DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_nuevaTablaDiccionarioGestionVenta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado-REM01-reg3.1.sql > DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_nuevaTablaDiccionarioResolucionAcreditado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql" "REM01" "CARLOS MARTOS" "online"  "9.2.0" "20160330" "PRODUCTO-744" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION-REM01-reg3.1.sql > DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DDL_350_ENTITY01_VTAR_TAREAS_VS_USUARIO_MEZCLADA_VERSIONES_CORRECCION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision-REM01-reg3.1.sql > DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DDL_351_ENTITY01_nuevaTablaDiccionarioResultadoRevision.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql 20163030 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1.0-cj-rc36.1-CMREC-1907s" "20163030" "CMREC-2907" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907-REM01-reg3.1.sql > DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql" "20163030" "REM01" "KO" ""
	      echo "@KO@: DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql" "20163030" "REM01" "OK" ""
	      echo " OK : DDL_351_ENTITY01_REFRESH_DATA_RULE_ENGINE_CMREC2907.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioCuantia.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioDecisionSuspElect.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioEntidadCesionRemate.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoNoPagarTasa.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioMotivoSuspSubastaElect.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioResolucionPagoTasa.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoComiteSub.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores-REM01-reg3.1.sql > DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DDL_352_ENTITY01_nuevaTablaDiccionarioResultadoPostores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql 20160418 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql" "REM01" "Carlos Martos" "online"  "9.2" "20160418" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional-REM01-reg3.1.sql > DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql" "20160418" "REM01" "KO" ""
	      echo "@KO@: DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql" "20160418" "REM01" "OK" ""
	      echo " OK : DDL_353_ENTITY01_nuevaTablaDiccionarioFavorableCondicional.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql 20160413 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.2.3" "20160413" "PRODUCTO-1241" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO-REM01-reg3.1.sql > DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql" "20160413" "REM01" "KO" ""
	      echo "@KO@: DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql" "20160413" "REM01" "OK" ""
	      echo " OK : DDL_360_ENTITY01_ADD_ORDER_DD_EPI_EST_POL_ITINERARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql 20160415 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql" "REM01" "Luis Caballero" "producto"  "9.1" "20160415" "PRODUCTO-1242" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO-REM01-reg3.1.sql > DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql" "20160415" "REM01" "KO" ""
	      echo "@KO@: DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql" "20160415" "REM01" "OK" ""
	      echo " OK : DDL_361_ENTITY01_ALTER_TABLE_CMP_OBLIGATORIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql 20160606 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql" "REM01" "Vicente Lozano" "producto"  "9.2.6" "20160606" "PRODUCTO-1659" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659-REM01-reg3.1.sql > DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql" "20160606" "REM01" "KO" ""
	      echo "@KO@: DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql" "20160606" "REM01" "OK" ""
	      echo " OK : DDL_361_ENTITY01_ALTER_TABLE_CRI_RIESGO_OPERACIONAL_PROD_1659.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar-REM01-reg3.1.sql > DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DDL_362_ENTITY01_nuevoDiccionarioMovitoNoLitigar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_362_ENTITY01_nuevoDiccionarioPrioridad.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_362_ENTITY01_nuevoDiccionarioPrioridad.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_362_ENTITY01_nuevoDiccionarioPrioridad-REM01-reg3.1.sql > DDL_362_ENTITY01_nuevoDiccionarioPrioridad.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_362_ENTITY01_nuevoDiccionarioPrioridad.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_362_ENTITY01_nuevoDiccionarioPrioridad.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DDL_362_ENTITY01_nuevoDiccionarioPrioridad.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_363_ENTITY01_nuevoCampoPCOProcedimientos-REM01-reg3.1.sql > DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DDL_363_ENTITY01_nuevoCampoPCOProcedimientos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_363_ENTITY01_nuevoCampoPrcProcedimientos-REM01-reg3.1.sql > DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DDL_363_ENTITY01_nuevoCampoPrcProcedimientos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql 20160506 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160506" "PRODUCTO-1315" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud-REM01-reg3.1.sql > DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql" "20160506" "REM01" "KO" ""
	      echo "@KO@: DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql" "20160506" "REM01" "OK" ""
	      echo " OK : DDL_364_ENTITY01_nuevoDiccionarioTipoSolicitud.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql 20160404 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2" "20160404" "PRODUCTO-1323" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO-REM01-reg3.1.sql > DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql" "20160404" "REM01" "KO" ""
	      echo "@KO@: DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql" "20160404" "REM01" "OK" ""
	      echo " OK : DDL_365_ENTITY01_CREATE_DD_ECA_ESTADO_CALCULO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql 20160510 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160510" "PRODUCTO-1315" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar-REM01-reg3.1.sql > DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql" "20160510" "REM01" "KO" ""
	      echo "@KO@: DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql" "20160510" "REM01" "OK" ""
	      echo " OK : DDL_365_ENTITY01_nuevoDiccionarioAceptarSubsanar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql 20160404 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2" "20160404" "PRODUCTO-1323" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION-REM01-reg3.1.sql > DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql" "20160404" "REM01" "KO" ""
	      echo "@KO@: DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql" "20160404" "REM01" "OK" ""
	      echo " OK : DDL_366_ENTITY01_CREATE_CAL_CALCULO_LIQUIDACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql 20160504 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql" "REM01" "Luis Caballero" "web"  "9.2" "20160504" "PRODUCTO-1323" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL-REM01-reg3.1.sql > DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql" "20160504" "REM01" "KO" ""
	      echo "@KO@: DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql" "20160504" "REM01" "OK" ""
	      echo " OK : DDL_366_ENTITY01_CREATE_TABLE_ATI_ACTUALIZA_TIPO_INTERES_CAL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql 20160404 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2" "20160404" "PRODUCTO-1323" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION-REM01-reg3.1.sql > DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql" "20160404" "REM01" "KO" ""
	      echo "@KO@: DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql" "20160404" "REM01" "OK" ""
	      echo " OK : DDL_367_ENTITY01_CREATE_ENT_CAL_LIQUIDACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql 20160512 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql" "REM01" "Enrique Badenes" "online"  "9.2" "20160512" "PRODUCTO-1082" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA-REM01-reg3.1.sql > DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql" "20160512" "REM01" "KO" ""
	      echo "@KO@: DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql" "20160512" "REM01" "OK" ""
	      echo " OK : DDL_368_ENTITY01_ALTER_TABLE_ADA_ADJUNTOS_ASUNTOS_NUEVA_COLUMNA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql 20160517 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql" "REM01" "Javier Ruiz" "online"  "2.9.4" "20160517" "PRODUCTO-1349" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES-REM01-reg3.1.sql > DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql" "20160517" "REM01" "KO" ""
	      echo "@KO@: DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql" "20160517" "REM01" "OK" ""
	      echo " OK : DDL_368_ENTITY01_CREATE_DEL_ZPU_DELEGACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql 20160513 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql" "REM01" "Luis Caballero" "online"  "9.2.5" "20160513" "PRODUCTO-1357" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX-REM01-reg3.1.sql > DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql" "20160513" "REM01" "KO" ""
	      echo "@KO@: DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql" "20160513" "REM01" "OK" ""
	      echo " OK : DDL_368_ENTITY01_create_index_CRC_CICLO_y_ACE_ACCIONES_EX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql 20160517 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql" "REM01" "Luis Caballero" "online"  "9.2.5" "20160517" "PRODUCTO-1358" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS-REM01-reg3.1.sql > DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql" "20160517" "REM01" "KO" ""
	      echo "@KO@: DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql" "20160517" "REM01" "OK" ""
	      echo " OK : DDL_369_ENTITY01_create_index_CPA_COCBROS_PAGOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql 20160524 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160524" "PRODUCTO-1533" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar-REM01-reg3.1.sql > DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql" "20160524" "REM01" "KO" ""
	      echo "@KO@: DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql" "20160524" "REM01" "OK" ""
	      echo " OK : DDL_369_ENTITY01_nuevoDiccionarioTipoPrcIniciar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql 20160527 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql" "REM01" "ENRIQUE BADENES" "producto"  "9.2" "20160527" "PRODUCTO-1630" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN-REM01-reg3.1.sql > DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql" "20160527" "REM01" "KO" ""
	      echo "@KO@: DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql" "20160527" "REM01" "OK" ""
	      echo " OK : DDL_370_ENTITY01_ALTER_TABLE_ADA_ADD_COLUMN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql 20160603 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql" "REM01" "Alberto Soler" "producto"  "9.2" "20160603" "PRODUCTO-1861" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu-REM01-reg3.1.sql > DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql" "20160603" "REM01" "KO" ""
	      echo "@KO@: DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql" "20160603" "REM01" "OK" ""
	      echo " OK : DDL_371_ENTITY01_CreacionTablaHistTurnadoProcu.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql 20160606 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql" "REM01" "IVAN PICAZO" "online"  "9.2.6" "20160606" "PRODUCTO-1444" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS-REM01-reg3.1.sql > DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql" "20160606" "REM01" "KO" ""
	      echo "@KO@: DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql" "20160606" "REM01" "OK" ""
	      echo " OK : DDL_372_ENTITY01_NUEVO_CAMPO_ASUNTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_375_ENTITY01_NuevoCampoEstEstados.sql 20160603 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_375_ENTITY01_NuevoCampoEstEstados.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_375_ENTITY01_NuevoCampoEstEstados.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.2.6" "20160603" "PRODUCTO-1673" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_375_ENTITY01_NuevoCampoEstEstados.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_375_ENTITY01_NuevoCampoEstEstados.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_375_ENTITY01_NuevoCampoEstEstados-REM01-reg3.1.sql > DDL_375_ENTITY01_NuevoCampoEstEstados.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_375_ENTITY01_NuevoCampoEstEstados.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_375_ENTITY01_NuevoCampoEstEstados.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_375_ENTITY01_NuevoCampoEstEstados.sql" "20160603" "REM01" "KO" ""
	      echo "@KO@: DDL_375_ENTITY01_NuevoCampoEstEstados.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_375_ENTITY01_NuevoCampoEstEstados.sql" "20160603" "REM01" "OK" ""
	      echo " OK : DDL_375_ENTITY01_NuevoCampoEstEstados.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql 20160610 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql" "REM01" "Luis Caballero" "online"  "9.2.6" "20160610" "PRODUCTO-1959" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA-REM01-reg3.1.sql > DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql" "20160610" "REM01" "KO" ""
	      echo "@KO@: DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql" "20160610" "REM01" "OK" ""
	      echo " OK : DDL_377_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql 20160615 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql" "REM01" "Luis Caballero" "online"  "9.2.6" "20160615" "PRODUCTO-1999" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA-REM01-reg3.1.sql > DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql" "20160615" "REM01" "KO" ""
	      echo "@KO@: DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql" "20160615" "REM01" "OK" ""
	      echo " OK : DDL_378_ENTITY01_ALTER_SPR_SOLICITUD_PRORROGA_CAMPO_FECHA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql 20160607 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "20160607" "PRODUCTO-1635" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES-REM01-reg3.1.sql > DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "20160607" "REM01" "KO" ""
	      echo "@KO@: DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql" "20160607" "REM01" "OK" ""
	      echo " OK : DDL_380_ENTITY01_ALTER_TABLE_PCO_DOC_SOLICITUDES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql 20160607 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "20160607" "PRODUCTO-1635" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO-REM01-reg3.1.sql > DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql" "20160607" "REM01" "KO" ""
	      echo "@KO@: DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql" "20160607" "REM01" "OK" ""
	      echo " OK : DDL_381_ENTITY01_ALTER_TABLE_DES_DESPACHO_EXTERNO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql 20160607 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql" "REM01" "MANUEL MEJIAS" "web"  "9.1" "20160607" "PRODUCTO-1635" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES-REM01-reg3.1.sql > DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql" "20160607" "REM01" "KO" ""
	      echo "@KO@: DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql" "20160607" "REM01" "OK" ""
	      echo " OK : DDL_382_ENTITY01_ALTER_TABLE_EXP_EXPEDIENTES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql 20160613 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql" "REM01" "Luis Ruiz" "online"  "9.2.6" "20160613" "PRODUCTO-1797" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID-REM01-reg3.1.sql > DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql" "20160613" "REM01" "KO" ""
	      echo "@KO@: DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql" "20160613" "REM01" "OK" ""
	      echo " OK : DDL_382_ENTITY01_CREATE_INDEX_ASU_USD_ID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql 20160628 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql" "REM01" "PEDRO BLASCO" "online"  "9.2.6" "20160628" "RECOVERY-1837" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID-REM01-reg3.1.sql > DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql" "20160628" "REM01" "KO" ""
	      echo "@KO@: DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql" "20160628" "REM01" "OK" ""
	      echo " OK : DDL_383_ENTITY01_CREATE_INDEX_ASU_DD_DFI_ID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql 20160613 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql" "REM01" "MANUEL MEJIAS" "producto"  "9.2" "20160613" "PRODUCTO-1708" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE-REM01-reg3.1.sql > DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql" "20160613" "REM01" "KO" ""
	      echo "@KO@: DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql" "20160613" "REM01" "OK" ""
	      echo " OK : DDL_400_ENTITY01_ALTER_TABLE_SAE_SANCION_EXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql 20160614 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql" "REM01" "PEDRO BLASCO" "online"  "v9.2.5-bk" "20160614" "PRODUCTO-1451" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla-REM01-reg3.1.sql > DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql" "20160614" "REM01" "KO" ""
	      echo "@KO@: DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql" "20160614" "REM01" "OK" ""
	      echo " OK : DDL_400_ENTITY01_CreacionTablaTipoProdPlantilla.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql 20160524 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql" "REM01" "Vicente Lozano" "online"  "9.2" "20160524" "PRODUCTO-1579" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579-REM01-reg3.1.sql > DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql" "20160524" "REM01" "KO" ""
	      echo "@KO@: DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql" "20160524" "REM01" "OK" ""
	      echo " OK : DDL_902_ENTITY01_CREATE_IDX_TUP_PROD-1579.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql 20160509 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql" "REM01" "José Luis Gauxachs" "online"  "9.2.0" "20160509" "HR-1125" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_999_ENTITY01_ModificarTamanyoCampoUsurname-REM01-reg3.1.sql > DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql" "20160509" "REM01" "KO" ""
	      echo "@KO@: DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql" "20160509" "REM01" "OK" ""
	      echo " OK : DDL_999_ENTITY01_ModificarTamanyoCampoUsurname.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_999_ENTITY01_ProcesoFinal.sql 20150219 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_999_ENTITY01_ProcesoFinal.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_999_ENTITY01_ProcesoFinal.sql" "REM01" "PEDROBLASCO" "online"  "9.2" "20150219" "NOITEM" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REM01_DDL_999_ENTITY01_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REM01_DDL_999_ENTITY01_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_999_ENTITY01_ProcesoFinal-REM01-reg3.1.sql > DDL_999_ENTITY01_ProcesoFinal.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REM01_DDL_999_ENTITY01_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REM01_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REM01_DDL_999_ENTITY01_ProcesoFinal.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_ENTITY01_ProcesoFinal.sql" "20150219" "REM01" "KO" ""
	      echo "@KO@: DDL_999_ENTITY01_ProcesoFinal.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_ENTITY01_ProcesoFinal.sql" "20150219" "REM01" "OK" ""
	      echo " OK : DDL_999_ENTITY01_ProcesoFinal.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql 20160510 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql" "REMMASTER" "José Luis Gauxachs" "online"  "9.2.0" "20160510" "HR-1125" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_999_MASTER_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_999_MASTER_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_999_MASTER_ModificarTamanyoCampoUsurname-REMMASTER-reg3.1.sql > DDL_999_MASTER_ModificarTamanyoCampoUsurname.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_999_MASTER_ModificarTamanyoCampoUsurname.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_999_MASTER_ModificarTamanyoCampoUsurname.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql" "20160510" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql" "20160510" "REMMASTER" "OK" ""
	      echo " OK : DDL_999_MASTER_ModificarTamanyoCampoUsurname.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg2.sql DDL_999_MASTER_ProcesoFinal.sql 20150219 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DDL_999_MASTER_ProcesoFinal.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_999_MASTER_ProcesoFinal.sql" "REMMASTER" "PEDROBLASCO" "online"  "9.2" "20150219" "NOITEM" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_PREV_tables_REMMASTER_DDL_999_MASTER_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_PREV_objects_REMMASTER_DDL_999_MASTER_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_999_MASTER_ProcesoFinal-REMMASTER-reg3.1.sql > DDL_999_MASTER_ProcesoFinal.log
	  export RESULTADO=$?
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_tables.sql > DB_SNAPSHOT_POST_tables_REMMASTER_DDL_999_MASTER_ProcesoFinal.log
	  exit | sqlplus -s -l $1 @./scripts/DDL_000_REMMASTER_metadata_objects.sql > DB_SNAPSHOT_POST_objects_REMMASTER_DDL_999_MASTER_ProcesoFinal.log
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_MASTER_ProcesoFinal.sql" "20150219" "REMMASTER" "KO" ""
	      echo "@KO@: DDL_999_MASTER_ProcesoFinal.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg4.sql "DDL_999_MASTER_ProcesoFinal.sql" "20150219" "REMMASTER" "OK" ""
	      echo " OK : DDL_999_MASTER_ProcesoFinal.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_001_ENTITY01_VI_VTAR_TAREAS_VS_USUARIO.sql" "REM01" "Luis Ruiz" "online"  "9.2.6" "20160627" "PRODUCTO-1797" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_001_ENTITY01_VI_VTAR_TAREAS_VS_USUARIO-REM01-reg3.1.sql > DDL_001_ENTITY01_VI_VTAR_TAREAS_VS_USUARIO.log
echo " -- : DDL_001_ENTITY01_VI_VTAR_TAREAS_VS_USUARIO.sql"
	exit | sqlplus -s -l $1 @./scripts/DDL_000_ENTITY01_reg3.sql "DDL_002_ENTITY01_SP_CAMBIO_MASIVOS_GESTOR.sql" "REM01" "Miguel Ángel Sánchez" "batch"  "9.2.7" "20160622" "RECOVERY-2105" "SI"
	exit | sqlplus -s -l $1 @./scripts/DDL_002_ENTITY01_SP_CAMBIO_MASIVOS_GESTOR-REM01-reg3.1.sql > DDL_002_ENTITY01_SP_CAMBIO_MASIVOS_GESTOR.log
echo " -- : DDL_002_ENTITY01_SP_CAMBIO_MASIVOS_GESTOR.sql"
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql 20151002 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151002" "PRODUCTO-283" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas-REMMASTER-reg3.1.sql > DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql" "20151002" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql" "20151002" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_DD_EST_ESTADOS_ITINERARIOS-FormalizacionPropuestas.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql 20151006 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151006" "PRODUCTO-283" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta-REMMASTER-reg3.1.sql > DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql" "20151006" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql" "20151006" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_DD_STA_SUBTIPO_TAREA_BASE-subtareaPropuesta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql 20151001 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151001" "PRODUCTO-282" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta-REMMASTER-reg3.1.sql > DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "20151001" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "20151001" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql 20151104 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151104" "PRODUCTO-396" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal-REMMASTER-reg3.1.sql > DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql" "20151104" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql" "20151104" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_FUN_FUNCIONES-insertFuncionFichaGlobal.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql 20151110 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151110" "CMREC-960" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas-REMMASTER-reg3.1.sql > DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql" "20151110" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql" "20151110" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_FUN_FUNCIONES_MuestraDocumentoCancelacionCargas.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql 20151022 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql" "REMMASTER" "Alberto B" "online"  "9.1" "20151022" "PRODUCTO-342" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE-REMMASTER-reg3.1.sql > DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql" "20151022" "REMMASTER" "KO" ""
	      echo "@KO@: DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql" "20151022" "REMMASTER" "OK" ""
	      echo " OK : DML_000_MASTER_FUN_FUNCIONES_NuevoPermisoPROPRE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_BANK01_BPMPrecontencioso.sql 20150728 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_BANK01_BPMPrecontencioso.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_BANK01_BPMPrecontencioso.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150728" "PRODUCTO-130" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_BANK01_BPMPrecontencioso-REM01-reg3.1.sql > DML_001_BANK01_BPMPrecontencioso.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_BANK01_BPMPrecontencioso.sql" "20150728" "REM01" "KO" ""
	      echo "@KO@: DML_001_BANK01_BPMPrecontencioso.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_BANK01_BPMPrecontencioso.sql" "20150728" "REM01" "OK" ""
	      echo " OK : DML_001_BANK01_BPMPrecontencioso.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_ENTITY01_BPMPrecontencioso_02.sql 20151117 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_ENTITY01_BPMPrecontencioso_02.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_ENTITY01_BPMPrecontencioso_02.sql" "REM01" "Alberto Campos" "producto"  "9.1" "20151117" "PRODUCTO-130" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_ENTITY01_BPMPrecontencioso_02-REM01-reg3.1.sql > DML_001_ENTITY01_BPMPrecontencioso_02.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_BPMPrecontencioso_02.sql" "20151117" "REM01" "KO" ""
	      echo "@KO@: DML_001_ENTITY01_BPMPrecontencioso_02.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_BPMPrecontencioso_02.sql" "20151117" "REM01" "OK" ""
	      echo " OK : DML_001_ENTITY01_BPMPrecontencioso_02.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql 20151002 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "REM01" "Alberto B" "online"  "9.1" "20151002" "PRODUCTO-334" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS-REM01-reg3.1.sql > DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "20151002" "REM01" "KO" ""
	      echo "@KO@: DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql" "20151002" "REM01" "OK" ""
	      echo " OK : DML_001_ENTITY01_INSERT_DD_TDV_TRAMOS_DIAS_VENCIDOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_004_ENTITY01_InsertarEstadoProceso.sql 20150601 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_004_ENTITY01_InsertarEstadoProceso.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_004_ENTITY01_InsertarEstadoProceso.sql" "REM01" "DANIEL GUTIERREZ" "online"  "9.1.0-X" "20150601" "MITCDD-2068" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_004_ENTITY01_InsertarEstadoProceso-REM01-reg3.1.sql > DML_004_ENTITY01_InsertarEstadoProceso.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_InsertarEstadoProceso.sql" "20150601" "REM01" "KO" ""
	      echo "@KO@: DML_004_ENTITY01_InsertarEstadoProceso.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_InsertarEstadoProceso.sql" "20150601" "REM01" "OK" ""
	      echo " OK : DML_004_ENTITY01_InsertarEstadoProceso.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_004_ENTITY01_SEG_PRODUCTO_67.sql 20150803 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_004_ENTITY01_SEG_PRODUCTO_67.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_004_ENTITY01_SEG_PRODUCTO_67.sql" "REM01" "ALBERTO RAMÍREZ LOSILLA" "online"  "9.1" "20150803" "PRODUCTO-67" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_004_ENTITY01_SEG_PRODUCTO_67-REM01-reg3.1.sql > DML_004_ENTITY01_SEG_PRODUCTO_67.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_SEG_PRODUCTO_67.sql" "20150803" "REM01" "KO" ""
	      echo "@KO@: DML_004_ENTITY01_SEG_PRODUCTO_67.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_SEG_PRODUCTO_67.sql" "20150803" "REM01" "OK" ""
	      echo " OK : DML_004_ENTITY01_SEG_PRODUCTO_67.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_007_MASTER_SEG_PRODUCTO_188.sql 20150824 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_007_MASTER_SEG_PRODUCTO_188.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_007_MASTER_SEG_PRODUCTO_188.sql" "REMMASTER" "ALBERTO RAMÍREZ" "online"  "9.1" "20150824" "PRODUCTO-188" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_007_MASTER_SEG_PRODUCTO_188-REMMASTER-reg3.1.sql > DML_007_MASTER_SEG_PRODUCTO_188.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_007_MASTER_SEG_PRODUCTO_188.sql" "20150824" "REMMASTER" "KO" ""
	      echo "@KO@: DML_007_MASTER_SEG_PRODUCTO_188.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_007_MASTER_SEG_PRODUCTO_188.sql" "20150824" "REMMASTER" "OK" ""
	      echo " OK : DML_007_MASTER_SEG_PRODUCTO_188.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql 20151001 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "REM01" "Alberto B" "online"  "9.1" "20151001" "PRODUCTO-282" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta-REM01-reg3.1.sql > DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "20151001" "REM01" "KO" ""
	      echo "@KO@: DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql" "20151001" "REM01" "OK" ""
	      echo " OK : DML_008_ENTITY01_DD_TRE_TIPO_REGLAS_ELEVACION-GestionarPropuesta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_008_ENTITY01_SEG_PRODUCTO_188.sql 20150824 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_008_ENTITY01_SEG_PRODUCTO_188.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_008_ENTITY01_SEG_PRODUCTO_188.sql" "REM01" "ALBERTO RAMÍREZ" "online"  "9.1" "20150824" "PRODUCTO-188" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_008_ENTITY01_SEG_PRODUCTO_188-REM01-reg3.1.sql > DML_008_ENTITY01_SEG_PRODUCTO_188.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_ENTITY01_SEG_PRODUCTO_188.sql" "20150824" "REM01" "KO" ""
	      echo "@KO@: DML_008_ENTITY01_SEG_PRODUCTO_188.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_ENTITY01_SEG_PRODUCTO_188.sql" "20150824" "REM01" "OK" ""
	      echo " OK : DML_008_ENTITY01_SEG_PRODUCTO_188.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql 20150702 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150702" "PRODUCTO-52" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES-REM01-reg3.1.sql > DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql" "20150702" "REM01" "KO" ""
	      echo "@KO@: DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql" "20150702" "REM01" "OK" ""
	      echo " OK : DML_012_HAYA01_FUN_TAB_TITULOS_EXPEDIENTES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql 20150824 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20150824" "PRODUCTO-49" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS-REM01-reg3.1.sql > DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql" "20150824" "REM01" "KO" ""
	      echo "@KO@: DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql" "20150824" "REM01" "OK" ""
	      echo " OK : DML_014_HAYA01_UPDATE_MRA_ARQ_ARQUETIPOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql 20151015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20151015" "PRODUCTO-247" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA-REM01-reg3.1.sql > DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "20151015" "REM01" "KO" ""
	      echo "@KO@: DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "20151015" "REM01" "OK" ""
	      echo " OK : DML_015_HAYA01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql 20151116 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql" "REM01" "Alberto Campos" "online"  "9.1" "20151116" "PRODUCTO-422" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02-REM01-reg3.1.sql > DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql" "20151116" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql" "20151116" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_DD_PCO_LIQ_ESTADO_02.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql 20150707 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql" "REM01" "Jorge Martin" "online"  "9.1" "20150707" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_DD_PCO_LIQ_ESTADO-REM01-reg3.1.sql > DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql" "20150707" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql" "20150707" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_DD_PCO_LIQ_ESTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql 20150715 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql" "REM01" "Jorge Martin" "online"  "9.1" "20150715" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO-REM01-reg3.1.sql > DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql" "20150715" "REM01" "KO" ""
	      echo "@KO@: DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql" "20150715" "REM01" "OK" ""
	      echo " OK : DML_021_ENTITY01_INSERT_GESTORTIPO_APODERADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql" "REM01" "PedroBlasco" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_DD_PCO_DOC_ESTADO-REM01-reg3.1.sql > DML_022_ENTITY01_DD_PCO_DOC_ESTADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_DD_PCO_DOC_ESTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "REM01" "PedroBlasco" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO-REM01-reg3.1.sql > DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_023_ENTITY01_DD_PCO_DOC_SOLICIT_RESULTADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql" "REM01" "Agustin Mompo" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION-REM01-reg3.1.sql > DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_DD_PCO_PRC_ESTADO_PREPARACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql" "REM01" "Agustin Mompo" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION-REM01-reg3.1.sql > DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_025_ENTITY01_DD_PCO_PRC_TIPO_PREPARACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql" "REM01" "Agustin Mompo" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION-REM01-reg3.1.sql > DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_026_ENTITY01_DD_PCO_DOC_UNIDADGESTION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "REM01" "Agustin Mompo" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR-REM01-reg3.1.sql > DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_027_ENTITY01_DD_PCO_DOC_SOLICIT_TIPOACTOR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql 20150716 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql" "REM01" "PedroBlasco" "online"  "9.1" "20150716" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_028_ENTITY01_DD_SNN_SINONOAPLICA-REM01-reg3.1.sql > DML_028_ENTITY01_DD_SNN_SINONOAPLICA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql" "20150716" "REM01" "KO" ""
	      echo "@KO@: DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql" "20150716" "REM01" "OK" ""
	      echo " OK : DML_028_ENTITY01_DD_SNN_SINONOAPLICA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_030_ENTITY01_RESULTADO_BUROFAX.sql 20150803 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_030_ENTITY01_RESULTADO_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_030_ENTITY01_RESULTADO_BUROFAX.sql" "REM01" "Vicente Lozano" "online"  "9.1" "20150803" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_030_ENTITY01_RESULTADO_BUROFAX-REM01-reg3.1.sql > DML_030_ENTITY01_RESULTADO_BUROFAX.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_030_ENTITY01_RESULTADO_BUROFAX.sql" "20150803" "REM01" "KO" ""
	      echo "@KO@: DML_030_ENTITY01_RESULTADO_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_030_ENTITY01_RESULTADO_BUROFAX.sql" "20150803" "REM01" "OK" ""
	      echo " OK : DML_030_ENTITY01_RESULTADO_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_031_ENTITY01_ESTADO_BUROFAX.sql 20150803 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_031_ENTITY01_ESTADO_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_031_ENTITY01_ESTADO_BUROFAX.sql" "REM01" "Vicente Lozano" "online"  "9.1" "20150803" "PRODUCTO-76" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_031_ENTITY01_ESTADO_BUROFAX-REM01-reg3.1.sql > DML_031_ENTITY01_ESTADO_BUROFAX.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_031_ENTITY01_ESTADO_BUROFAX.sql" "20150803" "REM01" "KO" ""
	      echo "@KO@: DML_031_ENTITY01_ESTADO_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_031_ENTITY01_ESTADO_BUROFAX.sql" "20150803" "REM01" "OK" ""
	      echo " OK : DML_031_ENTITY01_ESTADO_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql 20150901 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql" "REM01" "Vicente Lozano" "online"  "9.1" "20150901" "PRODUCTO-231" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO-REM01-reg3.1.sql > DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql" "20150901" "REM01" "KO" ""
	      echo "@KO@: DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql" "20150901" "REM01" "OK" ""
	      echo " OK : DML_033_ENTITY01_CAMBIO_DESCRIPCION_PRETURNADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql 20151117 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql" "REM01" "Alberto Campos" "producto"  "9.1" "20151117" "PRODUCTO-422" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02-REM01-reg3.1.sql > DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql" "20151117" "REM01" "KO" ""
	      echo "@KO@: DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql" "20151117" "REM01" "OK" ""
	      echo " OK : DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA_02.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql 20150827 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150827" "PRODUCTO-130" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA-REM01-reg3.1.sql > DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20150827" "REM01" "KO" ""
	      echo "@KO@: DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20150827" "REM01" "OK" ""
	      echo " OK : DML_057_ENTITY01_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql 20150901 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1" "20150901" "PRODUCTO-221" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES-REM01-reg3.1.sql > DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql" "20150901" "REM01" "KO" ""
	      echo "@KO@: DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql" "20150901" "REM01" "OK" ""
	      echo " OK : DML_058_ENTITY01_VISIBLE_BOTON_SOLICITAR_LIQUIDACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql 20150911 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1" "20150911" "PRODUCTO-75" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC-REM01-reg3.1.sql > DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql" "20150911" "REM01" "KO" ""
	      echo "@KO@: DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql" "20150911" "REM01" "OK" ""
	      echo " OK : DML_059_ENTITY01_DD_TPD_PCO_TIPO_PRM_DOC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3" "20150729" "PRODUCTO-159" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO-REM01-reg3.1.sql > DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DML_060_ENTITY01_INSERT_SUBTIPOS_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_060_ENTITY01_NuevosTGEySTA.sql 20150912 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_060_ENTITY01_NuevosTGEySTA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_060_ENTITY01_NuevosTGEySTA.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150912" "PRODUCTO-236" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_060_ENTITY01_NuevosTGEySTA-REM01-reg3.1.sql > DML_060_ENTITY01_NuevosTGEySTA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_060_ENTITY01_NuevosTGEySTA.sql" "20150912" "REM01" "KO" ""
	      echo "@KO@: DML_060_ENTITY01_NuevosTGEySTA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_060_ENTITY01_NuevosTGEySTA.sql" "20150912" "REM01" "OK" ""
	      echo " OK : DML_060_ENTITY01_NuevosTGEySTA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_061_ENTITY01_BPMPrecon_Tareas.sql 20150912 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_061_ENTITY01_BPMPrecon_Tareas.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_061_ENTITY01_BPMPrecon_Tareas.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150912" "PRODUCTO-236" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_061_ENTITY01_BPMPrecon_Tareas-REM01-reg3.1.sql > DML_061_ENTITY01_BPMPrecon_Tareas.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_061_ENTITY01_BPMPrecon_Tareas.sql" "20150912" "REM01" "KO" ""
	      echo "@KO@: DML_061_ENTITY01_BPMPrecon_Tareas.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_061_ENTITY01_BPMPrecon_Tareas.sql" "20150912" "REM01" "OK" ""
	      echo " OK : DML_061_ENTITY01_BPMPrecon_Tareas.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3" "20150729" "PRODUCTO-159" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_061_ENTITY01_INSERT_TIPOS_ACUERDO-REM01-reg3.1.sql > DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DML_061_ENTITY01_INSERT_TIPOS_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_062_BANK01_BPMPrecontModificaciones.sql 20150915 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_062_BANK01_BPMPrecontModificaciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_062_BANK01_BPMPrecontModificaciones.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20150915" "PRODUCTO-130" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_062_BANK01_BPMPrecontModificaciones-REM01-reg3.1.sql > DML_062_BANK01_BPMPrecontModificaciones.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_062_BANK01_BPMPrecontModificaciones.sql" "20150915" "REM01" "KO" ""
	      echo "@KO@: DML_062_BANK01_BPMPrecontModificaciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_062_BANK01_BPMPrecontModificaciones.sql" "20150915" "REM01" "OK" ""
	      echo " OK : DML_062_BANK01_BPMPrecontModificaciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3" "20150729" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO-REM01-reg3.1.sql > DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DML_062_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql 20150813 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150813" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO-REM01-reg3.1.sql > DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql" "20150813" "REM01" "KO" ""
	      echo "@KO@: DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql" "20150813" "REM01" "OK" ""
	      echo " OK : DML_063_ENTITY01_INSERT_PEF_PERFILES_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_063_ENTITY01_RoleFuncionPrecontencioso.sql 20150921 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_063_ENTITY01_RoleFuncionPrecontencioso.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_063_ENTITY01_RoleFuncionPrecontencioso.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20150921" "PRODUCTO-263" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_063_ENTITY01_RoleFuncionPrecontencioso-REM01-reg3.1.sql > DML_063_ENTITY01_RoleFuncionPrecontencioso.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_063_ENTITY01_RoleFuncionPrecontencioso.sql" "20150921" "REM01" "KO" ""
	      echo "@KO@: DML_063_ENTITY01_RoleFuncionPrecontencioso.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_063_ENTITY01_RoleFuncionPrecontencioso.sql" "20150921" "REM01" "OK" ""
	      echo " OK : DML_063_ENTITY01_RoleFuncionPrecontencioso.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO-REM01-reg3.1.sql > DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DML_064_ENTITY01_DD_EET_ESTADO_ESQUEMA_TURNADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql 20150813 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql" "REMMASTER" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150813" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO-REMMASTER-reg3.1.sql > DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql" "20150813" "REMMASTER" "KO" ""
	      echo "@KO@: DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql" "20150813" "REMMASTER" "OK" ""
	      echo " OK : DML_064_HAYAMASTER_INSERT_FUN_FUNCIONES_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_064_MASTER_DD_CCA_COMUNIDAD.sql 20151013 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_064_MASTER_DD_CCA_COMUNIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_064_MASTER_DD_CCA_COMUNIDAD.sql" "REMMASTER" "ALBERTO CAMPOS" "online"  "9.1.12-bk" "20151013" "PRODUCTO-109" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_064_MASTER_DD_CCA_COMUNIDAD-REMMASTER-reg3.1.sql > DML_064_MASTER_DD_CCA_COMUNIDAD.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_MASTER_DD_CCA_COMUNIDAD.sql" "20151013" "REMMASTER" "KO" ""
	      echo "@KO@: DML_064_MASTER_DD_CCA_COMUNIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_MASTER_DD_CCA_COMUNIDAD.sql" "20151013" "REMMASTER" "OK" ""
	      echo " OK : DML_064_MASTER_DD_CCA_COMUNIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_064_MASTER_PCO_nuevosTGE.sql 20151013 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_064_MASTER_PCO_nuevosTGE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_064_MASTER_PCO_nuevosTGE.sql" "REMMASTER" "Jorge Martin" "online"  "9.1" "20151013" "PRODUCTO-308" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_064_MASTER_PCO_nuevosTGE-REMMASTER-reg3.1.sql > DML_064_MASTER_PCO_nuevosTGE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_MASTER_PCO_nuevosTGE.sql" "20151013" "REMMASTER" "KO" ""
	      echo "@KO@: DML_064_MASTER_PCO_nuevosTGE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_064_MASTER_PCO_nuevosTGE.sql" "20151013" "REMMASTER" "OK" ""
	      echo " OK : DML_064_MASTER_PCO_nuevosTGE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql 20150813 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150813" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO-REM01-reg3.1.sql > DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql" "20150813" "REM01" "KO" ""
	      echo "@KO@: DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql" "20150813" "REM01" "OK" ""
	      echo " OK : DML_065_ENTITY01_INSERT_FUN_PEF_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_065_MASTER_PCO_ajustesTGE.sql 20151019 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_065_MASTER_PCO_ajustesTGE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_065_MASTER_PCO_ajustesTGE.sql" "REMMASTER" "Jorge Martin" "online"  "9.1" "20151019" "HR-1361" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_065_MASTER_PCO_ajustesTGE-REMMASTER-reg3.1.sql > DML_065_MASTER_PCO_ajustesTGE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_065_MASTER_PCO_ajustesTGE.sql" "20151019" "REMMASTER" "KO" ""
	      echo "@KO@: DML_065_MASTER_PCO_ajustesTGE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_065_MASTER_PCO_ajustesTGE.sql" "20151019" "REMMASTER" "OK" ""
	      echo " OK : DML_065_MASTER_PCO_ajustesTGE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql 20150901 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150901" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_066_ENTITY01_INSERT_ESTADO_ACUERDO-REM01-reg3.1.sql > DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql" "20150901" "REM01" "KO" ""
	      echo "@KO@: DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql" "20150901" "REM01" "OK" ""
	      echo " OK : DML_066_ENTITY01_INSERT_ESTADO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql 20150907 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150907" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo-REM01-reg3.1.sql > DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql" "20150907" "REM01" "KO" ""
	      echo "@KO@: DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql" "20150907" "REM01" "OK" ""
	      echo " OK : DML_068_ENTITY01_InsertSubtipoTareaAceptarAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql 20150910 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1.3" "20150910" "ACUERDOS" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES-REM01-reg3.1.sql > DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql" "20150910" "REM01" "KO" ""
	      echo "@KO@: DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql" "20150910" "REM01" "OK" ""
	      echo " OK : DML_069_ENTITY01_INSERT_TIPOS_ACUERDO_COMUNES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql 20150729 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1.3" "20150729" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES-REM01-reg3.1.sql > DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql" "20150729" "REM01" "KO" ""
	      echo "@KO@: DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql" "20150729" "REM01" "OK" ""
	      echo " OK : DML_070_ENTITY01_INSERT_CAMPOS_TIPO_ACUERDO_COMUNES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql 20150914 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql" "REM01" "Agustin Mompo" "online"  "9.1.3-hy-master" "20150914" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO-REM01-reg3.1.sql > DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql" "20150914" "REM01" "KO" ""
	      echo "@KO@: DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql" "20150914" "REM01" "OK" ""
	      echo " OK : DML_072_ENTITY01_UPDATE_ESTADO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_072_MASTER_FuncionesSupervisor.sql 20151001 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_072_MASTER_FuncionesSupervisor.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_072_MASTER_FuncionesSupervisor.sql" "REMMASTER" "NACHO ARCOS" "online"  "9.1.6-hy" "20151001" "HR-1206" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_072_MASTER_FuncionesSupervisor-REMMASTER-reg3.1.sql > DML_072_MASTER_FuncionesSupervisor.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_072_MASTER_FuncionesSupervisor.sql" "20151001" "REMMASTER" "KO" ""
	      echo "@KO@: DML_072_MASTER_FuncionesSupervisor.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_072_MASTER_FuncionesSupervisor.sql" "20151001" "REMMASTER" "OK" ""
	      echo " OK : DML_072_MASTER_FuncionesSupervisor.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql 20151014 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql" "REM01" "PEDROBLASCOS" "online"  "9.1.0-X" "20151014" "PRODUCTO-174" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_073_ENTITY01_ConfiguracionProductoAcuerdos-REM01-reg3.1.sql > DML_073_ENTITY01_ConfiguracionProductoAcuerdos.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql" "20151014" "REM01" "KO" ""
	      echo "@KO@: DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql" "20151014" "REM01" "OK" ""
	      echo " OK : DML_073_ENTITY01_ConfiguracionProductoAcuerdos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_073_MASTER_InsertarFuncionFiltroDespacho.sql 20151007 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_073_MASTER_InsertarFuncionFiltroDespacho.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_073_MASTER_InsertarFuncionFiltroDespacho.sql" "REMMASTER" "Oscar Dorado" "online"  "9.1.16-bk" "20151007" "BKREC-970" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_073_MASTER_InsertarFuncionFiltroDespacho-REMMASTER-reg3.1.sql > DML_073_MASTER_InsertarFuncionFiltroDespacho.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_073_MASTER_InsertarFuncionFiltroDespacho.sql" "20151007" "REMMASTER" "KO" ""
	      echo "@KO@: DML_073_MASTER_InsertarFuncionFiltroDespacho.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_073_MASTER_InsertarFuncionFiltroDespacho.sql" "20151007" "REMMASTER" "OK" ""
	      echo " OK : DML_073_MASTER_InsertarFuncionFiltroDespacho.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150916" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo-REM01-reg3.1.sql > DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DML_074_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql 20151007 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql" "REMMASTER" "Oscar Dorado" "online"  "9.1.16-bk" "20151007" "BKREC-970" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_074_MASTER_InsertarFuncionEsquemasTurnado-REMMASTER-reg3.1.sql > DML_074_MASTER_InsertarFuncionEsquemasTurnado.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql" "20151007" "REMMASTER" "KO" ""
	      echo "@KO@: DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql" "20151007" "REMMASTER" "OK" ""
	      echo " OK : DML_074_MASTER_InsertarFuncionEsquemasTurnado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql 20151015 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql" "REMMASTER" "JORGE ROS" "online"  "9.1.16-bk" "20151015" "BKREC-943" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_075_BANKMASTER_BKREC_943_InsertFunFunciones-REMMASTER-reg3.1.sql > DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql" "20151015" "REMMASTER" "KO" ""
	      echo "@KO@: DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql" "20151015" "REMMASTER" "OK" ""
	      echo " OK : DML_075_BANKMASTER_BKREC_943_InsertFunFunciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql 20150907 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150907" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo-REM01-reg3.1.sql > DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql" "20150907" "REM01" "KO" ""
	      echo "@KO@: DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql" "20150907" "REM01" "OK" ""
	      echo " OK : DML_075_ENTITY01_InsertSubtipoTareaCumplimientoAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql 20150916 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150916" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo-REM01-reg3.1.sql > DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "20150916" "REM01" "KO" ""
	      echo "@KO@: DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql" "20150916" "REM01" "OK" ""
	      echo " OK : DML_075_ENTITY01_UpdateSubtipoTareaAceptarAcuerdo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql 20151023 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql" "REMMASTER" "OSCAR DORADO" "online"  "9.1.17-bk" "20151023" "BKREC-1265" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones-REMMASTER-reg3.1.sql > DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql" "20151023" "REMMASTER" "KO" ""
	      echo "@KO@: DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql" "20151023" "REMMASTER" "OK" ""
	      echo " OK : DML_077_BANKMASTER_BKREC_1265_InsertFunFunciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql 20151019 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20151019" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones-REM01-reg3.1.sql > DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql" "20151019" "REM01" "KO" ""
	      echo "@KO@: DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql" "20151019" "REM01" "OK" ""
	      echo " OK : DML_077_ENTITY01_InsertConfigAcuerdosDerivaciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql" "REM01" "RAFAEL ARACIL LOPEZ  " "load_ficheros_fsr"  "9.1.17-bk" "20151110" "BKREC-1417" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR-REM01-reg3.1.sql > DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DML_078_BANK01_DD_TAF_TIPOS_ACTUACION_FSR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql 20150922 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150922" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos-REM01-reg3.1.sql > DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql" "20150922" "REM01" "KO" ""
	      echo "@KO@: DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql" "20150922" "REM01" "OK" ""
	      echo " OK : DML_078_ENTITY01_InsertSubtipoTareaNotificacionesAcuerdos.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20151110" "BKREC-1421" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_079_BANK01_INSERT_DD_RULE_DEFINITION-REM01-reg3.1.sql > DML_079_BANK01_INSERT_DD_RULE_DEFINITION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DML_079_BANK01_INSERT_DD_RULE_DEFINITION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql 20150925 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql" "REM01" "PEDROBLASCO" "online"  "9.1.3-hy-master" "20150925" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado-REM01-reg3.1.sql > DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql" "20150925" "REM01" "KO" ""
	      echo "@KO@: DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql" "20150925" "REM01" "OK" ""
	      echo " OK : DML_079_ENTITY01_CambioDescEstadoAcuerdoAceptado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql 20151014 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql" "REM01" "Vicente Lozano" "online"  "9.1" "20151014" "PRODUCTO-298" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION-REM01-reg3.1.sql > DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql" "20151014" "REM01" "KO" ""
	      echo "@KO@: DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql" "20151014" "REM01" "OK" ""
	      echo " OK : DML_079_ENTITY01_INSERT_DIRECTORIO_PLANTILLA_LIQUIDACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql 20151027 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql" "REMMASTER" "JORGE ROS" "online"  "9.1.17-bk" "20151027" "BKREC-1003" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS-REMMASTER-reg3.1.sql > DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql" "20151027" "REMMASTER" "KO" ""
	      echo "@KO@: DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql" "20151027" "REMMASTER" "OK" ""
	      echo " OK : DML_079_MASTER_BKREC_1003_INSERT_ROLE_VER_TABS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql 20151006 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3" "20151006" "PRODUCTO-290" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO-REM01-reg3.1.sql > DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql" "20151006" "REM01" "KO" ""
	      echo "@KO@: DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql" "20151006" "REM01" "OK" ""
	      echo " OK : DML_080_ENTITY01_INSERT_MOTIVO_RECHAZO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql 20150922 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20150922" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta-REM01-reg3.1.sql > DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql" "20150922" "REM01" "KO" ""
	      echo "@KO@: DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql" "20150922" "REM01" "OK" ""
	      echo " OK : DML_080_ENTITY01_InsertSubtipoTareaEventoPropuesta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql 20151015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151015" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO-REM01-reg3.1.sql > DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql" "20151015" "REM01" "KO" ""
	      echo "@KO@: DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql" "20151015" "REM01" "OK" ""
	      echo " OK : DML_081_ENTITY01_INSERT_SUBTIPO_TAREA_BASE_OCULTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql 20151007 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql" "REMMASTER" "JAVIER RUIZ" "online"  "9.1.3-hy-master" "20151007" "PRODUCTO-286" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta-REMMASTER-reg3.1.sql > DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql" "20151007" "REMMASTER" "KO" ""
	      echo "@KO@: DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql" "20151007" "REMMASTER" "OK" ""
	      echo " OK : DML_081_MASTER_CambiarTipoTareaSubtipoEventoPropuesta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql 20151016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3-hy-master" "20151016" "HR-1259" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES-REM01-reg3.1.sql > DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql" "20151016" "REM01" "KO" ""
	      echo "@KO@: DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql" "20151016" "REM01" "OK" ""
	      echo " OK : DML_084_ENTITY01_UPATE_CAMPOS_TAREA_ASIGNACION_GESTORES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_084_MASTER_InsertarFuncionSoloConsulta.sql 20151021 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_084_MASTER_InsertarFuncionSoloConsulta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_084_MASTER_InsertarFuncionSoloConsulta.sql" "REMMASTER" "José Luis Gauxachs" "online"  "9.1.8-hy-rc01" "20151021" "HR-1336" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_084_MASTER_InsertarFuncionSoloConsulta-REMMASTER-reg3.1.sql > DML_084_MASTER_InsertarFuncionSoloConsulta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_084_MASTER_InsertarFuncionSoloConsulta.sql" "20151021" "REMMASTER" "KO" ""
	      echo "@KO@: DML_084_MASTER_InsertarFuncionSoloConsulta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_084_MASTER_InsertarFuncionSoloConsulta.sql" "20151021" "REMMASTER" "OK" ""
	      echo " OK : DML_084_MASTER_InsertarFuncionSoloConsulta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql 20151118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "REM01" "Alberto Campos" "online"  "9.1.3-hy-master" "20151118" "PRODUCTO-347" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD-REM01-reg3.1.sql > DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20151118" "REM01" "KO" ""
	      echo "@KO@: DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql" "20151118" "REM01" "OK" ""
	      echo " OK : DML_085_ENTITY01_UPDATE_PCO_CDE_CONF_TFA_TIPOENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_085_MASTER_BotonFinalizarAsunto.sql 20151102 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_085_MASTER_BotonFinalizarAsunto.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_085_MASTER_BotonFinalizarAsunto.sql" "REMMASTER" "G.Estellés" "online"  "9.1.9" "20151102" "-" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_085_MASTER_BotonFinalizarAsunto-REMMASTER-reg3.1.sql > DML_085_MASTER_BotonFinalizarAsunto.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_085_MASTER_BotonFinalizarAsunto.sql" "20151102" "REMMASTER" "KO" ""
	      echo "@KO@: DML_085_MASTER_BotonFinalizarAsunto.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_085_MASTER_BotonFinalizarAsunto.sql" "20151102" "REMMASTER" "OK" ""
	      echo " OK : DML_085_MASTER_BotonFinalizarAsunto.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql 20151103 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql" "REM01" "Alberto Campos" "online"  "9.1.3-hy-master" "20151103" "CMREC-887" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_086_ENTITY01_INSERT_ESTADO_DECISION-REM01-reg3.1.sql > DML_086_ENTITY01_INSERT_ESTADO_DECISION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql" "20151103" "REM01" "KO" ""
	      echo "@KO@: DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql" "20151103" "REM01" "OK" ""
	      echo " OK : DML_086_ENTITY01_INSERT_ESTADO_DECISION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql 20151124 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20151124" "PRODUCTO-477" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros-REM01-reg3.1.sql > DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql" "20151124" "REM01" "KO" ""
	      echo "@KO@: DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql" "20151124" "REM01" "OK" ""
	      echo " OK : DML_111_ENTITY01_InsertTipoAdjuntoEntidadOtros.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql" "REM01" "PEDROBLASCO" "online"  "9.1.3-hy" "20151013" "PRODUCTO-306" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_120_ENTITY01_ModificacionesBPMPcoProducto-REM01-reg3.1.sql > DML_120_ENTITY01_ModificacionesBPMPcoProducto.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DML_120_ENTITY01_ModificacionesBPMPcoProducto.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_121_ENTITY01_AjustesBPMPcoProducto.sql 20151013 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_121_ENTITY01_AjustesBPMPcoProducto.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_121_ENTITY01_AjustesBPMPcoProducto.sql" "REM01" "PEDROBLASCO" "online"  "9.1.3-hy" "20151013" "PRODUCTO-306" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_121_ENTITY01_AjustesBPMPcoProducto-REM01-reg3.1.sql > DML_121_ENTITY01_AjustesBPMPcoProducto.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_121_ENTITY01_AjustesBPMPcoProducto.sql" "20151013" "REM01" "KO" ""
	      echo "@KO@: DML_121_ENTITY01_AjustesBPMPcoProducto.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_121_ENTITY01_AjustesBPMPcoProducto.sql" "20151013" "REM01" "OK" ""
	      echo " OK : DML_121_ENTITY01_AjustesBPMPcoProducto.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql 20151016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151016" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION-REM01-reg3.1.sql > DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "20151016" "REM01" "KO" ""
	      echo "@KO@: DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "20151016" "REM01" "OK" ""
	      echo " OK : DML_122_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql 20151016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151016" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION-REM01-reg3.1.sql > DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "20151016" "REM01" "KO" ""
	      echo "@KO@: DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql" "20151016" "REM01" "OK" ""
	      echo " OK : DML_123_ENTITY01_UPATE_CAMPOS_TAREA_TOMA_REG_DECISION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql 20151016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151016" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS-REM01-reg3.1.sql > DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151016" "REM01" "KO" ""
	      echo "@KO@: DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151016" "REM01" "OK" ""
	      echo " OK : DML_124_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql 20151019 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151019" "HR-1359" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS-REM01-reg3.1.sql > DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151019" "REM01" "KO" ""
	      echo "@KO@: DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151019" "REM01" "OK" ""
	      echo " OK : DML_125_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql 20151021 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151021" "HR-1359" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO-REM01-reg3.1.sql > DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql" "20151021" "REM01" "KO" ""
	      echo "@KO@: DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql" "20151021" "REM01" "OK" ""
	      echo " OK : DML_126_ENTITY01_UPATE_CAMPOS_TAP_TAREA_PROCEDIMIENTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_127_ENTITY01_RESULTADO_BUROFAX.sql 20151029 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_127_ENTITY01_RESULTADO_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_127_ENTITY01_RESULTADO_BUROFAX.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1" "20151029" "PRODUCTO-366" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_127_ENTITY01_RESULTADO_BUROFAX-REM01-reg3.1.sql > DML_127_ENTITY01_RESULTADO_BUROFAX.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_127_ENTITY01_RESULTADO_BUROFAX.sql" "20151029" "REM01" "KO" ""
	      echo "@KO@: DML_127_ENTITY01_RESULTADO_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_127_ENTITY01_RESULTADO_BUROFAX.sql" "20151029" "REM01" "OK" ""
	      echo " OK : DML_127_ENTITY01_RESULTADO_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql 20151106 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20151106" "PRODUCTO" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso-REM01-reg3.1.sql > DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql" "20151106" "REM01" "KO" ""
	      echo "@KO@: DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql" "20151106" "REM01" "OK" ""
	      echo " OK : DML_128_ENTITY01_InsertfuncionesBotonesGridPrecontencioso.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql 20151113 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.3-hy" "20151113" "PRODUCTO-416" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_128_ENTITY01_ModificacionesBPMPcoProducto_02-REM01-reg3.1.sql > DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql" "20151113" "REM01" "KO" ""
	      echo "@KO@: DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql" "20151113" "REM01" "OK" ""
	      echo " OK : DML_128_ENTITY01_ModificacionesBPMPcoProducto_02.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql 20151118 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.3-hy" "20151118" "PRODUCTO-347" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_128_ENTITY01_ModificacionesBPMPcoProducto_03-REM01-reg3.1.sql > DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql" "20151118" "REM01" "KO" ""
	      echo "@KO@: DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql" "20151118" "REM01" "OK" ""
	      echo " OK : DML_128_ENTITY01_ModificacionesBPMPcoProducto_03.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql 20151110 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql" "REM01" "JOSEVI" "online"  "9.1.17-bk" "20151110" "BKREC-1051" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP-REM01-reg3.1.sql > DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql" "20151110" "REM01" "KO" ""
	      echo "@KO@: DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql" "20151110" "REM01" "OK" ""
	      echo " OK : DML_129_ENTITY01_BKREC-1051_RTF_DESCARGA_ZIP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_129_ENTITY01_Estado_Descartada_Burofax.sql 20151123 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_129_ENTITY01_Estado_Descartada_Burofax.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_129_ENTITY01_Estado_Descartada_Burofax.sql" "REM01" "Alberto Soler" "online"  "9.1" "20151123" "PRODUCTO-355" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_129_ENTITY01_Estado_Descartada_Burofax-REM01-reg3.1.sql > DML_129_ENTITY01_Estado_Descartada_Burofax.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_ENTITY01_Estado_Descartada_Burofax.sql" "20151123" "REM01" "KO" ""
	      echo "@KO@: DML_129_ENTITY01_Estado_Descartada_Burofax.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_ENTITY01_Estado_Descartada_Burofax.sql" "20151123" "REM01" "OK" ""
	      echo " OK : DML_129_ENTITY01_Estado_Descartada_Burofax.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql 20151111 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql" "REMMASTER" "Javier Ruiz" "online"  "9.1" "20151111" "CMREC-1091" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO-REMMASTER-reg3.1.sql > DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql" "20151111" "REMMASTER" "KO" ""
	      echo "@KO@: DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql" "20151111" "REMMASTER" "OK" ""
	      echo " OK : DML_129_MASTER_INSERT_DD_EGT_EST_GEST_TERMINO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql 20151117 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql" "REM01" "AGUSTIN MOMPO" "online"  "9.1" "20151117" "PRODUCTO-366" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX-REM01-reg3.1.sql > DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql" "20151117" "REM01" "KO" ""
	      echo "@KO@: DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql" "20151117" "REM01" "OK" ""
	      echo " OK : DML_130_ENTITY01_MODIF_COD_RESULTADO_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql 20151112 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql" "REMMASTER" "Javier Ruiz" "online"  "9.1" "20151112" "CMREC-1119" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL-REMMASTER-reg3.1.sql > DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql" "20151112" "REMMASTER" "KO" ""
	      echo "@KO@: DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql" "20151112" "REMMASTER" "OK" ""
	      echo " OK : DML_130_MASTER_FUN_SOLICITAR_EXP_MANUAL.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql 20151120 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql" "REM01" "PEDROBLASCO" "online"  "9.1" "20151120" "PRODUCTO-470" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX-REM01-reg3.1.sql > DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql" "20151120" "REM01" "KO" ""
	      echo "@KO@: DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql" "20151120" "REM01" "OK" ""
	      echo " OK : DML_131_ENTITY01_MODIF_PLANTILLA_BUROFAX.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql 20151113 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql" "REMMASTER" "Javier Ruiz" "online"  "9.1" "20151113" "CMREC-1119" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA-REMMASTER-reg3.1.sql > DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql" "20151113" "REMMASTER" "KO" ""
	      echo "@KO@: DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql" "20151113" "REMMASTER" "OK" ""
	      echo " OK : DML_131_MASTER_FUN_MENU_ACC_MULTIPLES_SUBASTA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql 20151126 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20151126" "PRODUCTO-410" "si"
	  exit | sqlplus -s -l $1 @./scripts/DML_132_ENTITY01_InsercionTGP_SUP_PCO-REM01-reg3.1.sql > DML_132_ENTITY01_InsercionTGP_SUP_PCO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql" "20151126" "REM01" "KO" ""
	      echo "@KO@: DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql" "20151126" "REM01" "OK" ""
	      echo " OK : DML_132_ENTITY01_InsercionTGP_SUP_PCO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql 20151201 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "REM01" "JAVIER RUIZ" "online"  "9.1" "20151201" "PRODUCTO-495" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA-REM01-reg3.1.sql > DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "20151201" "REM01" "KO" ""
	      echo "@KO@: DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql" "20151201" "REM01" "OK" ""
	      echo " OK : DML_133_ENTITY01_UPDATE_DD_STA_SUBTIPO_TAREA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql 20151201 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc26" "20151201" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO-REM01-reg3.1.sql > DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql" "20151201" "REM01" "KO" ""
	      echo "@KO@: DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql" "20151201" "REM01" "OK" ""
	      echo " OK : DML_136_ENTITY01_INSERT_REGISTROS_DD_TPA_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql 20151202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc26" "20151202" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_137_ENTITY01_UPDATE_TEA_TERMINOS-REM01-reg3.1.sql > DML_137_ENTITY01_UPDATE_TEA_TERMINOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql" "20151202" "REM01" "KO" ""
	      echo "@KO@: DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql" "20151202" "REM01" "OK" ""
	      echo " OK : DML_137_ENTITY01_UPDATE_TEA_TERMINOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql 20151202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc26" "20151202" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS-REM01-reg3.1.sql > DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql" "20151202" "REM01" "KO" ""
	      echo "@KO@: DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql" "20151202" "REM01" "OK" ""
	      echo " OK : DML_138_ENTITY01_UPDATE_TEA_TERMINOS_ACUERDOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql 20151202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc26" "20151202" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO-REM01-reg3.1.sql > DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql" "20151202" "REM01" "KO" ""
	      echo "@KO@: DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql" "20151202" "REM01" "OK" ""
	      echo " OK : DML_139_ENTITY01_INSERT_DD_ENTIDAD_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql 20151203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc25" "20151203" "PRODUCTO-496" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO-REM01-reg3.1.sql > DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "20151203" "REM01" "KO" ""
	      echo "@KO@: DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "20151203" "REM01" "OK" ""
	      echo " OK : DML_140_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_141_ENTITY01_INSERT_TRAMO_91-120.sql 20151209 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_141_ENTITY01_INSERT_TRAMO_91-120.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_141_ENTITY01_INSERT_TRAMO_91-120.sql" "REM01" "Javier Ruiz" "online"  "9.1" "20151209" "CMREC-1466" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_141_ENTITY01_INSERT_TRAMO_91-120-REM01-reg3.1.sql > DML_141_ENTITY01_INSERT_TRAMO_91-120.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_141_ENTITY01_INSERT_TRAMO_91-120.sql" "20151209" "REM01" "KO" ""
	      echo "@KO@: DML_141_ENTITY01_INSERT_TRAMO_91-120.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_141_ENTITY01_INSERT_TRAMO_91-120.sql" "20151209" "REM01" "OK" ""
	      echo " OK : DML_141_ENTITY01_INSERT_TRAMO_91-120.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql 20151210 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "REM01" "Alberto b" "web"  "9.1.0-cj-rc30" "20151210" "CMREC-1382" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO-REM01-reg3.1.sql > DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "20151210" "REM01" "KO" ""
	      echo "@KO@: DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql" "20151210" "REM01" "OK" ""
	      echo " OK : DML_142_ENTITY01_UPDATE_DD_TPA_TIPO_ACUERDO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_143_ENTITY01_MERGE_BIE_BIEN.sql 20160202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_143_ENTITY01_MERGE_BIE_BIEN.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_143_ENTITY01_MERGE_BIE_BIEN.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20160202" "BKREC-1420" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_143_ENTITY01_MERGE_BIE_BIEN-REM01-reg3.1.sql > DML_143_ENTITY01_MERGE_BIE_BIEN.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_143_ENTITY01_MERGE_BIE_BIEN.sql" "20160202" "REM01" "KO" ""
	      echo "@KO@: DML_143_ENTITY01_MERGE_BIE_BIEN.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_143_ENTITY01_MERGE_BIE_BIEN.sql" "20160202" "REM01" "OK" ""
	      echo " OK : DML_143_ENTITY01_MERGE_BIE_BIEN.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_143_MASTER_INSERT_ROLES_VER_TABS.sql 20160203 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_143_MASTER_INSERT_ROLES_VER_TABS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_143_MASTER_INSERT_ROLES_VER_TABS.sql" "REMMASTER" "JORGE ROS" "online"  "9.1" "20160203" "PRODUCTO-671" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_143_MASTER_INSERT_ROLES_VER_TABS-REMMASTER-reg3.1.sql > DML_143_MASTER_INSERT_ROLES_VER_TABS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_143_MASTER_INSERT_ROLES_VER_TABS.sql" "20160203" "REMMASTER" "KO" ""
	      echo "@KO@: DML_143_MASTER_INSERT_ROLES_VER_TABS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_143_MASTER_INSERT_ROLES_VER_TABS.sql" "20160203" "REMMASTER" "OK" ""
	      echo " OK : DML_143_MASTER_INSERT_ROLES_VER_TABS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_144_ENTITY01_MERGE_BIE_CNT.sql 20160202 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_144_ENTITY01_MERGE_BIE_CNT.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_144_ENTITY01_MERGE_BIE_CNT.sql" "REM01" "RUBEN ROVIRA" "batch"  "9.1.12-bk" "20160202" "BKREC-1420" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_144_ENTITY01_MERGE_BIE_CNT-REM01-reg3.1.sql > DML_144_ENTITY01_MERGE_BIE_CNT.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_144_ENTITY01_MERGE_BIE_CNT.sql" "20160202" "REM01" "KO" ""
	      echo "@KO@: DML_144_ENTITY01_MERGE_BIE_CNT.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_144_ENTITY01_MERGE_BIE_CNT.sql" "20160202" "REM01" "OK" ""
	      echo " OK : DML_144_ENTITY01_MERGE_BIE_CNT.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql 20151204 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "REM01" "JAVIER DIAZ" "batch"  "9.3" "20151204" "CMREC-866" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD-REM01-reg3.1.sql > DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "20151204" "REM01" "KO" ""
	      echo "@KO@: DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql" "20151204" "REM01" "OK" ""
	      echo " OK : DML_330_ENTITY01_DATJADR_Carga_DD_EIC_ESTADO_INTERNO_ENTIDAD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql 20150113 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql" "REMMASTER" "Alberto b" "online"  "9.1.3-hy-master" "20150113" "HR-1708" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS-REMMASTER-reg3.1.sql > DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql" "20150113" "REMMASTER" "KO" ""
	      echo "@KO@: DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql" "20150113" "REMMASTER" "OK" ""
	      echo " OK : DML_330_MASTER_INSERT_FUN_FUNCIONES_TAB_ATIPICOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql 20160113 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql" "REM01" "Alberto b." "online"  "9.1.0-rc-cj37" "20160113" "HR-1708" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_331_ENTITY01_INSERT_TAB_ATIPICOS-REM01-reg3.1.sql > DML_331_ENTITY01_INSERT_TAB_ATIPICOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql" "20160113" "REM01" "KO" ""
	      echo "@KO@: DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql" "20160113" "REM01" "OK" ""
	      echo " OK : DML_331_ENTITY01_INSERT_TAB_ATIPICOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql 20151223 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql" "REM01" "PEDROBLASCO" "producto"  "9.1" "20151223" "PRODUCTO-547" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_352_ENTITY01_InsercionDiccionarioGestionRevisar-REM01-reg3.1.sql > DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql" "20151223" "REM01" "KO" ""
	      echo "@KO@: DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql" "20151223" "REM01" "OK" ""
	      echo " OK : DML_352_ENTITY01_InsercionDiccionarioGestionRevisar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql 20160125 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql" "REMMASTER" "Javier Ruiz" "online"  "9.1" "20160125" "PRODUCTO-567" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE-REMMASTER-reg3.1.sql > DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql" "20160125" "REMMASTER" "KO" ""
	      echo "@KO@: DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql" "20160125" "REMMASTER" "OK" ""
	      echo " OK : DML_353_MASTER_FUN_ROLE_VER_ARQUETIPO_EXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql 20160210 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20160210" "PRODUCTO-714" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado-REM01-reg3.1.sql > DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql" "20160210" "REM01" "KO" ""
	      echo "@KO@: DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql" "20160210" "REM01" "OK" ""
	      echo " OK : DML_400_ENTITY01_PEN_PARAM_ENTIDAD_moduloProcuradoresActivado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql 20160210 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql" "REM01" "JORGE MARTIN" "online"  "9.1" "20160210" "PRODUCTO-714" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido-REM01-reg3.1.sql > DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql" "20160210" "REM01" "KO" ""
	      echo "@KO@: DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql" "20160210" "REM01" "OK" ""
	      echo " OK : DML_401_ENTITY01_PEN_PARAM_ENTIDAD_codigoTipoDespachoLetradoValido.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_500_MASTER_InsertarFuncionMenusComites.sql 20150909 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_500_MASTER_InsertarFuncionMenusComites.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_500_MASTER_InsertarFuncionMenusComites.sql" "REMMASTER" "Carlos Perez" "online"  "gestionVencidos" "20150909" "PRODUCTO-240" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_500_MASTER_InsertarFuncionMenusComites-REMMASTER-reg3.1.sql > DML_500_MASTER_InsertarFuncionMenusComites.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_500_MASTER_InsertarFuncionMenusComites.sql" "20150909" "REMMASTER" "KO" ""
	      echo "@KO@: DML_500_MASTER_InsertarFuncionMenusComites.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_500_MASTER_InsertarFuncionMenusComites.sql" "20150909" "REMMASTER" "OK" ""
	      echo " OK : DML_500_MASTER_InsertarFuncionMenusComites.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_501_MASTER_InsertFuncionCambioMasivo.sql 20160201 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_501_MASTER_InsertFuncionCambioMasivo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_501_MASTER_InsertFuncionCambioMasivo.sql" "REMMASTER" "PEDROBLASCO" "online"  "9.1" "20160201" "PRODUCTO-683" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_501_MASTER_InsertFuncionCambioMasivo-REMMASTER-reg3.1.sql > DML_501_MASTER_InsertFuncionCambioMasivo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_501_MASTER_InsertFuncionCambioMasivo.sql" "20160201" "REMMASTER" "KO" ""
	      echo "@KO@: DML_501_MASTER_InsertFuncionCambioMasivo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_501_MASTER_InsertFuncionCambioMasivo.sql" "20160201" "REMMASTER" "OK" ""
	      echo " OK : DML_501_MASTER_InsertFuncionCambioMasivo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_505_MASTER_InsertFuncionGenerarDocPCO.sql 20160201 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_505_MASTER_InsertFuncionGenerarDocPCO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_505_MASTER_InsertFuncionGenerarDocPCO.sql" "REMMASTER" "PEDROBLASCO" "online"  "9.1" "20160201" "CMREC-1847" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_505_MASTER_InsertFuncionGenerarDocPCO-REMMASTER-reg3.1.sql > DML_505_MASTER_InsertFuncionGenerarDocPCO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_505_MASTER_InsertFuncionGenerarDocPCO.sql" "20160201" "REMMASTER" "KO" ""
	      echo "@KO@: DML_505_MASTER_InsertFuncionGenerarDocPCO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_505_MASTER_InsertFuncionGenerarDocPCO.sql" "20160201" "REMMASTER" "OK" ""
	      echo " OK : DML_505_MASTER_InsertFuncionGenerarDocPCO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql 20160216 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql" "REMMASTER" "Jorge Ros" "online"  "9.1" "20160216" "PRODUCTO-671" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES-REMMASTER-reg3.1.sql > DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql" "20160216" "REMMASTER" "KO" ""
	      echo "@KO@: DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql" "20160216" "REMMASTER" "OK" ""
	      echo " OK : DML_510_MASTER_FUNCION_VER_TAB_PRC_RESOLUCIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql 20151130 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151130" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_550_ENTITY01_ModificacionesBPMPcoProducto_04-REM01-reg3.1.sql > DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql" "20151130" "REM01" "KO" ""
	      echo "@KO@: DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql" "20151130" "REM01" "OK" ""
	      echo " OK : DML_550_ENTITY01_ModificacionesBPMPcoProducto_04.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql 20151229 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql" "REM01" "ALBERTO CAMPOS" "online"  "9.1.0-cj-rc35" "20151229" "CMREC-1605" "Sí"
	  exit | sqlplus -s -l $1 @./scripts/DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA-REM01-reg3.1.sql > DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20151229" "REM01" "KO" ""
	      echo "@KO@: DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql" "20151229" "REM01" "OK" ""
	      echo " OK : DML_551_ENTITY01_UPD_PCO_LCT_LINEA_CONFIG_TAREA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql 20151016 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.3-hy-master" "20151016" "PRODUCTO-180" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS-REM01-reg3.1.sql > DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151016" "REM01" "KO" ""
	      echo "@KO@: DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql" "20151016" "REM01" "OK" ""
	      echo " OK : DML_555_ENTITY01_UPATE_CAMPOS_FORM_ITEMS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_556_ENTITY01_InsertaTipoCambioMasivo.sql 20160113 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_556_ENTITY01_InsertaTipoCambioMasivo.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_556_ENTITY01_InsertaTipoCambioMasivo.sql" "REM01" "PEDROBLASCO" "online"  "9.1" "20160113" "CMREC-1795" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_556_ENTITY01_InsertaTipoCambioMasivo-REM01-reg3.1.sql > DML_556_ENTITY01_InsertaTipoCambioMasivo.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_556_ENTITY01_InsertaTipoCambioMasivo.sql" "20160113" "REM01" "KO" ""
	      echo "@KO@: DML_556_ENTITY01_InsertaTipoCambioMasivo.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_556_ENTITY01_InsertaTipoCambioMasivo.sql" "20160113" "REM01" "OK" ""
	      echo " OK : DML_556_ENTITY01_InsertaTipoCambioMasivo.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql 20150301 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql" "REM01" "José Luis Gauxachs" "online"  "9.1.0-cj-rc37" "20150301" "CMREC-2328" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS-REM01-reg3.1.sql > DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql" "20150301" "REM01" "KO" ""
	      echo "@KO@: DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql" "20150301" "REM01" "OK" ""
	      echo " OK : DML_556_ENTITY01_UPATE_PCO_PRC_PROCEDIMIENTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql 20160126 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql" "REM01" "JORGE ROS" "online"  "9.1" "20160126" "HR-1316" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION-REM01-reg3.1.sql > DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql" "20160126" "REM01" "KO" ""
	      echo "@KO@: DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql" "20160126" "REM01" "OK" ""
	      echo " OK : DML_557_ENTITY01_INSERT_DD_TRI_TRIBUTACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql 20160308 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "REM01" "Alberto B." "producto"  "9.2" "20160308" "CMREC-2723" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS-REM01-reg3.1.sql > DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "20160308" "REM01" "KO" ""
	      echo "@KO@: DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql" "20160308" "REM01" "OK" ""
	      echo " OK : DML_557_ENTITY01_NORMALIZAR_VALORES_TERMINOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql 20160126 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql" "REMMASTER" "JORGE ROS" "online"  "9.1" "20160126" "HR-1316" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION-REMMASTER-reg3.1.sql > DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql" "20160126" "REMMASTER" "KO" ""
	      echo "@KO@: DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql" "20160126" "REMMASTER" "OK" ""
	      echo " OK : DML_558_MASTER_INSERT_DD_TPI_TIPO_IMPOSICION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql 20160126 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql" "REMMASTER" "JORGE ROS" "online"  "9.1" "20160126" "HR-1316" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA-REMMASTER-reg3.1.sql > DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql" "20160126" "REMMASTER" "KO" ""
	      echo "@KO@: DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql" "20160126" "REMMASTER" "OK" ""
	      echo " OK : DML_559_MASTER_INSERT_DD_IMV_IMPOSICION_VENTA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql 20160125 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.0-cj-rc37" "20160125" "PRODUCTO-637" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES-REM01-reg3.1.sql > DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql" "20160125" "REM01" "KO" ""
	      echo "@KO@: DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql" "20160125" "REM01" "OK" ""
	      echo " OK : DML_560_ENTITY01_LIMITE_EXPORT_BUSCADORES_BIENES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql 20160129 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql" "REM01" "MANUEL_MEJIAS" "online"  "9.1.0-cj-rc37" "20160129" "PRODUCTO-513" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES-REM01-reg3.1.sql > DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql" "20160129" "REM01" "KO" ""
	      echo "@KO@: DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql" "20160129" "REM01" "OK" ""
	      echo " OK : DML_561_ENTITY01_LIMITE_EXPORT_BUSCADORES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql 20160201 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.2-HY" "20160201" "CMREC-1847" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO-REM01-reg3.1.sql > DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql" "20160201" "REM01" "KO" ""
	      echo "@KO@: DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql" "20160201" "REM01" "OK" ""
	      echo " OK : DML_562_ENTITY01_INSERT_FICHERO_ADJUNTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql 20160125 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql" "REM01" "BRUNO ANGLES" "web"  "9.1.0-cj-rc36.1-CMREC-1907s" "20160125" "CMREC-1907" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907-REM01-reg3.1.sql > DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql" "20160125" "REM01" "KO" ""
	      echo "@KO@: DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql" "20160125" "REM01" "OK" ""
	      echo " OK : DML_602_ENTITY01_INSERT_DD_RULE_DEFINITION_CMREC1907.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_603_ENTITY01_NuevoEstadoEPF.sql 20160225 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_603_ENTITY01_NuevoEstadoEPF.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_603_ENTITY01_NuevoEstadoEPF.sql" "REM01" "Oscar Dorado" "online"  "9.1" "20160225" "PRODUCTO-851" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_603_ENTITY01_NuevoEstadoEPF-REM01-reg3.1.sql > DML_603_ENTITY01_NuevoEstadoEPF.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_603_ENTITY01_NuevoEstadoEPF.sql" "20160225" "REM01" "KO" ""
	      echo "@KO@: DML_603_ENTITY01_NuevoEstadoEPF.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_603_ENTITY01_NuevoEstadoEPF.sql" "20160225" "REM01" "OK" ""
	      echo " OK : DML_603_ENTITY01_NuevoEstadoEPF.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql 2016015 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.3-hy-master" "2016015" "PRODUCTO-710" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO-REM01-reg3.1.sql > DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql" "2016015" "REM01" "KO" ""
	      echo "@KO@: DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql" "2016015" "REM01" "OK" ""
	      echo " OK : DML_000_ENTITY01_REPARAR_TAP_TAREA_PROCEDIMEINTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql 20160203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.1.3-hy-master" "20160203" "CMREC-1772" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR-REM01-reg3.1.sql > DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql" "20160203" "REM01" "KO" ""
	      echo "@KO@: DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql" "20160203" "REM01" "OK" ""
	      echo " OK : DML_001_ENTITY01_INSERT_FUN_FUNCIONES_ACTUACIONES_EXPLORAR.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql 20160229 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql" "REM01" "PEDROBLASCO" "online"  "9.2" "20160229" "PRODUCTO-565" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg-REM01-reg3.1.sql > DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql" "20160229" "REM01" "KO" ""
	      echo "@KO@: DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql" "20160229" "REM01" "OK" ""
	      echo " OK : DML_001_ENTITY01_NuevoTipoSubtareaNotificacionEntradaIrreg.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql 20160203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql" "REM01" "Alberto B" "online"  "9.2.0-cj" "20160203" "CMREC-1989" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion-REM01-reg3.1.sql > DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql" "20160203" "REM01" "KO" ""
	      echo "@KO@: DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql" "20160203" "REM01" "OK" ""
	      echo " OK : DML_001_ENTITY01_UPDATE_ZON_ZONIFICACIONresetDescripcion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql 20160203 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql" "REM01" "JORGE ROS" "online"  "9.1" "20160203" "PRODUCTO-671" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU-REM01-reg3.1.sql > DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql" "20160203" "REM01" "KO" ""
	      echo "@KO@: DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql" "20160203" "REM01" "OK" ""
	      echo " OK : DML_002_ENTITY01_INSERT_FUN_PEF_TABS_ASU.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql 20160225 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql" "REM01" "Luis Caballero Pardillo" "online"  "9.2-hy-master" "20160225" "PRODUCTO-707" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO-REM01-reg3.1.sql > DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql" "20160225" "REM01" "KO" ""
	      echo "@KO@: DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql" "20160225" "REM01" "OK" ""
	      echo " OK : DML_002_ENTITY01_INSERT_PEN_PARAM_TIEMPO_CARGA_FECHA_CACHEO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_002_ENTITY01_UPDATE_CRI.sql 20160215 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_002_ENTITY01_UPDATE_CRI.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_002_ENTITY01_UPDATE_CRI.sql" "REM01" "José Luis Gauxachs" "online"  "v_Febrero" "20160215" "CMREC-2026" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_002_ENTITY01_UPDATE_CRI-REM01-reg3.1.sql > DML_002_ENTITY01_UPDATE_CRI.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_UPDATE_CRI.sql" "20160215" "REM01" "KO" ""
	      echo "@KO@: DML_002_ENTITY01_UPDATE_CRI.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_ENTITY01_UPDATE_CRI.sql" "20160215" "REM01" "OK" ""
	      echo " OK : DML_002_ENTITY01_UPDATE_CRI.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql 20160218 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql" "REMMASTER" "Javier Ruiz" "online"  "9.2.0-hy-rc01" "20160218" "PRODUCTO-796" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_002_MASTER_INSERT_TIPO_ITINERARIO-REMMASTER-reg3.1.sql > DML_002_MASTER_INSERT_TIPO_ITINERARIO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql" "20160218" "REMMASTER" "KO" ""
	      echo "@KO@: DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql" "20160218" "REMMASTER" "OK" ""
	      echo " OK : DML_002_MASTER_INSERT_TIPO_ITINERARIO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql 20160218 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "REM01" "CARLOS GIL GIMENO" "web"  "9.1.0-cj-rc26" "20160218" "PRODUCTO-798" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION-REM01-reg3.1.sql > DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "20160218" "REM01" "KO" ""
	      echo "@KO@: DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "20160218" "REM01" "OK" ""
	      echo " OK : DML_003_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_003_ENTITY01_INSERT_DDSituacionGestion.sql 20160303 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_003_ENTITY01_INSERT_DDSituacionGestion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_003_ENTITY01_INSERT_DDSituacionGestion.sql" "REM01" "Alberto S" "online"  "9.2" "20160303" "PRODUCTO-811" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_003_ENTITY01_INSERT_DDSituacionGestion-REM01-reg3.1.sql > DML_003_ENTITY01_INSERT_DDSituacionGestion.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DDSituacionGestion.sql" "20160303" "REM01" "KO" ""
	      echo "@KO@: DML_003_ENTITY01_INSERT_DDSituacionGestion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DDSituacionGestion.sql" "20160303" "REM01" "OK" ""
	      echo " OK : DML_003_ENTITY01_INSERT_DDSituacionGestion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql 20160301 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql" "REM01" "CARLOS MARTOS NAVARRO" "online"  "9.2" "20160301" "PRODUCTO-692" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO-REM01-reg3.1.sql > DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql" "20160301" "REM01" "KO" ""
	      echo "@KO@: DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql" "20160301" "REM01" "OK" ""
	      echo " OK : DML_003_ENTITY01_INSERT_DD_TFA_FICHERO_ADJUNTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql 20160225 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql" "REM01" "José Luis Gauxachs" "web"  "9.2.0-hy-rc01" "20160225" "HR-1958" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS-REM01-reg3.1.sql > DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql" "20160225" "REM01" "KO" ""
	      echo "@KO@: DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql" "20160225" "REM01" "OK" ""
	      echo " OK : DML_003_ENTITY01_UPDATE_PRB_PRC_BIE_BORRAR_DUPLICADOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql 20160302 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql" "REMMASTER" "Iván Picazo" "online"  "9.2" "20160302" "PRODUCTO-730" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_003_MASTER_UPDATE_DD_STA_SUBTIPO-REMMASTER-reg3.1.sql > DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql" "20160302" "REMMASTER" "KO" ""
	      echo "@KO@: DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql" "20160302" "REMMASTER" "OK" ""
	      echo " OK : DML_003_MASTER_UPDATE_DD_STA_SUBTIPO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql 20160219 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.17-bk" "20160219" "PRODUCTO-798" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_004_ENTITY01_INSERT_FUNCION_SANCION-REM01-reg3.1.sql > DML_004_ENTITY01_INSERT_FUNCION_SANCION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql" "20160219" "REM01" "KO" ""
	      echo "@KO@: DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql" "20160219" "REM01" "OK" ""
	      echo " OK : DML_004_ENTITY01_INSERT_FUNCION_SANCION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql 20160301 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql" "REMMASTER" "Alberto B." "online"  "9.2.0-HY-BCC" "20160301" "_SIN_ITEM" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS-REMMASTER-reg3.1.sql > DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql" "20160301" "REMMASTER" "KO" ""
	      echo "@KO@: DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql" "20160301" "REMMASTER" "OK" ""
	      echo " OK : DML_004_MASTER_INSERT_FUN_FUNCIONES_TAB_PROPUESTAS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql 20160219 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql" "REM01" "CARLOS GIL GIMENO" "online"  "9.1.17-bk" "20160219" "PRODUCTO-791" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA-REM01-reg3.1.sql > DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql" "20160219" "REM01" "KO" ""
	      echo "@KO@: DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql" "20160219" "REM01" "OK" ""
	      echo " OK : DML_005_ENTITY01_INSERT_FUNCION_REVISION_SOLVENCIA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_005_MASTER_INSERT_USUARIO_FAKE.sql 20160307 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_005_MASTER_INSERT_USUARIO_FAKE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_005_MASTER_INSERT_USUARIO_FAKE.sql" "REMMASTER" "Carlos Perez" "online"  "9.2.0" "20160307" "CMREC-2422" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_005_MASTER_INSERT_USUARIO_FAKE-REMMASTER-reg3.1.sql > DML_005_MASTER_INSERT_USUARIO_FAKE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_005_MASTER_INSERT_USUARIO_FAKE.sql" "20160307" "REMMASTER" "KO" ""
	      echo "@KO@: DML_005_MASTER_INSERT_USUARIO_FAKE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_005_MASTER_INSERT_USUARIO_FAKE.sql" "20160307" "REMMASTER" "OK" ""
	      echo " OK : DML_005_MASTER_INSERT_USUARIO_FAKE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql 20160219 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql" "REM01" "Javier Ruiz" "online"  "9.2.0-hy-rc01" "20160219" "PRODUCTO-793" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA-REM01-reg3.1.sql > DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql" "20160219" "REM01" "KO" ""
	      echo "@KO@: DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql" "20160219" "REM01" "OK" ""
	      echo " OK : DML_006_ENTITY01_INSERT_TIPO_EXP_GESTION_DEUDA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql 20160309 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql" "REM01" "Luis Caballero Pardillo" "online"  "9.2.0-hy-rc01" "20160309" "PRODUCTO-901" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE-REM01-reg3.1.sql > DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql" "20160309" "REM01" "KO" ""
	      echo "@KO@: DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql" "20160309" "REM01" "OK" ""
	      echo " OK : DML_006_ENTITY01_UPDATE_FUN_PEF_TAB_DOCUMENTOS_EXPEDIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql" "REMMASTER" "Jorge Ros" "online"  "9.2" "20160311" "HR-2052" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_006_MASTER_UPDATE_BORRADO_DD_IMV-REMMASTER-reg3.1.sql > DML_006_MASTER_UPDATE_BORRADO_DD_IMV.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_006_MASTER_UPDATE_BORRADO_DD_IMV.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql 20160222 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql" "REM01" "Javier Ruiz" "online"  "9.2.0-hy-rc01" "20160222" "PRODUCTO-802" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP-REM01-reg3.1.sql > DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql" "20160222" "REM01" "KO" ""
	      echo "@KO@: DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql" "20160222" "REM01" "OK" ""
	      echo " OK : DML_007_ENTITY01_FUNCIONES_CREACION_MANUAL_EXP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-702" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI-REMMASTER-reg3.1.sql > DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_008_MASTER_INSERT_FUN_FUNCIONES_TELECOBRO_ITI.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-702" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI-REMMASTER-reg3.1.sql > DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_009_MASTER_INSERT_FUN_FUNCIONES_BOTON_NUEVO_ITI.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-702" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO-REMMASTER-reg3.1.sql > DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_010_MASTER_INSERT_FUN_FUNCIONES_TAB_SUPERVISORES_DESPACHO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql 20160322 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160322" "_PRODUCTO-953" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA-REMMASTER-reg3.1.sql > DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql" "20160322" "REMMASTER" "KO" ""
	      echo "@KO@: DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql" "20160322" "REMMASTER" "OK" ""
	      echo " OK : DML_011_MASTER_INSERT_FUN_FUNCIONES_BOTON_AGREGAR_ENTREGA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql" "REMMASTER" "Kevin Fernandez" "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS-REMMASTER-reg3.1.sql > DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_011_MASTER_INSERT_FUN_FUNCIONES_TAB_CONTABILIDAD_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql 20160322 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160322" "_PRODUCTO-953" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA-REMMASTER-reg3.1.sql > DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql" "20160322" "REMMASTER" "KO" ""
	      echo "@KO@: DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql" "20160322" "REMMASTER" "OK" ""
	      echo " OK : DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_MODIFICAR_ENTREGA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql" "REMMASTER" "Kevin Fernandez" "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO-REMMASTER-reg3.1.sql > DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_012_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIDAD_COBRO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql 20160311 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql" "REMMASTER" "Luis Caballero." "online"  "9.2.0-HY-BCC" "20160311" "_PRODUCTO-702" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO-REMMASTER-reg3.1.sql > DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql" "20160311" "REMMASTER" "KO" ""
	      echo "@KO@: DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql" "20160311" "REMMASTER" "OK" ""
	      echo " OK : DML_013_MASTER_INSERT_FUN_FUNCIONES_TAB_ENTREGAS_ASUNTO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql 20160311 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql" "REM01" "Alberto b." "online"  "9.2.0-cj" "20160311" "CMREC-2751" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP-REM01-reg3.1.sql > DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql" "20160311" "REM01" "KO" ""
	      echo "@KO@: DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql" "20160311" "REM01" "OK" ""
	      echo " OK : DML_016_ENTITY01_INSERT_DD_STA_SUBTIPO_TAREA_BASE_ProrrogaFP.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_017_MASTER_INSERT_DD_IMV.sql 20160314 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_017_MASTER_INSERT_DD_IMV.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_017_MASTER_INSERT_DD_IMV.sql" "REMMASTER" "JORGE ROS" "online"  "9.2" "20160314" "HR-2052" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_017_MASTER_INSERT_DD_IMV-REMMASTER-reg3.1.sql > DML_017_MASTER_INSERT_DD_IMV.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_017_MASTER_INSERT_DD_IMV.sql" "20160314" "REMMASTER" "KO" ""
	      echo "@KO@: DML_017_MASTER_INSERT_DD_IMV.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_017_MASTER_INSERT_DD_IMV.sql" "20160314" "REMMASTER" "OK" ""
	      echo " OK : DML_017_MASTER_INSERT_DD_IMV.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql" "REM01" "Kevin Fernández" "online"  "9.1.3-hy-master" "20160330" "PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS-REM01-reg3.1.sql > DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DML_018_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_BOTONES_CONTABILIDAD_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql 20160330 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql" "REM01" "Kevin Fernández" "online"  "9.1.3-hy-master" "20160330" "PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS-REM01-reg3.1.sql > DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql" "20160330" "REM01" "KO" ""
	      echo "@KO@: DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql" "20160330" "REM01" "OK" ""
	      echo " OK : DML_019_ENTITY01_INSERT_FUN_FUNCIONES_PERMISOS_TAB_CONTABILIDAD_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma-REM01-reg3.1.sql > DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_insertarEnDiccionarioAsistenciaAFirma.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_insertarEnDiccionarioDesistir-REM01-reg3.1.sql > DML_020_ENTITY01_insertarEnDiccionarioDesistir.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_insertarEnDiccionarioDesistir.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_insertarEnDiccionarioGestionVenta-REM01-reg3.1.sql > DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_insertarEnDiccionarioGestionVenta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado-REM01-reg3.1.sql > DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_020_ENTITY01_insertarEnDiccionarioResolucionAcreditado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql 20160401 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql" "REMMASTER" "Kevin Fernandez" "online"  "9.2.0-HY-BCC" "20160401" "_PRODUCTO-954" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO-REMMASTER-reg3.1.sql > DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql" "20160401" "REMMASTER" "KO" ""
	      echo "@KO@: DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql" "20160401" "REMMASTER" "OK" ""
	      echo " OK : DML_020_MASTER_INSERT_FUN_FUNCIONES_BOTON_ENVIAR_CONTABILIDAD_COBRO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision-REM01-reg3.1.sql > DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_021_ENTITY01_insertarEnDiccionarioResultadoRevision.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql 20160414 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql" "REMMASTER" "Óscar Dorado" "online"  "9.2.2" "20160414" "_PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS-REMMASTER-reg3.1.sql > DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql" "20160414" "REMMASTER" "KO" ""
	      echo "@KO@: DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql" "20160414" "REMMASTER" "OK" ""
	      echo " OK : DML_021_MASTER_Insert_ROLE_PUEDE_SUBIR_ADJUNTOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioCuantia-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioCuantia.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioCuantia.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioDecisionSuspElect.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioEntidadCesionRemate.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioMotivoNoPagarTasa.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioMotivoSuspSubastaElec.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioResolucionPagoTasa.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioResultadoComiteSub.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql 20160415 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160415" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores-REM01-reg3.1.sql > DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql" "20160415" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql" "20160415" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_insertarEnDiccionarioResultadoPostores.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql 20160411 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2.3" "20160411" "PRODUCTO-1212" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_ENTITY01_INSERT_TIPO_OBJETIVO-REM01-reg3.1.sql > DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql" "20160411" "REM01" "KO" ""
	      echo "@KO@: DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql" "20160411" "REM01" "OK" ""
	      echo " OK : DML_022_ENTITY01_INSERT_TIPO_OBJETIVO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql 20160422 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql" "REMMASTER" "Alberto Campos" "online"  "9.2.2" "20160422" "HR-2306" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306-REMMASTER-reg3.1.sql > DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql" "20160422" "REMMASTER" "KO" ""
	      echo "@KO@: DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql" "20160422" "REMMASTER" "OK" ""
	      echo " OK : DML_022_MASTER_DELETE_JBPM_TRANSITION_HR-2306.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql 20160418 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql" "REM01" "Carlos Martos" "online"  "9.2" "20160418" "PRODUCTO-1093" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional-REM01-reg3.1.sql > DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql" "20160418" "REM01" "KO" ""
	      echo "@KO@: DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql" "20160418" "REM01" "OK" ""
	      echo " OK : DML_023_ENTITY01_insertarEnDiccionarioFavorableCondicional.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_023_ENTITY01_insertarEnDiccionarioTFA.sql 20160413 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_023_ENTITY01_insertarEnDiccionarioTFA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_023_ENTITY01_insertarEnDiccionarioTFA.sql" "REM01" "Óscar Dorado" "online"  "9.2" "20160413" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_023_ENTITY01_insertarEnDiccionarioTFA-REM01-reg3.1.sql > DML_023_ENTITY01_insertarEnDiccionarioTFA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_insertarEnDiccionarioTFA.sql" "20160413" "REM01" "KO" ""
	      echo "@KO@: DML_023_ENTITY01_insertarEnDiccionarioTFA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_023_ENTITY01_insertarEnDiccionarioTFA.sql" "20160413" "REM01" "OK" ""
	      echo " OK : DML_023_ENTITY01_insertarEnDiccionarioTFA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql 20160512 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql" "REM01" "Alberto Campos" "online"  "9.2.4" "20160512" "HR-2198" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198-REM01-reg3.1.sql > DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql" "20160512" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql" "20160512" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_DELETE_TAR_TAREAS_NOTIFICACIONES_HR-2198.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_InsertarFunciones.sql 20160506 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_InsertarFunciones.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_InsertarFunciones.sql" "REM01" "MANUEL MEJIAS" "online"  "9.1.0-X" "20160506" "PRODUCTO-1253" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_InsertarFunciones-REM01-reg3.1.sql > DML_024_ENTITY01_InsertarFunciones.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_InsertarFunciones.sql" "20160506" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_InsertarFunciones.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_InsertarFunciones.sql" "20160506" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_InsertarFunciones.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_nuevaEntradaTipoPreparacion-REM01-reg3.1.sql > DML_024_ENTITY01_nuevaEntradaTipoPreparacion.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_nuevaEntradaTipoPreparacion.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql 20160414 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160414" "PRODUCTO-1089" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_nuevoDiccionarioPrioridad-REM01-reg3.1.sql > DML_024_ENTITY01_nuevoDiccionarioPrioridad.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql" "20160414" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql" "20160414" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_nuevoDiccionarioPrioridad.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql 20160502 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160502" "PRODUCTO-1091" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar-REM01-reg3.1.sql > DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql" "20160502" "REM01" "KO" ""
	      echo "@KO@: DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql" "20160502" "REM01" "OK" ""
	      echo " OK : DML_024_ENTITY01_nuevoTipoActuacion_NoLitigar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql 20160502 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql" "REMMASTER" "Luis Caballero" "online"  "9.2.0-HY-BCC" "20160502" "_PRODUCTO-1266" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA-REMMASTER-reg3.1.sql > DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql" "20160502" "REMMASTER" "KO" ""
	      echo "@KO@: DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql" "20160502" "REMMASTER" "OK" ""
	      echo " OK : DML_024_MASTER_INSERT_FUN_FUNCIONES_BOTON_CAMBIO_OFICINA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_025_MASTER_EliminarFuncionSoloConsulta.sql 20160505 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_025_MASTER_EliminarFuncionSoloConsulta.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_025_MASTER_EliminarFuncionSoloConsulta.sql" "REMMASTER" "PEDRO BLASCO" "online"  "9.1.8-hy-rc01" "20160505" "PRODUCTO-1253" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_025_MASTER_EliminarFuncionSoloConsulta-REMMASTER-reg3.1.sql > DML_025_MASTER_EliminarFuncionSoloConsulta.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_EliminarFuncionSoloConsulta.sql" "20160505" "REMMASTER" "KO" ""
	      echo "@KO@: DML_025_MASTER_EliminarFuncionSoloConsulta.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_EliminarFuncionSoloConsulta.sql" "20160505" "REMMASTER" "OK" ""
	      echo " OK : DML_025_MASTER_EliminarFuncionSoloConsulta.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql 20160506 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql" "REMMASTER" "Kevin Fernandez" "online"  "9.2.4" "20160506" "_PRODUCTO-1330" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS-REMMASTER-reg3.1.sql > DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql" "20160506" "REMMASTER" "KO" ""
	      echo "@KO@: DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql" "20160506" "REMMASTER" "OK" ""
	      echo " OK : DML_025_MASTER_INSERT_FUN_FUNCIONES_BOTON_PERMITIR_CONTABILIZAR_COBROS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql 20160503 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql" "REMMASTER" "Enrique_Badenes" "online"  "9.2" "20160503" "_PRODUCTO-1293" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE-REMMASTER-reg3.1.sql > DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql" "20160503" "REMMASTER" "KO" ""
	      echo "@KO@: DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql" "20160503" "REMMASTER" "OK" ""
	      echo " OK : DML_025_MASTER_INSERT_FUN_FUNCIONES_BUZON_OBJETIVOS_CLIENTE.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql 20160512 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql" "REM01" "PEDRO BLASCO" "online"  "9.2.3.patch3" "20160512" "PRODUCTO-1372" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA-REM01-reg3.1.sql > DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql" "20160512" "REM01" "KO" ""
	      echo "@KO@: DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql" "20160512" "REM01" "OK" ""
	      echo " OK : DML_026_ENTITY01_EliminarFunPefMSV-INST-SUBASTA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud-REM01-reg3.1.sql > DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_026_ENTITY01_insertarEnDiccionarioTipoSolicitud.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql 20160511 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "REM01" "CARLOS GIL GIMENO" "web"  "9.2.4" "20160511" "PRODUCTO-1297" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION-REM01-reg3.1.sql > DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "20160511" "REM01" "KO" ""
	      echo "@KO@: DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql" "20160511" "REM01" "OK" ""
	      echo " OK : DML_026_ENTITY01_INSERT_DD_DES_DECISION_SANCION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql 20160519 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql" "REMMASTER" "IVÁN PICAZO" "online"  "9.2.4" "20160519" "_PRODUCTO-1270" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS-REMMASTER-reg3.1.sql > DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql" "20160519" "REMMASTER" "KO" ""
	      echo "@KO@: DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql" "20160519" "REMMASTER" "OK" ""
	      echo " OK : DML_026_MASTER_INSERT_FUN_FUNCIONES_PESTANIA_BUSCADOR_ACUERDOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql 20160510 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160510" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar-REM01-reg3.1.sql > DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql" "20160510" "REM01" "KO" ""
	      echo "@KO@: DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql" "20160510" "REM01" "OK" ""
	      echo " OK : DML_027_ENTITY01_insertarEnDiccionarioAceptarSubsanar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql 20160401 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160401" "PRODUCTO-948" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar-REM01-reg3.1.sql > DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql" "20160401" "REM01" "KO" ""
	      echo "@KO@: DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql" "20160401" "REM01" "OK" ""
	      echo " OK : DML_028_ENTITY01_insertarEnDiccionarioTipoPrcIniciar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql 20160610 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql" "REM01" "Kevin Fernández" "online"  "9.2" "20160610" "PRODUCTO-1491" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA-REM01-reg3.1.sql > DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql" "20160610" "REM01" "KO" ""
	      echo "@KO@: DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql" "20160610" "REM01" "OK" ""
	      echo " OK : DML_029_ENTITY01_INSERT_DD_OOF_ORIGEN_OFICINA.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql 20160519 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql" "REMMASTER" "Jorge Ros" "online"  "v9.2.4-bk" "20160519" "PRODUCTO-1274" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS-REMMASTER-reg3.1.sql > DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql" "20160519" "REMMASTER" "KO" ""
	      echo "@KO@: DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql" "20160519" "REMMASTER" "OK" ""
	      echo " OK : DML_040_MASTER_INSERT_FUNCION_TAB_LETRADOS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql 20160602 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql" "REM01" "Nacho Arcos" "online"  "9.2" "20160602" "PRODUCTO-1864" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar-REM01-reg3.1.sql > DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql" "20160602" "REM01" "KO" ""
	      echo "@KO@: DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql" "20160602" "REM01" "OK" ""
	      echo " OK : DML_041_ENTITY01_UPDATE_DD_TPO_NoLitigar.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql 20160504 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql" "REM01" "Luis Caballero" "online"  "9.2" "20160504" "PRODUCTO-1342" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID-REM01-reg3.1.sql > DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql" "20160504" "REM01" "KO" ""
	      echo "@KO@: DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql" "20160504" "REM01" "OK" ""
	      echo " OK : DML_104_ENTITY01_INSERT_FUN_FUNCIONES_CALCULO_LIQUID.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql 20160517 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql" "REM01" "Luis Caballero" "online"  "9.2.4-bk" "20160517" "PRODUCTO-1439" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION-REM01-reg3.1.sql > DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql" "20160517" "REM01" "KO" ""
	      echo "@KO@: DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql" "20160517" "REM01" "OK" ""
	      echo " OK : DML_105_ENTITY01_CREACION_TAREA_UNICA_ANOTACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql 20160516 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql" "REM01" "Javier Ruiz" "online"  "9.2.4" "20160516" "PRODUCTO-1349" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES-REM01-reg3.1.sql > DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql" "20160516" "REM01" "KO" ""
	      echo "@KO@: DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql" "20160516" "REM01" "OK" ""
	      echo " OK : DML_105_ENTITY01_INSERT_DD_EDL_ESTADO_DELEGACIONES.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql 20160525 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql" "REM01" "Luis Caballero" "online"  "9.2.4-bk" "20160525" "PRODUCTO-1546" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_106_ENTITY01_Buscadores_jerarquizado_activado-REM01-reg3.1.sql > DML_106_ENTITY01_Buscadores_jerarquizado_activado.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql" "20160525" "REM01" "KO" ""
	      echo "@KO@: DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql" "20160525" "REM01" "OK" ""
	      echo " OK : DML_106_ENTITY01_Buscadores_jerarquizado_activado.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql 20160516 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql" "REM01" "Carlos Gil Gimeno" "online"  "9.2" "20160516" "PRODUCTO-1414" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS-REM01-reg3.1.sql > DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql" "20160516" "REM01" "KO" ""
	      echo "@KO@: DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql" "20160516" "REM01" "OK" ""
	      echo " OK : DML_106_ENTITY01_INSERT_FUN_FUNCIONES_DELEGACION_TAREAS.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql 20160607 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql" "REM01" "Ivan Picazo" "online"  "9.2.6" "20160607" "PRODUCTO-1444" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION-REM01-reg3.1.sql > DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql" "20160607" "REM01" "KO" ""
	      echo "@KO@: DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql" "20160607" "REM01" "OK" ""
	      echo " OK : DML_107_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql 20160616 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql" "REM01" "LUIS CABALLERO" "online"  "9.2" "20160616" "PRODUCTO-1999" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC-REM01-reg3.1.sql > DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql" "20160616" "REM01" "KO" ""
	      echo "@KO@: DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql" "20160616" "REM01" "OK" ""
	      echo " OK : DML_107_ENTITY01_UPDATE_SPR_SOLICITUD_PRORROGAS_FECHA_VENC.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql 20160609 REMMASTER > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql" "REMMASTER" "Enrique Badenes" "online"  "v9.2.6" "20160609" "PRODUCTO-1366" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO-REMMASTER-reg3.1.sql > DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql" "20160609" "REMMASTER" "KO" ""
	      echo "@KO@: DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql" "20160609" "REMMASTER" "OK" ""
	      echo " OK : DML_107_MASTER_INFERT_FUN_FUNCIONES_CONFIG_TURNADO.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql 20160701 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql" "REM01" "Ivan Picazo" "online"  "9.2.6" "20160701" "PRODUCTO-1444" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD-REM01-reg3.1.sql > DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql" "20160701" "REM01" "KO" ""
	      echo "@KO@: DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql" "20160701" "REM01" "OK" ""
	      echo " OK : DML_108_ENTITY01_UPDATE_ASU_ASUNTOS_MOTIVO_FINALIZACION_MOD.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql 20160608 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql" "REM01" "Iván Picazo" "online"  "9.2.6" "20160608" "PRODUCTO-1910" "NO"
	  exit | sqlplus -s -l $1 @./scripts/DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version-REM01-reg3.1.sql > DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql" "20160608" "REM01" "KO" ""
	      echo "@KO@: DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql" "20160608" "REM01" "OK" ""
	      echo " OK : DML_108_ENTITY01_UPDATE_LIA_LISTA_ARQUETIPOS_Version.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql 20160603 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql" "REM01" "OSCAR DORADO" "online"  "9.2" "20160603" "PRODUCTO-1901" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_139_ENTITY01_PRODUCTO-1901_calculoFecha-REM01-reg3.1.sql > DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql" "20160603" "REM01" "KO" ""
	      echo "@KO@: DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql" "20160603" "REM01" "OK" ""
	      echo " OK : DML_139_ENTITY01_PRODUCTO-1901_calculoFecha.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql 20160614 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql" "REM01" "Vicente Lozano" "online"  "9.2.5" "20160614" "PRODUCTO-1913" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913-REM01-reg3.1.sql > DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql" "20160614" "REM01" "KO" ""
	      echo "@KO@: DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql" "20160614" "REM01" "OK" ""
	      echo " OK : DML_140_ENTITY01_UPDATE_DES_DESPACHO_EXTERNO_PROD_1913.sql"
	  fi
	fi
	exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg2.sql DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql 20160616 REM01 > /dev/null
	export RESULTADO=$?
	if [ $RESULTADO == 33 ] ; then
	    echo " YE : Fichero ya ejecutado DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql"
	elif [ $RESULTADO != 0 ] ; then
	    echo "Fin de ejecución por fallo. Remita los ficheros de logs para que se analice lo sucedido."
	    return
	else
	  exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg3.sql "DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql" "REM01" "Alberto Soler" "online"  "9.2" "20160616" "PRODUCTO-1960" "SI"
	  exit | sqlplus -s -l $1 @./scripts/DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida-REM01-reg3.1.sql > DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.log
	  export RESULTADO=$?
	  if [ $RESULTADO != 0 ] ; then
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql" "20160616" "REM01" "KO" ""
	      echo "@KO@: DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql"
	      return
	  else
	      exit | sqlplus -s -l $1 @./scripts/DML_000_ENTITY01_reg4.sql "DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql" "20160616" "REM01" "OK" ""
	      echo " OK : DML_141_ENTITY01_INSERT_UPDATE_PEN_PARAM_plazoSiTareaVencida.sql"
	  fi
	fi
}

run_scripts "$@" | tee output.log
zip --quiet DB_logs_428a00d9a86d715cb2442923a9b8859cecab61a1_$(date +"%y%m%d-%H%M%S").zip *.log
